const express = require('express');
const path = require('path');

const app = express();
app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname)));

/* ── Ollama Proxy: avoids CORS ── */
async function ollamaProxy(targetPath, reqBody, res) {
    const apiUrl = (reqBody.apiUrl || '').replace(/\/+$/, '');
    if (!apiUrl) return res.status(400).json({ error: 'apiUrl is required' });

    try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 180000);

        const response = await fetch(apiUrl + targetPath, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(reqBody.payload || {}),
            signal: controller.signal
        });
        clearTimeout(timeout);

        const text = await response.text();
        let data;
        try { data = JSON.parse(text); } catch { data = text; }

        res.status(response.status).json(data);
    } catch (err) {
        const msg = err.name === 'AbortError'
            ? 'Ollama request timed out (3 min)'
            : 'Cannot reach Ollama at ' + apiUrl + '. Is it running?';
        res.status(502).json({ error: msg });
    }
}

/* Test connection — fetches model list */
app.post('/api/ollama/test', async (req, res) => {
    const apiUrl = (req.body.apiUrl || '').replace(/\/+$/, '');
    if (!apiUrl) return res.status(400).json({ error: 'apiUrl is required' });

    try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 8000);

        const response = await fetch(apiUrl + '/api/tags', { signal: controller.signal });
        clearTimeout(timeout);
        const data = await response.json();
        res.status(response.status).json(data);
    } catch (err) {
        const msg = err.name === 'AbortError'
            ? 'Connection timed out. Is Ollama running?'
            : 'Cannot reach ' + apiUrl;
        res.status(502).json({ error: msg });
    }
});

/* Chat completion proxy */
app.post('/api/ollama/chat', (req, res) => {
    ollamaProxy('/api/chat', req.body, res);
});

/* Generate proxy (for future use) */
app.post('/api/ollama/generate', (req, res) => {
    ollamaProxy('/api/generate', req.body, res);
});

const PORT = 3000;
const HOST = '192.168.15.253'; // Aapki specific IP

app.listen(PORT, HOST, () => {
    console.log('╔══════════════════════════════════════╗');
    console.log('║  FlowCraft server running            ║');
    console.log(`║  Network: http://${HOST}:${PORT}      ║`);
    console.log(`║  Local:   http://localhost:${PORT}     ║`);
    console.log('╚══════════════════════════════════════╝');
});
