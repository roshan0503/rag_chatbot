from django.urls import path
from . import views

app_name = 'question_generation'

urlpatterns = [
    path('', views.hierarchy_view, name='home'),
    path('hierarchy/', views.hierarchy_view, name='hierarchy_view'),
    path('ajax/get-legs/', views.ajax_get_legs, name='ajax_get_legs'),
    path('ajax/get-subjects/', views.ajax_get_subjects, name='ajax_get_subjects'),
    path('ajax/get-chapters/', views.ajax_get_chapters, name='ajax_get_chapters'),
    path('ajax/get-topics/', views.ajax_get_topics, name='ajax_get_topics'),
    path('ajax/get-sections/', views.ajax_get_sections, name='ajax_get_sections'),
    path('ajax/get-hierarchy-data/', views.ajax_get_hierarchy_data, name='ajax_get_hierarchy_data'),
    path('question_generation/',         views.question_generation, name='question_generation'),
    path('ajax/search-documents/',        views.ajax_search_documents,   name='ajax_search_documents'),
    path('ajax/generate-questions/',      views.generate_questions,       name='generate_questions'),
    path('question_paper/',         views.question_paper, name='question_paper'),
    path('api/generate-paper-pdf/', views.generate_paper_pdf, name='generate_paper_pdf'),
    path('api/save-question-bank/', views.save_question_bank, name='save_question_bank'),
    path('api/export-bank-pdf/', views.export_bank_pdf, name='export_bank_pdf'),
    path('api/question-banks/', views.question_bank_list, name='question_bank_list'),
    path('api/question-banks/<int:bank_id>/', views.question_bank_detail, name='question_bank_detail'),
    path('ajax/load-questions-from-db/', views.ajax_load_questions_from_db, name='ajax_load_questions_from_db'),
    path('access-denied/', views.access_denied, name='access_denied'),
    path('export/<str:file_type>/', views.export_questions, name='export_questions'),
    path('question_bank_explorer/',                 views.question_bank_explorer, name='question_bank_explorer'),
    path('ajax/update-question/',     views.ajax_update_question,   name='ajax_update_question'),
    path('ajax/delete-question/',     views.ajax_delete_question,   name='ajax_delete_question'),
    path('ajax/get-users/',           views.ajax_get_users,         name='ajax_get_users'),

    # ── Also needed: question_bank_detail must accept pk in URL ──────────────────
    # Make sure this pattern exists (it should already):
    path('banks/<int:bank_id>/',      views.question_bank_detail,   name='question_bank_detail'),
    path('ajax/doc-course-map/', views.ajax_doc_course_map, name='ajax_doc_course_map'),
    path('check-document-questions/', views.check_document_questions, name='check_document_questions'),

]
