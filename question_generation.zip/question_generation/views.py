"""
Updated views for question generation in Project 2
Integrates with multi-document hierarchy and chunk management
"""

import json
import PyPDF2
from django.shortcuts import render
from django.http import JsonResponse, FileResponse
from django.views.decorators.http import require_GET, require_POST
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.utils import timezone
from io import BytesIO

from masters.models import Course, Leg, Subject, Chapter, Topic, Section
from masters.views import get_visible_queryset
from question_generation.models import (
    UploadDocument, DocumentCourseMapping, DocumentChunk
)
from question_generation.models import QuestionPaperLog
# Import our new services
from question_generation.question_generation_service import *
from question_generation.llm_integration import LLMFactory, QuestionGenerationPipeline

import json
import PyPDF2
from io import BytesIO
from django.shortcuts import render
from django.http import JsonResponse, FileResponse
from django.views.decorators.http import require_GET, require_POST
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.utils import timezone

# ReportLab
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY, TA_RIGHT
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    PageBreak, KeepTogether,
)
from reportlab.platypus.flowables import Flowable
from reportlab.pdfgen import canvas as pdfcanvas

from masters.models import Course, Leg, Subject, Chapter, Topic, Section,HierarchyCourse
from masters.views import get_visible_queryset
from question_generation.models import (
    UploadDocument, DocumentCourseMapping, DocumentChunk,
    QuestionBank, Question, QuestionBankExport,
)
from question_generation.question_generation_service import QuestionGenerationService
from question_generation.llm_integration import LLMFactory, QuestionGenerationPipeline

# ══════════════════════════════════════════════════════════════════════════════
#  HELPER — resolve a list of document names to UploadDocument instances
# ══════════════════════════════════════════════════════════════════════════════
 
def _resolve_docs_by_name(doc_names: list[str]) -> dict[str, 'UploadDocument']:
    """
    Given a list of document names return a {name: UploadDocument} dict.
    Uses a single DB query.  Names that don't match any row are silently
    omitted (you can log them if you need to debug missing documents).
    """
    if not doc_names:
        return {}
    qs = UploadDocument.objects.filter(document_name__in=doc_names)
    return {doc.document_name: doc for doc in qs}

# REMOVE the old name-based helper entirely and replace with:

def _resolve_docs_by_id(doc_ids: list) -> dict[int, 'UploadDocument']:
    """
    Given a list of document IDs return a {id: UploadDocument} dict.
    Single DB query. Missing IDs are silently omitted.
    """
    if not doc_ids:
        return {}
    # Coerce to int safely
    clean_ids = []
    for d in doc_ids:
        try:
            clean_ids.append(int(d))
        except (TypeError, ValueError):
            pass
    if not clean_ids:
        return {}
    qs = UploadDocument.objects.filter(id__in=clean_ids)
    return {doc.id: doc for doc in qs}


# ══════════════════════════════════════════════════════════════════════════════
#  ROLE HELPER  — used throughout this file
# ══════════════════════════════════════════════════════════════════════════════

def _get_role(user):
    """Return the user's role name string, or '' if not set."""
    try:
        return user.profile.role.name if user.profile.role else ''
    except Exception:
        return ''

def _is_elevated(user):
    """True for superadmin / admin — can see ALL users' data."""
    return _get_role(user) in ('superadmin', 'admin')


# ══════════════════════════════════════════════════════════════════════════════
#  PREMIUM PDF ENGINE
# ══════════════════════════════════════════════════════════════════════════════

# ── Palette ───────────────────────────────────────────────────────────────────
BRAND       = colors.HexColor('#1C4D8D')
BRAND2      = colors.HexColor('#2563b0')
BRAND_LITE  = colors.HexColor('#EBF0FA')
BRAND_XLIT  = colors.HexColor('#F4F7FD')
ACCENT      = colors.HexColor('#F06449')
ACCENT_LITE = colors.HexColor('#FFF2EF')
GREEN       = colors.HexColor('#2ecc8d')
GREEN_LITE  = colors.HexColor('#E6FAF3')
AMBER       = colors.HexColor('#F59E0B')
AMBER_LITE  = colors.HexColor('#FFFBEB')
PURPLE      = colors.HexColor('#7C3AED')
PURPLE_LITE = colors.HexColor('#F5F3FF')
TEXT        = colors.HexColor('#1A2340')
TEXT_MID    = colors.HexColor('#4A5568')
TEXT_SOFT   = colors.HexColor('#94A3B8')
BORDER      = colors.HexColor('#DDE3EF')
WHITE       = colors.white
GRAY_BG     = colors.HexColor('#F8FAFC')

PAGE_W, PAGE_H = A4
ML = 17 * mm;  MR = 17 * mm;  MT = 14 * mm;  MB = 14 * mm
CW = PAGE_W - ML - MR

QTYPE_COLORS = {
    'mcq':  (BRAND,  BRAND_LITE),
    'tf':   (GREEN,  GREEN_LITE),
    'fitb': (AMBER,  AMBER_LITE),
    'sa':   (PURPLE, PURPLE_LITE),
    'desc': (ACCENT, ACCENT_LITE),
}
QTYPE_LABELS = {
    'mcq':  'Multiple Choice Questions',
    'tf':   'True / False',
    'fitb': 'Fill in the Blanks',
    'sa':   'Short Answer',
    'desc': 'Descriptive',
}
TYPE_ORDER = ['mcq', 'fitb', 'tf', 'sa', 'desc']


# ── Custom flowables ──────────────────────────────────────────────────────────

class SectionBanner(Flowable):
    """Coloured full-width section header banner."""
    def __init__(self, label, count, sec_marks, qtype):
        super().__init__()
        self.label     = label
        self.count     = count
        self.sec_marks = sec_marks
        self.qtype     = qtype
        self._height   = 11 * mm

    def wrap(self, aW, aH):
        self._width = aW
        return aW, self._height

    def draw(self):
        c  = self.canv
        w  = self._width
        h  = self._height
        tc, bg = QTYPE_COLORS.get(self.qtype, (BRAND, BRAND_LITE))
        c.setFillColor(bg)
        c.roundRect(0, 0, w, h, 3, fill=1, stroke=0)
        c.setFillColor(tc)
        c.rect(0, 0, 3, h, fill=1, stroke=0)
        c.setFont('Helvetica-Bold', 10.5)
        c.drawString(10, h * 0.32, self.label)
        badge = f"{self.count} question{'s' if self.count != 1 else ''}  ·  {self.sec_marks} marks"
        c.setFont('Helvetica', 8.5)
        c.setFillColor(TEXT_MID)
        c.drawRightString(w - 8, h * 0.32, badge)


class DotLine(Flowable):
    """Dotted writing line for answer spaces."""
    def __init__(self, width):
        super().__init__()
        self._width  = width
        self._height = 7 * mm

    def wrap(self, aW, aH):
        return self._width, self._height

    def draw(self):
        c = self.canv
        c.setStrokeColor(BORDER)
        c.setLineWidth(0.5)
        c.setDash(1, 4)
        c.line(0, 1.5 * mm, self._width, 1.5 * mm)
        c.setDash()


# ── Full-page header / footer canvas ─────────────────────────────────────────

class PaperCanvas(pdfcanvas.Canvas):
    def __init__(self, *args, **kwargs):
        self._paper_title = kwargs.pop('paper_title', 'Question Paper')
        self._total_marks = kwargs.pop('total_marks', 50)
        self._duration    = kwargs.pop('duration',    120)
        self._date_str    = kwargs.pop('date_str',    '')
        self._school      = kwargs.pop('school',      '')
        super().__init__(*args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        n = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self._draw_page(n)
            pdfcanvas.Canvas.showPage(self)
        pdfcanvas.Canvas.save(self)

    def _draw_page(self, total_pages):
        p = self._pageNumber
        c = self

        HEADER_H = 28 * mm if p == 1 else 10 * mm

        c.setFillColor(BRAND)
        c.rect(0, PAGE_H - HEADER_H, PAGE_W, HEADER_H, fill=1, stroke=0)
        c.setFillColor(BRAND2)
        c.rect(0, PAGE_H - HEADER_H, PAGE_W * 0.55, HEADER_H, fill=1, stroke=0)
        c.setFillColor(ACCENT)
        c.rect(0, PAGE_H - HEADER_H - 2 * mm, PAGE_W, 2 * mm, fill=1, stroke=0)
        c.setFillColor(colors.HexColor('#2d6cb5'))
        c.circle(PAGE_W - 20 * mm, PAGE_H - 8 * mm, 18 * mm, fill=1, stroke=0)
        c.setFillColor(colors.HexColor('#3480c9'))
        c.circle(PAGE_W - 8 * mm, PAGE_H - 20 * mm, 14 * mm, fill=1, stroke=0)

        if p == 1:
            if self._school:
                c.setFillColor(colors.HexColor('#b3c9e8'))
                c.setFont('Helvetica', 8)
                c.drawString(ML, PAGE_H - 8 * mm, self._school.upper())
            c.setFillColor(WHITE)
            c.setFont('Helvetica-Bold', 17)
            c.drawString(ML, PAGE_H - 16.5 * mm, self._paper_title)

            pill_y = PAGE_H - 24.5 * mm
            pill_data = [
                (f"  Total Marks: {self._total_marks}  ", ACCENT),
                (f"  Duration: {self._duration} min  ",   GREEN),
                (f"  Date: {self._date_str}  ",           colors.HexColor('#b3c9e8')),
            ]
            px = ML
            for txt, _ in pill_data:
                tw = c.stringWidth(txt, 'Helvetica-Bold', 8)
                c.setFillColor(colors.HexColor('#16A34A'))
                c.roundRect(px, pill_y - 1 * mm, tw + 8, 4.5 * mm, 3.5, fill=1, stroke=0)
                c.setFillColor(WHITE)
                c.setFont('Helvetica-Bold', 8)
                c.drawString(px + 4, pill_y + 0.5 * mm, txt.strip())
                px += tw + 14
        else:
            c.setFillColor(WHITE)
            c.setFont('Helvetica-Bold', 9.5)
            c.drawString(ML, PAGE_H - 7 * mm, self._paper_title + '  (continued)')
            c.setFont('Helvetica', 8)
            c.drawRightString(PAGE_W - MR, PAGE_H - 7 * mm, f'Page {p}')

        FOOTER_H = 9 * mm
        c.setFillColor(BRAND_LITE)
        c.rect(0, 0, PAGE_W, FOOTER_H, fill=1, stroke=0)
        c.setStrokeColor(BRAND)
        c.setLineWidth(0.75)
        c.line(0, FOOTER_H, PAGE_W, FOOTER_H)
        c.setFillColor(TEXT_MID)
        c.setFont('Helvetica', 7.5)
        c.drawString(ML, 3.2 * mm, 'Sawal AI  ·  Confidential')
        c.drawRightString(PAGE_W - MR, 3.2 * mm, f'Page {p} of {total_pages}')

        if p == 1:
            bx_w = 42 * mm
            bx_x = (PAGE_W - bx_w) / 2
            c.setFillColor(WHITE)
            c.setStrokeColor(BORDER)
            c.setLineWidth(0.5)
            c.roundRect(bx_x, 1.5 * mm, bx_w, 6 * mm, 2, fill=1, stroke=1)
            c.setFillColor(TEXT_SOFT)
            c.setFont('Helvetica', 7)
            c.drawCentredString(PAGE_W / 2, 3.2 * mm, f'Score: _________ / {self._total_marks}')


# ── Styles ────────────────────────────────────────────────────────────────────

def _make_styles():
    s = {}
    s['q']   = ParagraphStyle('Q',  fontName='Helvetica', fontSize=10,
                               textColor=TEXT, leading=15, spaceBefore=0,
                               spaceAfter=3, alignment=TA_JUSTIFY)
    s['op']  = ParagraphStyle('OP', fontName='Helvetica', fontSize=9.5,
                               textColor=TEXT_MID, leading=14, leftIndent=4,
                               spaceBefore=1, spaceAfter=1)
    s['nm']  = ParagraphStyle('NM', fontName='Helvetica', fontSize=9.5,
                               textColor=TEXT, leading=14, spaceBefore=2, spaceAfter=3)
    s['ak_q'] = ParagraphStyle('AKQ', fontName='Helvetica-Bold', fontSize=8.5,
                                textColor=TEXT, leading=12, spaceBefore=1, spaceAfter=1)
    s['ak_a'] = ParagraphStyle('AKA', fontName='Helvetica', fontSize=8.5,
                                textColor=TEXT_MID, leading=12, leftIndent=0,
                                spaceBefore=0, spaceAfter=3)
    return s


def _safe(text):
    if not text:
        return ''
    return (str(text)
            .replace('&', '&amp;')
            .replace('<', '&lt;')
            .replace('>', '&gt;'))


def _group(questions):
    grps = {}
    for q in questions:
        t = (q.get('question_type') or 'mcq').lower()
        grps.setdefault(t, []).append(q)
    out = []
    for t in TYPE_ORDER:
        if t in grps:
            out.append((t, grps.pop(t)))
    for t, qs in grps.items():
        out.append((t, qs))
    return out


# ── Build question paper story ────────────────────────────────────────────────

def _build_paper_story(questions, total_marks, duration, instructions, s):
    story = [Spacer(1, 4 * mm)]

    if instructions:
        lines = [l.strip() for l in instructions.split('\n') if l.strip()]

        # ── Instruction header ────────────────────────────────────────────
        header_tbl = Table(
            [[Paragraph(
                '\u2139  GENERAL INSTRUCTIONS',
                ParagraphStyle('IH', fontName='Helvetica-Bold', fontSize=8.5,
                                textColor=WHITE, leading=12, alignment=TA_LEFT)
            )]],
            colWidths=[CW],
        )
        header_tbl.setStyle(TableStyle([
            ('BACKGROUND',    (0, 0), (0, 0), BRAND),
            ('TOPPADDING',    (0, 0), (0, 0), 5),
            ('BOTTOMPADDING', (0, 0), (0, 0), 5),
            ('LEFTPADDING',   (0, 0), (0, 0), 10),
            ('RIGHTPADDING',  (0, 0), (0, 0), 10),
        ]))

        # ── Compact rows — no spaceBefore/spaceAfter so lines are tight ──
        instr_style = ParagraphStyle('IL',
            fontName='Helvetica', fontSize=8.5, textColor=TEXT,
            leading=12, spaceBefore=0, spaceAfter=0)
        num_style = ParagraphStyle('IN',
            fontName='Helvetica-Bold', fontSize=8.5, textColor=BRAND,
            leading=12, spaceBefore=0, spaceAfter=0, alignment=TA_CENTER)

        instr_rows = []
        for i, line in enumerate(lines, 1):
            instr_rows.append([
                Paragraph(f'{i}', num_style),
                Paragraph(_safe(line), instr_style),
            ])

        instr_tbl = Table(instr_rows, colWidths=[7 * mm, CW - 7 * mm])
        row_styles = [
            ('TOPPADDING',    (0, 0), (-1, -1), 4),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
            ('LEFTPADDING',   (0, 0), (-1, -1), 8),
            ('RIGHTPADDING',  (0, 0), (-1, -1), 8),
            ('VALIGN',        (0, 0), (-1, -1), 'MIDDLE'),
            ('LINEBELOW',     (0, 0), (-1, -2), 0.4, BORDER),
        ]
        # Alternating row backgrounds
        for i in range(len(lines)):
            bg = WHITE if i % 2 == 0 else GRAY_BG
            row_styles.append(('BACKGROUND', (0, i), (-1, i), bg))
        instr_tbl.setStyle(TableStyle(row_styles))

        # ── Orange accent left-border wrapper ─────────────────────────────
        wrapper = Table([[instr_tbl]], colWidths=[CW])
        wrapper.setStyle(TableStyle([
            ('LEFTPADDING',   (0, 0), (0, 0), 0),
            ('RIGHTPADDING',  (0, 0), (0, 0), 0),
            ('TOPPADDING',    (0, 0), (0, 0), 0),
            ('BOTTOMPADDING', (0, 0), (0, 0), 0),
            ('LINEBEFORE',    (0, 0), (0, 0), 3.5, ACCENT),
            ('BOX',           (0, 0), (0, 0), 0.5, BORDER),
        ]))

        story.append(KeepTogether([header_tbl, wrapper]))
        story.append(Spacer(1, 5 * mm))

    groups = _group(questions)
    gn = 1

    for qtype, qs in groups:
        label     = QTYPE_LABELS.get(qtype, qtype.upper())
        sec_marks = sum(q.get('marks', 1) for q in qs)
        tc, bg    = QTYPE_COLORS.get(qtype, (BRAND, BRAND_LITE))

        story.append(SectionBanner(label, len(qs), sec_marks, qtype))
        story.append(Spacer(1, 3 * mm))

        for q in qs:
            qt = _safe(q.get('question') or q.get('question_text') or '')
            qm = q.get('marks', 1)

            num_tbl = Table(
                [[Paragraph(f'<b>{gn}</b>', ParagraphStyle('QN',
                    fontName='Helvetica-Bold', fontSize=9.5,
                    textColor=WHITE, alignment=TA_CENTER, leading=11))]],
                colWidths=[6.5 * mm], rowHeights=[6.5 * mm],
            )
            num_tbl.setStyle(TableStyle([
                ('BACKGROUND',    (0, 0), (0, 0), tc),
                ('TOPPADDING',    (0, 0), (0, 0), 1),
                ('BOTTOMPADDING', (0, 0), (0, 0), 1),
                ('LEFTPADDING',   (0, 0), (0, 0), 0),
                ('RIGHTPADDING',  (0, 0), (0, 0), 0),
                ('VALIGN',        (0, 0), (0, 0), 'MIDDLE'),
            ]))

            marks_para = Paragraph(
                f'<font color="#94a3b8">[{qm}m]</font>',
                ParagraphStyle('MR', fontName='Helvetica-Oblique', fontSize=8,
                               textColor=TEXT_SOFT, alignment=TA_RIGHT, leading=11),
            )

            q_row = Table(
                [[num_tbl, Paragraph(qt, s['q']), marks_para]],
                colWidths=[8 * mm, CW - 8 * mm - 18 * mm, 18 * mm],
            )
            q_row.setStyle(TableStyle([
                ('VALIGN',        (0, 0), (-1, -1), 'TOP'),
                ('TOPPADDING',    (0, 0), (-1, -1), 0),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 0),
                ('LEFTPADDING',   (0, 0), (-1, -1), 2),
                ('RIGHTPADDING',  (0, 0), (-1, -1), 2),
            ]))

            block = [q_row]

            if qtype in ('mcq', 'fitb'):
                opt_rows = []
                for lbl in ('A', 'B', 'C', 'D'):
                    opt = q.get('option_' + lbl) or q.get('option' + lbl) or ''
                    if opt:
                        opt_rows.append([
                            Paragraph(f'<b>{lbl}</b>', ParagraphStyle('OL',
                                fontName='Helvetica-Bold', fontSize=9, textColor=tc,
                                alignment=TA_CENTER, leading=13)),
                            Paragraph(_safe(opt), s['op']),
                        ])
                if opt_rows:
                    half = len(opt_rows) // 2 + len(opt_rows) % 2
                    left_opts  = opt_rows[:half]
                    right_opts = opt_rows[half:]
                    while len(right_opts) < len(left_opts):
                        right_opts.append([Paragraph('', s['op']), Paragraph('', s['op'])])
                    combined = [[lo[0], lo[1], ro[0], ro[1]]
                                for lo, ro in zip(left_opts, right_opts)]
                    opt_tbl = Table(combined, colWidths=[6 * mm, CW * 0.42, 6 * mm, CW * 0.42])
                    opt_tbl.setStyle(TableStyle([
                        ('TOPPADDING',    (0, 0), (-1, -1), 2),
                        ('BOTTOMPADDING', (0, 0), (-1, -1), 2),
                        ('LEFTPADDING',   (0, 0), (-1, -1), 3),
                        ('RIGHTPADDING',  (0, 0), (-1, -1), 3),
                        ('VALIGN',        (0, 0), (-1, -1), 'MIDDLE'),
                        ('BACKGROUND',    (0, 0), (-1, -1), GRAY_BG),
                    ]))
                    block.append(Spacer(1, 1 * mm))
                    block.append(opt_tbl)

            elif qtype == 'tf':
                tf_tbl = Table(
                    [[Paragraph('<b>○ True</b>', ParagraphStyle('TF',
                          fontName='Helvetica-Bold', fontSize=10,
                          textColor=TEXT_MID, alignment=TA_CENTER)),
                      Paragraph('<b>○ False</b>', ParagraphStyle('TF2',
                          fontName='Helvetica-Bold', fontSize=10,
                          textColor=TEXT_MID, alignment=TA_CENTER))]],
                    colWidths=[CW * 0.3, CW * 0.3],
                )
                tf_tbl.setStyle(TableStyle([
                    ('TOPPADDING',    (0, 0), (-1, -1), 5),
                    ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
                    ('LEFTPADDING',   (0, 0), (-1, -1), 10),
                    ('BOX',           (0, 0), (0, 0), 0.75, BORDER),
                    ('BOX',           (1, 0), (1, 0), 0.75, BORDER),
                    ('BACKGROUND',    (0, 0), (-1, -1), GRAY_BG),
                ]))
                block.append(Spacer(1, 1 * mm))
                block.append(tf_tbl)

            elif qtype in ('sa', 'desc'):
                for _ in range(3 if qtype == 'sa' else 5):
                    block.append(DotLine(CW - 8 * mm))

            block.append(Spacer(1, 4 * mm))
            story.append(KeepTogether(block))
            gn += 1

        story.append(Spacer(1, 3 * mm))

    return story


# ── Build answer key story ────────────────────────────────────────────────────

def _build_answer_key_story(questions, s):
    story = [PageBreak(), Spacer(1, 4 * mm)]

    title_tbl = Table(
        [[Paragraph('Answer Key', ParagraphStyle('AKH',
            fontName='Helvetica-Bold', fontSize=14, textColor=WHITE,
            alignment=TA_CENTER, leading=18))]],
        colWidths=[CW],
    )
    title_tbl.setStyle(TableStyle([
        ('BACKGROUND',    (0, 0), (0, 0), BRAND),
        ('TOPPADDING',    (0, 0), (0, 0), 8),
        ('BOTTOMPADDING', (0, 0), (0, 0), 8),
    ]))
    story.append(title_tbl)
    story.append(Spacer(1, 4 * mm))

    cw = [9 * mm,  CW * 0.37,  CW * 0.45,  12 * mm]
    header = [
        Paragraph('<b>#</b>',       s['nm']),
        Paragraph('<b>Question</b>', s['nm']),
        Paragraph('<b>Answer</b>',   s['nm']),
        Paragraph('<b>Marks</b>',    s['nm']),
    ]
    rows = [header]
    for idx, q in enumerate(questions, 1):
        qt  = _safe(q.get('question') or q.get('question_text') or '')
        ans = _safe(q.get('correct_answer') or q.get('answer') or '—')
        mks = q.get('marks', 1)
        qd  = (qt[:90] + '…') if len(qt) > 90 else qt
        rows.append([
            Paragraph(f'<b>{idx}</b>', s['ak_q']),
            Paragraph(qd,  s['ak_q']),
            Paragraph(ans, s['ak_a']),
            Paragraph(str(mks), s['ak_q']),
        ])

    tbl = Table(rows, colWidths=cw, repeatRows=1)
    tbl.setStyle(TableStyle([
        ('BACKGROUND',     (0, 0), (-1, 0), BRAND),
        ('TEXTCOLOR',      (0, 0), (-1, 0), WHITE),
        ('FONTNAME',       (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE',       (0, 0), (-1, 0), 9),
        ('TOPPADDING',     (0, 0), (-1, 0), 7),
        ('BOTTOMPADDING',  (0, 0), (-1, 0), 7),
        ('FONTSIZE',       (0, 1), (-1, -1), 8.5),
        ('TOPPADDING',     (0, 1), (-1, -1), 5),
        ('BOTTOMPADDING',  (0, 1), (-1, -1), 5),
        ('LEFTPADDING',    (0, 0), (-1, -1), 6),
        ('RIGHTPADDING',   (0, 0), (-1, -1), 6),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [WHITE, GRAY_BG]),
        ('GRID',           (0, 0), (-1, -1), 0.4, BORDER),
        ('BOX',            (0, 0), (-1, -1), 1.2, BRAND),
        ('ALIGN',          (0, 0), (0, -1), 'CENTER'),
        ('ALIGN',          (3, 0), (3, -1), 'CENTER'),
        ('VALIGN',         (0, 0), (-1, -1), 'TOP'),
        ('BACKGROUND',     (2, 1), (2, -1), GREEN_LITE),
        ('LINEBEFORE',     (2, 1), (2, -1), 1.5, GREEN),
    ]))
    story.append(tbl)
    return story


# ══════════════════════════════════════════════════════════════════════════════
#  PAGE VIEWS
# ══════════════════════════════════════════════════════════════════════════════

@login_required
def hierarchy_view(request):
    courses = get_visible_queryset(HierarchyCourse, request.user)
    print("courses",courses)
    return render(request, 'masters/hierarchy_view.html', {'courses': courses})


@login_required
def question_generation(request):
    courses = get_visible_queryset(HierarchyCourse, request.user)
    print("courses",courses)
    return render(request, 'question_generation/question_generation.html', {'courses': courses})


@login_required
def question_paper(request):
    """Render the question paper builder page (load from DB)."""
    courses = get_visible_queryset(HierarchyCourse, request.user)
    return render(request, 'question_generation/question_paper.html', {'courses': courses})


# ══════════════════════════════════════════════════════════════════════════════
#  AJAX: Hierarchy Filter Dropdowns  (unchanged)
# ══════════════════════════════════════════════════════════════════════════════

@require_GET
@login_required
def ajax_get_legs(request):
    course_id = request.GET.get('course_id')
    legs = []
    if course_id:
        legs = list(get_visible_queryset(Leg, request.user).filter(course_id=course_id).values('id', 'name'))
    return JsonResponse({'data': legs})


@require_GET
@login_required
def ajax_get_subjects(request):
    leg_id = request.GET.get('leg_id')
    subjects = []
    if leg_id:
        subjects = list(get_visible_queryset(Subject, request.user).filter(leg_id=leg_id).values('id', 'name'))
    return JsonResponse({'data': subjects})


@require_GET
@login_required
def ajax_get_chapters(request):
    subject_id = request.GET.get('subject_id')
    chapters = []
    if subject_id:
        chapters = list(get_visible_queryset(Chapter, request.user).filter(subject_id=subject_id).values('id', 'title'))
    return JsonResponse({'data': chapters})


@require_GET
@login_required
def ajax_get_topics(request):
    chapter_id = request.GET.get('chapter_id')
    topics = []
    if chapter_id:
        topics = list(get_visible_queryset(Topic, request.user).filter(chapter_id=chapter_id).values('id', 'title'))
    return JsonResponse({'data': topics})


@require_GET
@login_required
def ajax_get_sections(request):
    topic_id = request.GET.get('topic_id')
    sections = []
    if topic_id:
        sections = list(get_visible_queryset(Section, request.user).filter(topic_id=topic_id).values('id', 'title'))
    return JsonResponse({'data': sections})


# ══════════════════════════════════════════════════════════════════════════════
#  AJAX: Document List
#  ROLE: admin/superadmin → all docs | student/instructor → only their uploads
# ══════════════════════════════════════════════════════════════════════════════
@require_GET
@login_required
def ajax_get_hierarchy_data(request):
    course_id = request.GET.get('course')

    mappings = DocumentCourseMapping.objects.select_related(
        'document', 'course', 'leg', 'subject', 'chapter', 'topic', 'section'
    )

    if course_id:
        mappings = mappings.filter(course_id=course_id)

    for key, field in [('leg', 'leg_id'), ('subject', 'subject_id'),
                       ('chapter', 'chapter_id'), ('topic', 'topic_id'),
                       ('section', 'section_id')]:
        val = request.GET.get(key)
        if val:
            mappings = mappings.filter(**{field: val})

    # ── ROLE FILTER (unchanged from your original) ────────────────────────
    role = _get_role(request.user)
    if role in ('superadmin', 'admin'):
        pass  # see everything
    else:
        # instructor AND student both: own uploads + admin/superadmin uploads
        from django.contrib.auth import get_user_model
        User = get_user_model()
        admin_user_ids = User.objects.filter(
            profile__role__name__in=('superadmin', 'admin')
        ).values_list('id', flat=True)
        mappings = mappings.filter(
            Q(document__uploaded_by=request.user) |
            Q(document__uploaded_by_id__in=admin_user_ids)
        )

    table_data, seen = [], set()
    for m in mappings:
        doc = m.document
        if doc.id in seen:
            continue
        seen.add(doc.id)
        if m.section:   sl = 'Section'
        elif m.topic:   sl = 'Topic'
        elif m.chapter: sl = 'Chapter'
        elif m.subject: sl = 'Subject'
        elif m.leg:     sl = 'Leg'
        else:           sl = 'Course'
        table_data.append({
            'id':            doc.id,
            'document_name': doc.document_name,
            'pdf_url':       doc.document_file.url if doc.document_file else None,
            'source_level':  sl,
            'course':        m.course.name   if m.course   else '',
            'leg':           m.leg.name      if m.leg      else '',
            'subject':       m.subject.name  if m.subject  else '',
            'chapter':       m.chapter.title if m.chapter  else '',
            'topic':         m.topic.title   if m.topic    else '',
            'section':       m.section.title if m.section  else '',
            'uploaded_by':   (doc.uploaded_by.get_full_name() or doc.uploaded_by.username)
                             if doc.uploaded_by else '—',
        })
    return JsonResponse({'data': table_data, 'total_count': len(table_data)})


# ══════════════════════════════════════════════════════════════════════════════
#  AJAX: Keyword Search
#  ROLE: admin/superadmin → search all chunks | student → only their docs
# ══════════════════════════════════════════════════════════════════════════════
@require_GET
@login_required
def ajax_search_documents(request):
    keyword = request.GET.get('keyword', '').strip()

    if keyword:
        chunk_q = Q()
        for word in keyword.split()[:4]:
            chunk_q &= Q(chunk__icontains=word)
        chunk_qs = DocumentChunk.objects.filter(chunk_q)
    else:
        chunk_qs = DocumentChunk.objects.all()

    # ── ROLE FILTER on chunks ─────────────────────────────────────────────
    role = _get_role(request.user)
    if role not in ('superadmin', 'admin'):
        from django.contrib.auth import get_user_model
        User = get_user_model()
        admin_user_ids = User.objects.filter(
            profile__role__name__in=('superadmin', 'admin')
        ).values_list('id', flat=True)
        chunk_qs = chunk_qs.filter(
            Q(document__uploaded_by=request.user) |
            Q(document__uploaded_by_id__in=admin_user_ids)
        )

    matching_doc_ids = chunk_qs.values_list('document_id', flat=True).distinct()

    if not matching_doc_ids.exists():
        return JsonResponse({'data': [], 'total_count': 0})

    mappings = DocumentCourseMapping.objects.select_related(
        'document', 'course', 'leg', 'subject', 'chapter', 'topic', 'section'
    ).filter(document_id__in=matching_doc_ids)

    for key, field in [('course', 'course_id'), ('leg', 'leg_id'),
                       ('subject', 'subject_id'), ('chapter', 'chapter_id'),
                       ('topic', 'topic_id'), ('section', 'section_id')]:
        val = request.GET.get(key)
        if val:
            mappings = mappings.filter(**{field: val})

    data, seen = [], set()
    for m in mappings:
        doc = m.document
        if doc.id in seen:
            continue
        seen.add(doc.id)
        if m.section:   sl = 'Section'
        elif m.topic:   sl = 'Topic'
        elif m.chapter: sl = 'Chapter'
        elif m.subject: sl = 'Subject'
        elif m.leg:     sl = 'Leg'
        else:           sl = 'Course'
        data.append({
            'id':            doc.id,
            'document_name': doc.document_name,
            'pdf_url':       doc.document_file.url if doc.document_file else None,
            'source_level':  sl,
            'course':        m.course.name   if m.course   else '',
            'leg':           m.leg.name      if m.leg      else '',
            'subject':       m.subject.name  if m.subject  else '',
            'chapter':       m.chapter.title if m.chapter  else '',
            'topic':         m.topic.title   if m.topic    else '',
            'section':       m.section.title if m.section  else '',
            'uploaded_by':   (doc.uploaded_by.get_full_name() or doc.uploaded_by.username)
                             if doc.uploaded_by else '—',
        })
    return JsonResponse({'data': data, 'total_count': len(data)})


def _extract_keyword_pages(pdf_path: str, keyword: str) -> str:
    """
    Return concatenated text of ONLY the pages that contain the keyword.
    Falls back to full document if no pages match.
    """
    import PyPDF2, re
    matched_pages = []
    words = [w.lower() for w in keyword.split() if w]

    try:
        with open(pdf_path, 'rb') as f:
            reader = PyPDF2.PdfReader(f)
            for page in reader.pages:
                text = page.extract_text() or ''
                lower_text = text.lower()
                if all(w in lower_text for w in words):
                    matched_pages.append(text)
    except Exception:
        pass                    # handled by caller

    if matched_pages:
        return '\n\n'.join(matched_pages)
    return ''                   # caller falls back to full doc / chunks

# ══════════════════════════════════════════════════════════════════════════════
#  AJAX: Generate Questions
#  ROLE: students can only generate from documents THEY uploaded
# ══════════════════════════════════════════════════════════════════════════════

@require_POST
@login_required
def generate_questions(request):
    try:
        body = json.loads(request.body)
    except (json.JSONDecodeError, AttributeError):
        return JsonResponse({'status': 'error', 'message': 'Invalid JSON payload.'}, status=400)

    documents      = body.get('documents', [])
    total_marks    = body.get('total_marks', 0)
    question_types = body.get('question_types', [])
    keyword        = (body.get('keyword') or '').strip()
    difficulty     = (body.get('difficulty') or 'medium').strip().lower()

    if difficulty not in ('easy', 'medium', 'hard'):
        difficulty = 'medium'

    service = QuestionGenerationService(request.user)
    is_valid, error_msg = service.validate_request(documents, total_marks, question_types)
    if not is_valid:
        return JsonResponse({'status': 'error', 'message': error_msg}, status=400)

    try:
        all_generated = []
        gen_ctx       = {'documents': []}
        elevated      = _is_elevated(request.user)

        for doc_sel in documents:
            doc_id    = doc_sel.get('id')
            doc_name  = doc_sel.get('name', 'Document')
            pages_str = (doc_sel.get('pages') or '').strip()

            try:
                doc = UploadDocument.objects.get(id=doc_id)
            except UploadDocument.DoesNotExist:
                service.log_generation(doc_id, 'error', 0, 0, 'failed', f'Doc {doc_id} not found')
                continue

            if not elevated:
                from django.contrib.auth import get_user_model
                User = get_user_model()
                admin_user_ids = set(
                    User.objects.filter(
                        profile__role__name__in=('superadmin', 'admin')
                    ).values_list('id', flat=True)
                )
                doc_owner_id = doc.uploaded_by_id if doc.uploaded_by else None
                is_own       = (doc.uploaded_by == request.user)
                is_admin_doc = (doc_owner_id in admin_user_ids)
                if not is_own and not is_admin_doc:
                    service.log_generation(doc_id, 'error', 0, 0, 'failed', 'Access denied')
                    continue

            all_chunks = DocumentChunk.objects.filter(
                document=doc
            ).order_by('chunk_index')

            if keyword:
                matched_chunks = _filter_chunks_by_keyword(all_chunks, keyword)
                if matched_chunks:
                    doc_text  = '\n\n'.join(
                        f"[Page {c.chunk_index}]\n{c.chunk}"
                        for c in matched_chunks
                    )
                    page_info = f"keyword-matched pages: {[c.chunk_index for c in matched_chunks]}"
                else:
                    doc_text  = '\n\n'.join(c.chunk for c in all_chunks)
                    page_info = "all pages (keyword not found in any page)"

            elif pages_str:
                selected_page_nums = _parse_page_range(pages_str)
                if selected_page_nums:
                    page_chunks = all_chunks.filter(chunk_index__in=selected_page_nums)
                    if page_chunks.exists():
                        doc_text  = '\n\n'.join(
                            f"[Page {c.chunk_index}]\n{c.chunk}"
                            for c in page_chunks
                        )
                        page_info = f"selected pages: {sorted(selected_page_nums)}"
                    else:
                        doc_text  = '\n\n'.join(c.chunk for c in all_chunks)
                        page_info = "all pages (selected pages not found in chunks)"
                else:
                    doc_text  = '\n\n'.join(c.chunk for c in all_chunks)
                    page_info = "all pages (invalid page range)"

            else:
                doc_text  = '\n\n'.join(c.chunk for c in all_chunks)
                page_info = "all pages"

            if not doc_text.strip():
                service.log_generation(
                    doc_id, 'error', 0, 0, 'failed',
                    f'No text content found for doc {doc_id} ({page_info})'
                )
                continue

            print(f"[Doc {doc_id}] Using {page_info} | text length: {len(doc_text)}")

            gen_ctx['documents'].append({
                'id':        doc_id,
                'name':      doc_name,
                'text':      doc_text,
                'page_info': page_info,
            })

        if not gen_ctx['documents']:
            return JsonResponse({
                'status':  'error',
                'message': 'No valid or accessible documents found.',
            }, status=400)

        # ── Instantiate LLM once, then generate per document ──────────────
        llm        = LLMFactory.create()
        pipeline   = QuestionGenerationPipeline(llm_provider=llm)
        total_docs = len(gen_ctx['documents'])

        for doc_index, doc_data in enumerate(gen_ctx['documents']):
            combined    = f"[From: {doc_data['name']}]\n{doc_data['text']}"
            is_last_doc = (doc_index == total_docs - 1)

            for qt in question_types:
                qtype       = qt['type']
                total_count = qt['count']

                # ── Distribute count evenly across documents ───────────────
                # Last doc gets the remainder to avoid losing questions to rounding
                base_count = total_count // total_docs
                remainder  = total_count % total_docs
                count      = base_count + (remainder if is_last_doc else 0)

                if count == 0:
                    continue

                prompt = service.generate_prompts_for_type(
                    qtype, count, difficulty=difficulty, keyword=keyword
                )
                try:
                    raw    = pipeline.generate_batch(combined, prompt)
                    parsed = service.parse_generated_questions(raw, qtype, request.user)
                    for q in parsed:
                        q['type_name']   = service.QUESTION_TYPES[qtype]['name']
                        q['source_docs'] = doc_data['name']
                        q['difficulty']  = difficulty
                    all_generated.extend(parsed)
                    service.log_generation(
                        doc_data['id'], qtype, count, len(parsed), 'completed'
                    )
                except Exception as e:
                    print(f'Error generating {qtype} for doc {doc_data["id"]}: {e}')
                    service.log_generation(
                        doc_data['id'], qtype, count, 0, 'failed', str(e)
                    )

        marks_dist = service.calculate_marks_distribution(total_marks, question_types)

        return JsonResponse({
            'status':  'success',
            'message': f'Generated {len(all_generated)} question(s)',
            'data': {
                'questions':           all_generated,
                'total_marks':         total_marks,
                'marks_distribution':  marks_dist,
                'summary':             service.get_summary(),
                'documents_processed': len(gen_ctx['documents']),
                'timestamp':           timezone.now().isoformat(),
            }
        })

    except Exception as e:
        import traceback; traceback.print_exc()
        return JsonResponse(
            {'status': 'error', 'message': f'Generation failed: {str(e)}'},
            status=500
        )
        
        
def _parse_page_range(pages_str: str) -> set:
    """
    Convert a user-entered page range string into a set of integers.

    Examples:
        "1-5, 8, 10-12"  →  {1, 2, 3, 4, 5, 8, 10, 11, 12}
        "3"              →  {3}
        ""               →  set()
    """
    pages = set()
    parts = pages_str.replace(';', ',').split(',')
    for part in parts:
        part = part.strip()
        if not part:
            continue
        if '-' in part:
            try:
                start, end = part.split('-', 1)
                start, end = int(start.strip()), int(end.strip())
                if start <= end:
                    pages.update(range(start, end + 1))
            except ValueError:
                pass   # ignore malformed range
        else:
            try:
                pages.add(int(part))
            except ValueError:
                pass
    return pages

def _extract_pdf_text(pdf_path: str) -> str:
    text = ''
    with open(pdf_path, 'rb') as f:
        reader = PyPDF2.PdfReader(f)
        for page in reader.pages:
            t = page.extract_text()
            if t:
                text += t + '\n\n'
    return text.strip()


# ══════════════════════════════════════════════════════════════════════════════
#  GENERATE PAPER PDF  (unchanged — logging already per-user)
# ══════════════════════════════════════════════════════════════════════════════

# @require_POST
# @login_required
# def generate_paper_pdf(request):
#     """
#     Full function — replace the existing one in views.py wholesale.
#     The PDF-generation logic is identical; the only addition is
#     populating QuestionPaperLog.source_documents_fk after log creation.
#     """
#     try:
#         body = json.loads(request.body)
#     except Exception:
#         return JsonResponse({'status': 'error', 'message': 'Invalid JSON'}, status=400)
 
#     questions    = body.get('questions', [])
#     total_marks  = int(body.get('total_marks', 50) or 50)
#     title        = (body.get('title', '') or 'Question Paper').strip() or 'Question Paper'
#     duration     = int(body.get('duration', 120) or 120)
#     instructions = (body.get('instructions', '') or '').strip()
#     inc_answers  = body.get('include_answers', True)
#     school       = body.get('school', '') or ''
 
#     if not questions:
#         return JsonResponse({'status': 'error', 'message': 'No questions provided'}, status=400)
 
#     try:
#         # ── (All your existing PDF-build imports live at the top of views.py) ─
#         from question_generation.views import (
#             _make_styles, _build_paper_story, _build_answer_key_story, PaperCanvas
#         )
#         from reportlab.platypus import SimpleDocTemplate
#         from reportlab.lib.pagesizes import A4
#         from reportlab.lib.units import mm
 
#         ML = 17 * mm; MR = 17 * mm; MT = 14 * mm; MB = 14 * mm
 
#         s        = _make_styles()
#         date_str = timezone.now().strftime('%d %b %Y')
#         buf      = BytesIO()
 
#         doc = SimpleDocTemplate(
#             buf, pagesize=A4,
#             leftMargin=ML, rightMargin=MR,
#             topMargin=MT + 30 * mm,
#             bottomMargin=MB + 10 * mm,
#         )
 
#         story = _build_paper_story(questions, total_marks, duration, instructions, s)
#         if inc_answers:
#             story += _build_answer_key_story(questions, s)
 
#         doc.build(
#             story,
#             canvasmaker=lambda *a, **kw: PaperCanvas(
#                 *a,
#                 paper_title=title,
#                 total_marks=total_marks,
#                 duration=duration,
#                 date_str=date_str,
#                 school=school,
#                 **kw
#             )
#         )
 
#         buf.seek(0)
 
#         # ── Create log entry and populate M2M (NEW) ───────────────────────────
#         try:
#             # Collect every unique source-doc name from all questions in the paper
#             all_source_names: set[str] = set()
#             for q in questions:
#                 raw = q.get('source_docs') or []
#                 if isinstance(raw, list):
#                     all_source_names.update(n for n in raw if n)
 
#             log = QuestionPaperLog.objects.create(
#                 user            = request.user,
#                 paper_name      = title,
#                 total_questions = len(questions),
#                 total_marks     = total_marks,
#             )
 
#             # Populate M2M — single bulk query to resolve names → objects
#             if all_source_names:
#                 log_doc_map  = _resolve_docs_by_name(list(all_source_names))
#                 log_doc_objs = list(log_doc_map.values())
#                 if log_doc_objs:
#                     log.source_documents_fk.set(log_doc_objs)
 
#         except Exception as log_err:
#             import logging
#             logging.getLogger(__name__).warning('[PaperLog] Could not save log: %s', log_err)
 
#         safe = title.replace(' ', '_').replace('/', '-')[:60]
#         return FileResponse(
#             buf,
#             as_attachment=True,
#             filename=f'{safe}.pdf',
#             content_type='application/pdf',
#         )
 
#     except Exception as e:
#         import traceback; traceback.print_exc()
#         return JsonResponse({'status': 'error', 'message': f'PDF failed: {str(e)}'}, status=500)
 
@require_POST
@login_required
def generate_paper_pdf(request):
    try:
        body = json.loads(request.body)
    except Exception:
        return JsonResponse({'status': 'error', 'message': 'Invalid JSON'}, status=400)

    questions    = body.get('questions', [])
    total_marks  = int(body.get('total_marks', 50) or 50)
    title        = (body.get('title', '') or 'Question Paper').strip() or 'Question Paper'
    duration     = int(body.get('duration', 120) or 120)
    instructions = (body.get('instructions', '') or '').strip()
    inc_answers  = body.get('include_answers', True)
    school       = body.get('school', '') or ''

    # The frontend should send source_doc_ids: [1, 2, 3] alongside questions.
    # Fall back to extracting from per-question source_doc_ids fields.
    source_doc_ids = body.get('source_doc_ids', [])

    if not questions:
        return JsonResponse({'status': 'error', 'message': 'No questions provided'}, status=400)

    try:
        from question_generation.views import (
            _make_styles, _build_paper_story, _build_answer_key_story, PaperCanvas
        )
        from reportlab.platypus import SimpleDocTemplate
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.units import mm

        ML = 17 * mm; MR = 17 * mm; MT = 14 * mm; MB = 14 * mm

        s        = _make_styles()
        date_str = timezone.now().strftime('%d %b %Y')
        buf      = BytesIO()

        doc = SimpleDocTemplate(
            buf, pagesize=A4,
            leftMargin=ML, rightMargin=MR,
            topMargin=MT + 30 * mm,
            bottomMargin=MB + 10 * mm,
        )

        story = _build_paper_story(questions, total_marks, duration, instructions, s)
        if inc_answers:
            story += _build_answer_key_story(questions, s)

        doc.build(
            story,
            canvasmaker=lambda *a, **kw: PaperCanvas(
                *a,
                paper_title=title,
                total_marks=total_marks,
                duration=duration,
                date_str=date_str,
                school=school,
                **kw
            )
        )

        buf.seek(0)

        # ── Log entry with ID-based M2M ───────────────────────────────────────
        try:
            # Collect IDs from top-level field OR from per-question source_doc_ids
            all_ids: set[int] = set()

            for raw_id in source_doc_ids:
                try:
                    all_ids.add(int(raw_id))
                except (TypeError, ValueError):
                    pass

            # Also scrape per-question source_doc_ids if the frontend sends them
            for q in questions:
                for raw_id in (q.get('source_doc_ids') or []):
                    try:
                        all_ids.add(int(raw_id))
                    except (TypeError, ValueError):
                        pass

            log = QuestionPaperLog.objects.create(
                user            = request.user,
                paper_name      = title,
                total_questions = len(questions),
                total_marks     = total_marks,
            )

            if all_ids:
                doc_objs = list(UploadDocument.objects.filter(id__in=all_ids))
                if doc_objs:
                    log.source_documents_fk.set(doc_objs)

        except Exception as log_err:
            import logging
            logging.getLogger(__name__).warning('[PaperLog] Could not save log: %s', log_err)

        safe = title.replace(' ', '_').replace('/', '-')[:60]
        return FileResponse(
            buf,
            as_attachment=True,
            filename=f'{safe}.pdf',
            content_type='application/pdf',
        )

    except Exception as e:
        import traceback; traceback.print_exc()
        return JsonResponse({'status': 'error', 'message': f'PDF failed: {str(e)}'}, status=500)

# ══════════════════════════════════════════════════════════════════════════════
#  SAVE QUESTION BANK  (unchanged — always saves under request.user)
# ══════════════════════════════════════════════════════════════════════════════
@require_POST
@login_required
def save_question_bank(request):
    try:
        body = json.loads(request.body)
    except Exception:
        return JsonResponse({'status': 'error', 'message': 'Invalid JSON'}, status=400)
 
    questions   = body.get('questions', [])
    total_marks = body.get('total_marks', 50)
    source_docs = body.get('source_docs', [])          # list of {name, id, …}
    keyword     = (body.get('keyword') or '').strip() or None
 
    if not questions:
        return JsonResponse({'status': 'error', 'message': 'No questions to save'}, status=400)
 
    source_doc_names = [d.get('name', '') for d in source_docs if d.get('name')]
    doc_name_map     = _resolve_docs_by_name(source_doc_names)   # {name: UploadDocument}
    bank_doc_objs    = list(doc_name_map.values())
 
    # ── Auto-generate title / description ─────────────────────────────────────
    now      = timezone.now()
    doc_part = ', '.join(source_doc_names[:2])
    auto_title = (
        f"Q-Bank {now.strftime('%d %b %Y %H:%M')}"
        + (f' — {doc_part}' if doc_part else '')
    )
    doc_names_str = ', '.join(source_doc_names) if source_doc_names else 'N/A'
    auto_desc = (
        f"Auto-saved {now.strftime('%d %b %Y %H:%M')}. "
        f"Sources: {doc_names_str}. "
        f"By: {request.user.get_full_name() or request.user.username}"
    )
 
    try:
        # ── Create the bank ───────────────────────────────────────────────────
        bank = QuestionBank.objects.create(
            title=auto_title,
            description=auto_desc,
            bank_type='bank',
            created_by=request.user,
            uploaded_by=request.user,
            total_marks=total_marks,
            keyword=keyword,
        )
 
        # ── Populate M2M on the bank (NEW) ────────────────────────────────────
        if bank_doc_objs:
            bank.source_documents_fk.set(bank_doc_objs)
 
        # ── Save individual questions ─────────────────────────────────────────
        created = 0
        skipped = 0

        for q_data in questions:
            try:
                q_text = q_data.get('question') or q_data.get('question_text') or ''

                # ── Normalize source_docs: backend now returns a string, not a list ──
                raw_sources = q_data.get('source_docs', [])
                if isinstance(raw_sources, str):
                    q_sources = [raw_sources] if raw_sources else []
                elif isinstance(raw_sources, list):
                    q_sources = [s for s in raw_sources if s]
                else:
                    q_sources = []

                # ── Duplicate check ───────────────────────────────────────────
                dup_qs = Question.objects.filter(question_text=q_text)
                is_dup = False
                if dup_qs.exists():
                    for existing_q in dup_qs:
                        try:
                            existing_sources = json.loads(existing_q.source_documents or '[]')
                        except Exception:
                            existing_sources = []
                        if not q_sources or not existing_sources or set(q_sources) & set(existing_sources):
                            is_dup = True
                            break
                if is_dup:
                    skipped += 1
                    continue

                # ── Create Question ───────────────────────────────────────────
                q_obj = Question.objects.create(
                    bank=bank,
                    question_text=q_text,
                    question_type=q_data.get('question_type', 'mcq'),
                    option_a=q_data.get('option_A') or q_data.get('option_a'),
                    option_b=q_data.get('option_B') or q_data.get('option_b'),
                    option_c=q_data.get('option_C') or q_data.get('option_c'),
                    option_d=q_data.get('option_D') or q_data.get('option_d'),
                    correct_answer=q_data.get('correct_answer') or q_data.get('answer') or '',
                    marks=q_data.get('marks', 1),
                    difficulty=q_data.get('difficulty', 'medium'),
                    source_documents=json.dumps(q_sources),
                )

                # ── Populate M2M FK on the question ──────────────────────────
                if q_sources:
                    q_doc_map  = _resolve_docs_by_name(q_sources)
                    q_doc_objs = list(q_doc_map.values())
                    if q_doc_objs:
                        q_obj.source_documents_fk.set(q_doc_objs)

                created += 1

            except Exception as e:
                import logging
                logging.getLogger(__name__).error('Error saving question: %s', e)   
 
        bank.update_statistics()
 
        msg = f'✓ Saved {created} question(s)'
        if skipped:
            msg += f' · {skipped} duplicate(s) skipped'
 
        return JsonResponse({
            'status':            'success',
            'message':           msg,
            'bank_id':           bank.id,
            'questions_saved':   created,
            'questions_skipped': skipped,
            'title':             auto_title,
        })
 
    except Exception as e:
        import traceback; traceback.print_exc()
        return JsonResponse({'status': 'error', 'message': f'Save failed: {str(e)}'}, status=500)

# import json
# from django.utils import timezone
# from django.http import JsonResponse
# from django.views.decorators.http import require_POST
# from django.contrib.auth.decorators import login_required

# # Assuming QuestionBank, Question, and _resolve_docs_by_id are imported/available

# from django.http import JsonResponse
# from django.utils import timezone
# from django.contrib.auth.decorators import login_required
# from django.views.decorators.http import require_POST
# import json


# from django.http import JsonResponse
# from django.views.decorators.http import require_POST
# from django.contrib.auth.decorators import login_required
# from django.utils import timezone
# import json


# def _resolve_docs_by_id(doc_ids):
#     from .models import UploadDocument
#     docs = UploadDocument.objects.filter(id__in=doc_ids)
#     return {doc.id: doc for doc in docs}


# @require_POST
# @login_required
# def save_question_bank(request):
#     try:
#         body = json.loads(request.body)
#     except Exception:
#         return JsonResponse({'status': 'error', 'message': 'Invalid JSON'}, status=400)

#     questions   = body.get('questions', [])
#     total_marks = body.get('total_marks', 50)
#     source_docs = body.get('source_docs', [])
#     keyword     = (body.get('keyword') or '').strip() or None

#     if not questions:
#         return JsonResponse({'status': 'error', 'message': 'No questions to save'}, status=400)

#     # ── Resolve BANK documents ─────────────────────────────
#     bank_doc_ids = [d.get('id') for d in source_docs if isinstance(d, dict) and d.get('id')]
#     doc_id_map   = _resolve_docs_by_id(bank_doc_ids)
#     bank_doc_objs = list(doc_id_map.values())

#     # SAFE name extraction
#     source_doc_names = []
#     for d in source_docs:
#         if isinstance(d, dict):
#             name = d.get('name') or d.get('document_name')
#             if name:
#                 source_doc_names.append(str(name).split(',')[0].strip())

#     now = timezone.now()

#     auto_title = (
#         f"Q-Bank {now.strftime('%d %b %Y %H:%M')}"
#         + (f" — {', '.join(source_doc_names[:2])}" if source_doc_names else "")
#     )

#     auto_desc = (
#         f"Auto-saved {now.strftime('%d %b %Y %H:%M')}. "
#         f"Sources: {', '.join(source_doc_names) if source_doc_names else 'N/A'}. "
#         f"By: {request.user.get_full_name() or request.user.username}"
#     )

#     try:
#         # ── Create Question Bank ─────────────────────────────
#         bank = QuestionBank.objects.create(
#             title=auto_title,
#             description=auto_desc,
#             bank_type='bank',
#             created_by=request.user,
#             uploaded_by=request.user,
#             total_marks=total_marks,
#             keyword=keyword,
#         )

#         if bank_doc_objs:
#             bank.source_documents_fk.set(bank_doc_objs)

#         created = 0
#         skipped = 0

#         # ────────────────────────────────────────────────────
#         for q_data in questions:
#             try:
#                 q_text = q_data.get('question') or q_data.get('question_text') or ''

#                 if not q_text.strip():
#                     skipped += 1
#                     continue

#                 # ── Resolve QUESTION documents ───────────────
#                 q_src_ids = [
#                     d.get('id')
#                     for d in (q_data.get('source_doc_objects') or [])
#                     if isinstance(d, dict) and d.get('id')
#                 ]

#                 q_src_names = q_data.get('source_docs', [])

#                 if q_src_ids:
#                     q_doc_map = _resolve_docs_by_id(q_src_ids)
#                     q_doc_objs = list(q_doc_map.values())
#                 elif bank_doc_objs:
#                     q_doc_objs = bank_doc_objs
#                 else:
#                     q_doc_objs = []

#                 # ── STRICT SINGLE NAME EXTRACTION ────────────
#                 first_name_only = ""

#                 if q_doc_objs:
#                     first_name_only = (q_doc_objs[0].document_name or "").strip()

#                 elif q_src_names:
#                     first_item = q_src_names[0]

#                     if isinstance(first_item, dict):
#                         first_item = first_item.get('name') or first_item.get('document_name') or ''

#                     first_name_only = str(first_item).split(',')[0].strip()

#                 elif source_doc_names:
#                     first_name_only = str(source_doc_names[0]).split(',')[0].strip()

#                 # FINAL SAFETY
#                 if first_name_only:
#                     first_name_only = first_name_only.split(',')[0].strip()
#                     single_doc_name_list = [first_name_only]
#                 else:
#                     single_doc_name_list = []

#                 # ── DUPLICATE CHECK ─────────────────────────
#                 dup_qs = Question.objects.filter(question_text=q_text)
#                 is_dup = False

#                 if dup_qs.exists():
#                     for existing_q in dup_qs:
#                         try:
#                             existing_sources = json.loads(existing_q.source_documents or '[]')
#                         except Exception:
#                             existing_sources = []

#                         existing_first = existing_sources[0] if existing_sources else None
#                         current_first = single_doc_name_list[0] if single_doc_name_list else None

#                         if existing_first == current_first:
#                             is_dup = True
#                             break

#                 if is_dup:
#                     skipped += 1
#                     continue

#                 # ── CREATE QUESTION ─────────────────────────
#                 q_obj = Question.objects.create(
#                     bank=bank,
#                     question_text=q_text,
#                     question_type=q_data.get('question_type', 'mcq'),
#                     option_a=q_data.get('option_A') or q_data.get('option_a'),
#                     option_b=q_data.get('option_B') or q_data.get('option_b'),
#                     option_c=q_data.get('option_C') or q_data.get('option_c'),
#                     option_d=q_data.get('option_D') or q_data.get('option_d'),
#                     correct_answer=q_data.get('correct_answer') or q_data.get('answer') or '',
#                     marks=q_data.get('marks', 1),
#                     difficulty=q_data.get('difficulty', 'medium'),
#                     source_documents=json.dumps(single_doc_name_list),
#                 )

#                 # ── Assign FK ───────────────────────────────
#                 if q_doc_objs:
#                     q_obj.source_documents_fk.set(q_doc_objs)

#                 # 🔥 CRITICAL FIX: FORCE SINGLE VALUE AFTER FK
#                 q_obj.source_documents = json.dumps(single_doc_name_list)
#                 q_obj.save(update_fields=['source_documents'])

#                 # DEBUG
#                 q_obj.refresh_from_db()
#                 print("FINAL DB VALUE:", q_obj.source_documents)

#                 created += 1

#             except Exception as e:
#                 import logging
#                 logging.getLogger(__name__).error('Error saving question: %s', e)

#         # ── Update stats ───────────────────────────────────
#         bank.update_statistics()

#         msg = f'✓ Saved {created} question(s)'
#         if skipped:
#             msg += f' · {skipped} duplicate(s) skipped'

#         return JsonResponse({
#             'status': 'success',
#             'message': msg,
#             'bank_id': bank.id,
#             'questions_saved': created,
#             'questions_skipped': skipped,
#             'title': auto_title,
#         })

#     except Exception as e:
#         import traceback
#         traceback.print_exc()
#         return JsonResponse(
#             {'status': 'error', 'message': f'Save failed: {str(e)}'},
#             status=500
#         )
        
# ══════════════════════════════════════════════════════════════════════════════
#  EXPORT BANK PDF
#  ROLE: admin can export any bank | student can only export their own
# ══════════════════════════════════════════════════════════════════════════════

def _filter_chunks_by_keyword(all_chunks, keyword: str):
    """
    Returns a QuerySet of chunks matching the keyword.

    Strategy (in priority order):
      1. Exact phrase match:  chunk ILIKE '%law of inertia%'
         → finds pages where the whole phrase appears together
      2. All-words AND match: chunk ILIKE '%law%' AND chunk ILIKE '%inertia%'
         → only used as fallback if exact phrase returns nothing

    Why this matters:
      "law of inertia" split into ["law", "of", "inertia"] with AND logic
      matches ANY page containing all three words separately — so a page
      discussing "the law of thermodynamics" with the word "inertia" elsewhere
      would match even though the phrase never appears.
    """
    keyword_stripped = keyword.strip()
    if not keyword_stripped:
        return all_chunks.none()

    # ── Step 1: exact phrase search ───────────────────────────────────────────
    exact_matches = all_chunks.filter(chunk__icontains=keyword_stripped)

    if exact_matches.exists():
        return exact_matches

    # ── Step 2: fallback — every individual word must be present ─────────────
    # (handles misspellings or phrase split across sentences)
    words = [w for w in keyword_stripped.split() if len(w) > 2]  # skip tiny words like "of", "a"
    if not words:
        words = keyword_stripped.split()  # if all words are tiny, use them anyway

    word_q = Q()
    for word in words:
        word_q &= Q(chunk__icontains=word)

    word_matches = all_chunks.filter(word_q)

    if word_matches.exists():
        return word_matches

    # ── Step 3: nothing found ─────────────────────────────────────────────────
    return all_chunks.none()

@require_POST
@login_required
def export_bank_pdf(request):
    try:
        body = json.loads(request.body)
        bank_id     = body.get('bank_id')
        export_type = body.get('export_type', 'paper')
    except Exception:
        return JsonResponse({'status': 'error', 'message': 'Invalid JSON'}, status=400)

    try:
        bank = QuestionBank.objects.get(id=bank_id)

        # ── ROLE CHECK ───────────────────────────────────────────────────────
        if not _is_elevated(request.user) and bank.created_by != request.user:
            return JsonResponse({'status': 'error',
                                 'message': 'Access denied: this bank belongs to another user.'}, status=403)
        # ─────────────────────────────────────────────────────────────────────

        questions = bank.questions.all()
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.lib.units import inch
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
        from reportlab.lib import colors
        from reportlab.lib.enums import TA_CENTER

        pdf_buffer = BytesIO()
        doc_rl = SimpleDocTemplate(pdf_buffer, pagesize=A4)
        story  = []
        styles = getSampleStyleSheet()

        from reportlab.lib.styles import ParagraphStyle as PS
        title_style = PS('CustomTitle', parent=styles['Heading1'],
                         fontSize=18, textColor=colors.HexColor('#1C4D8D'),
                         spaceAfter=12, alignment=TA_CENTER, fontName='Helvetica-Bold')

        story.append(Paragraph(bank.title, title_style))
        story.append(Spacer(1, 0.1 * inch))

        normal_style = styles['Normal']
        for idx, question in enumerate(questions, 1):
            story.append(Paragraph(f'<b>{idx}. {question.question_text}</b>', normal_style))
            if question.question_type in ['mcq', 'fitb']:
                for lbl, val in [('A', question.option_a), ('B', question.option_b),
                                  ('C', question.option_c), ('D', question.option_d)]:
                    if val:
                        story.append(Paragraph(f'{lbl}) {val}', normal_style))
            story.append(Spacer(1, 0.05 * inch))

        if export_type in ['paper_answer', 'answers_only']:
            story.append(PageBreak())
            story.append(Paragraph('Answer Key', title_style))
            answer_data = [['Q.', 'Answer', 'Marks']]
            for idx, question in enumerate(questions, 1):
                answer_data.append([str(idx), question.correct_answer, str(question.marks)])
            answer_table = Table(answer_data)
            answer_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1C4D8D')),
                ('TEXTCOLOR',  (0, 0), (-1, 0), colors.whitesmoke),
                ('GRID',       (0, 0), (-1, -1), 1, colors.grey),
            ]))
            story.append(answer_table)

        doc_rl.build(story)

        pdf_buffer.seek(0)
        from django.core.files.base import ContentFile
        pdf_content = pdf_buffer.getvalue()
        
        QuestionBankExport.objects.create(
            bank=bank,
            export_type=export_type,
            created_by=request.user,
            pdf_file=ContentFile(pdf_content, name=f"{bank.title}_{export_type}.pdf")
        )

        pdf_buffer.seek(0)
        return FileResponse(pdf_buffer, as_attachment=True,
                            filename=f'{bank.title}.pdf',
                            content_type='application/pdf')

    except QuestionBank.DoesNotExist:
        return JsonResponse({'status': 'error', 'message': 'Question bank not found'}, status=404)
    except Exception as e:
        import traceback; traceback.print_exc()
        return JsonResponse({'status': 'error', 'message': str(e)}, status=500)


# ══════════════════════════════════════════════════════════════════════════════
#  QUESTION BANK LIST
#  ROLE: admin → all banks | student → only their own
# ══════════════════════════════════════════════════════════════════════════════
@login_required
def question_bank_list(request):
    if _is_elevated(request.user):
        banks = QuestionBank.objects.all().select_related('created_by', 'course')
    else:
        banks = QuestionBank.objects.filter(created_by=request.user).select_related('created_by', 'course')

    # Build a doc_name → course_name lookup from DocumentCourseMapping
    from question_generation.models import UploadDocument
    doc_course_map = {}
    for mapping in DocumentCourseMapping.objects.select_related('course', 'document').filter(course__isnull=False):
        doc_course_map[mapping.document.document_name] = mapping.course.name

    data = []
    for b in banks:
        # Try direct FK first, then resolve via source docs of questions
        course_name = b.course.name if b.course else ''

        if not course_name:
            # Look at first question's source_documents to find course
            first_q = b.questions.first()
            if first_q and first_q.source_documents:
                try:
                    src_docs = json.loads(first_q.source_documents)
                    for doc_name in src_docs:
                        if doc_name in doc_course_map:
                            course_name = doc_course_map[doc_name]
                            break
                except Exception:
                    pass

        data.append({
            'id':              b.id,
            'title':           b.title,
            'type':            b.get_bank_type_display(),
            'total_questions': b.total_questions,
            'total_marks':     b.total_marks,
            'created_at':      b.created_at.strftime('%d/%m/%Y %H:%M'),
            'course':          course_name,
            'created_by':      b.created_by.get_full_name() or b.created_by.username,
            'keyword':         b.keyword or '',
        })
    return JsonResponse({'status': 'success', 'data': data})

# ══════════════════════════════════════════════════════════════════════════════
#  QUESTION BANK DETAIL
#  ROLE: admin → any bank | student → only their own
# ══════════════════════════════════════════════════════════════════════════════

@login_required
def question_bank_detail(request, bank_id):
    try:
        if _is_elevated(request.user):
            bank = QuestionBank.objects.get(id=bank_id)
        else:
            bank = QuestionBank.objects.get(id=bank_id, created_by=request.user)


        q_data = [{
            'id':             q.id,
            'question':       q.question_text,
            'type':           q.question_type,
            'option_A':       q.option_a,
            'option_B':       q.option_b,
            'option_C':       q.option_c,
            'option_D':       q.option_d,
            'correct_answer': q.correct_answer,
            'marks':          q.marks,
            'difficulty':     q.difficulty,
            'source_documents': q.source_documents or '[]',   # ← ADD THIS
        } for q in bank.questions.all()]

        return JsonResponse({
            'status': 'success',
            'bank': {
                'id':              bank.id,
                'title':           bank.title,
                'description':     bank.description,
                'total_marks':     bank.total_marks,
                'total_questions': bank.total_questions,
                'created_by':      bank.created_by.get_full_name() or bank.created_by.username,
                'keyword':         bank.keyword or '',       # ← ADD THIS
            },
            'questions': q_data,
        })
    except QuestionBank.DoesNotExist:
        return JsonResponse({'status': 'error',
                             'message': 'Bank not found or access denied.'}, status=404)


# ══════════════════════════════════════════════════════════════════════════════
#  LOAD QUESTIONS FROM DB  (Question Paper Builder)
#  ROLE: admin → all banks/questions | student → only their own banks
# ══════════════════════════════════════════════════════════════════════════════

@require_POST
@login_required
def ajax_load_questions_from_db(request):
    try:
        body = json.loads(request.body)
    except Exception:
        return JsonResponse({'status': 'error', 'message': 'Invalid JSON'}, status=400)

    diff_filter    = body.get('difficulty', [])
    kw_filter      = (body.get('keyword') or '').strip()
    document_ids   = body.get('document_ids', [])
    question_types = body.get('question_types', [])
    total_marks    = body.get('total_marks', 50)

    if not document_ids:
        return JsonResponse({'status': 'error', 'message': 'No documents selected.'}, status=400)

    # Coerce all incoming IDs to int safely
    clean_doc_ids = []
    for d in document_ids:
        try:
            clean_doc_ids.append(int(d))
        except (TypeError, ValueError):
            pass

    if not clean_doc_ids:
        return JsonResponse({'status': 'error', 'message': 'No valid document IDs provided.'}, status=400)

    try:
        elevated = _is_elevated(request.user)

        # Verify the selected documents exist (and optionally scope to user)
        selected_docs = UploadDocument.objects.filter(id__in=clean_doc_ids)
        if not elevated:
            # Non-admin users may only load from docs they own OR admin-uploaded docs
            from django.contrib.auth import get_user_model
            User = get_user_model()
            admin_user_ids = set(
                User.objects.filter(
                    profile__role__name__in=('superadmin', 'admin')
                ).values_list('id', flat=True)
            )
            selected_docs = selected_docs.filter(
                Q(uploaded_by=request.user) |
                Q(uploaded_by_id__in=admin_user_ids)
            )
            if not selected_docs.exists():
                return JsonResponse({
                    'status':  'error',
                    'message': 'Access denied: you can only load questions from documents you uploaded.',
                }, status=403)

        # Final set of allowed doc IDs after permission check
        allowed_doc_ids = set(selected_docs.values_list('id', flat=True))

        # ── Fetch questions linked to these docs via M2M (source_documents_fk) ──
        # Scope banks to the current user unless elevated
        if elevated:
            bank_qs = QuestionBank.objects.all()
        else:
            bank_qs = QuestionBank.objects.filter(created_by=request.user)

        # Questions whose source_documents_fk overlaps with the selected doc IDs
        question_qs = Question.objects.filter(
            bank__in=bank_qs,
            source_documents_fk__id__in=allowed_doc_ids,
        ).select_related('bank', 'bank__created_by').prefetch_related('source_documents_fk')

        if question_types:
            question_qs = question_qs.filter(question_type__in=question_types)

        # Deduplicate (the M2M join can produce duplicates when a question links
        # to several of the selected documents)
        question_qs = question_qs.distinct()

        all_questions = []
        banks_loaded  = set()

        for q in question_qs:
            banks_loaded.add(q.bank_id)

            # Build source-doc info from M2M (authoritative)
            src_doc_ids   = list(q.source_documents_fk.values_list('id', flat=True))
            src_doc_names = list(q.source_documents_fk.values_list('document_name', flat=True))

            all_questions.append({
                'id':             q.id,
                'question_text':  q.question_text,
                'question':       q.question_text,
                'question_type':  q.question_type,
                'option_A':       q.option_a,
                'option_B':       q.option_b,
                'option_C':       q.option_c,
                'option_D':       q.option_d,
                'correct_answer': q.correct_answer,
                'answer':         q.correct_answer,
                'marks':          q.marks,
                'difficulty':     q.difficulty,
                'source_docs':    src_doc_names,      # human-readable list
                'source_doc_ids': src_doc_ids,        # numeric IDs for downstream use
                'bank_title':     q.bank.title,
                'bank_id':        q.bank_id,
                'created_by':     q.bank.created_by.get_full_name() or q.bank.created_by.username,
            })

        # ── Fallback: if no results via M2M, try matching on the legacy
        #    source_documents JSON text field so old records still work ──────────
        if not all_questions:
            doc_names_for_fallback = list(
                UploadDocument.objects.filter(id__in=allowed_doc_ids)
                .values_list('document_name', flat=True)
            )

            fallback_qs = Question.objects.filter(bank__in=bank_qs)
            if question_types:
                fallback_qs = fallback_qs.filter(question_type__in=question_types)
            fallback_qs = fallback_qs.select_related('bank', 'bank__created_by')

            seen_ids = set()
            for q in fallback_qs:
                if q.id in seen_ids:
                    continue
                q_sources = []
                if q.source_documents:
                    try:
                        q_sources = json.loads(q.source_documents)
                    except Exception:
                        pass
                if not q_sources:
                    continue
                if not any(s in doc_names_for_fallback for s in q_sources):
                    continue
                seen_ids.add(q.id)
                banks_loaded.add(q.bank_id)
                all_questions.append({
                    'id':             q.id,
                    'question_text':  q.question_text,
                    'question':       q.question_text,
                    'question_type':  q.question_type,
                    'option_A':       q.option_a,
                    'option_B':       q.option_b,
                    'option_C':       q.option_c,
                    'option_D':       q.option_d,
                    'correct_answer': q.correct_answer,
                    'answer':         q.correct_answer,
                    'marks':          q.marks,
                    'difficulty':     q.difficulty,
                    'source_docs':    q_sources,
                    'source_doc_ids': [],   # unknown for legacy records
                    'bank_title':     q.bank.title,
                    'bank_id':        q.bank_id,
                    'created_by':     q.bank.created_by.get_full_name() or q.bank.created_by.username,
                })

        # ── Apply difficulty filter ────────────────────────────────────────────
        if diff_filter:
            all_questions = [q for q in all_questions if q.get('difficulty') in diff_filter]

        # ── Apply keyword filter ───────────────────────────────────────────────
        if kw_filter:
            kw_lower = kw_filter.lower()
            def matches_keyword(q):
                fields = [
                    q.get('question_text', ''),
                    q.get('option_A', '') or '',
                    q.get('option_B', '') or '',
                    q.get('option_C', '') or '',
                    q.get('option_D', '') or '',
                    q.get('correct_answer', '') or '',
                ]
                return any(kw_lower in str(f).lower() for f in fields)
            all_questions = [q for q in all_questions if matches_keyword(q)]

        return JsonResponse({
            'status': 'success',
            'data': {
                'questions':   all_questions,
                'total':       len(all_questions),
                'banks_count': len(banks_loaded),
                'total_marks': total_marks,
                'scope':       'all_users' if elevated else 'my_data',
            }
        })

    except Exception as e:
        import traceback; traceback.print_exc()
        return JsonResponse({'status': 'error', 'message': str(e)}, status=500)

        
# ══════════════════════════════════════════════════════════════════════════════
#  PAPER LOG STATS
#  ROLE: admin → all users (or filter by ?user_id=) | student → own only
# ══════════════════════════════════════════════════════════════════════════════

@login_required
def paper_log_stats(request):
    from question_generation.models import QuestionPaperLog
    from django.db.models import Count, Sum

    elevated = _is_elevated(request.user)

    if elevated:
        uid = request.GET.get('user_id')
        if uid:
            from django.contrib.auth import get_user_model
            User = get_user_model()
            try:
                target_user = User.objects.get(pk=uid)
                logs = QuestionPaperLog.objects.filter(user=target_user)
                scope = f'user:{target_user.username}'
            except User.DoesNotExist:
                return JsonResponse({'status': 'error', 'message': 'User not found'}, status=404)
        else:
            logs  = QuestionPaperLog.objects.all()
            scope = 'all_users'
    else:
        logs  = QuestionPaperLog.objects.filter(user=request.user)
        scope = f'user:{request.user.username}'

    agg = logs.aggregate(
        total_papers=Count('id'),
        total_questions=Sum('total_questions'),
        total_marks=Sum('total_marks'),
    )

    recent = list(logs.values('id', 'paper_name', 'total_questions',
                               'total_marks', 'created_at')[:10])
    for r in recent:
        r['created_at'] = r['created_at'].strftime('%d %b %Y %H:%M')

    return JsonResponse({
        'status': 'success',
        'scope':  scope,
        'stats': {
            'total_papers':    agg['total_papers']    or 0,
            'total_questions': agg['total_questions'] or 0,
            'total_marks':     agg['total_marks']     or 0,
        },
        'recent_papers': recent,
    })


# ══════════════════════════════════════════════════════════════════════════════
#  MISC HELPERS (unchanged)
# ══════════════════════════════════════════════════════════════════════════════

@require_POST
@login_required
def save_generated_questions(request):
    try:
        body      = json.loads(request.body)
        questions = body.get('questions', [])
        if not questions:
            return JsonResponse({'status': 'error', 'message': 'No questions to save'}, status=400)
        return JsonResponse({'status': 'success', 'message': f'Saved {len(questions)} question(s)',
                             'count': len(questions)})
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)}, status=500)


@require_POST
@login_required
def export_questions_pdf(request):
    try:
        body        = json.loads(request.body)
        questions   = body.get('questions', [])
        total_marks = body.get('total_marks', 0)
        if not questions:
            return JsonResponse({'status': 'error', 'message': 'No questions to export'}, status=400)
        return JsonResponse({'status': 'success', 'message': 'PDF generated'})
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)}, status=500)
    
    
    
def access_denied(request):
    print('hiiiiiii')
    return render(request, 'access_denied.html', status=403)







"""
ADD THIS to question_generation/views.py

1. Add to imports at top of views.py:
   import pandas as pd
   from docx import Document as DocxDocument
   from docx.shared import Pt, RGBColor
   from docx.enum.text import WD_ALIGN_PARAGRAPH

2. Add to urls.py:
   path('export/<str:file_type>/', views.export_questions, name='export_questions'),

3. Install if not already:
   pip install python-docx openpyxl xlsxwriter pandas
"""

import pandas as pd
from docx import Document as DocxDocument
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx import Document as DocxDocument
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from django.http import HttpResponse

@require_POST
@login_required
def export_questions(request, file_type):
    try:
        body        = json.loads(request.body)
        questions   = body.get('questions', [])
        paper_title = (body.get('paper_title') or 'Questions').strip()
        total_marks = body.get('total_marks', 0)

        if not questions:
            return HttpResponse("No questions provided!", status=400)

        # ── build safe filename ───────────────────────────────────────────────
        difficulty  = (questions[0].get('difficulty') or 'medium')
        safe_title  = paper_title.replace(' ', '_').replace('/', '-')[:40]

        # ── question type label map ───────────────────────────────────────────
        type_map = {
            'mcq':  'Multiple Choice Questions',
            'tf':   'True / False',
            'fitb': 'Fill in the Blanks',
            'sa':   'Short Answer',
            'desc': 'Descriptive',
        }

        # ══════════════════════════════════════════════════════════════════════
        #  TEXT
        # ══════════════════════════════════════════════════════════════════════
        if file_type == 'text':
            text_lines = []

            for idx, q in enumerate(questions, 1):
                qtype  = (q.get('question_type') or '').lower()
                q_text = q.get('question') or q.get('question_text') or ''
                answer = q.get('correct_answer') or q.get('answer') or ''

                text_lines.append(f"{idx}. {q_text}")

                if qtype in ('one-liner', 'descriptive', 'sa', 'desc'):
                    text_lines.append(f"Answer: {answer}")
                else:
                    options = [('A', q.get('option_A')), ('B', q.get('option_B')),
                            ('C', q.get('option_C')), ('D', q.get('option_D'))]
                    for opt_label, opt_text in options:
                        if opt_text:
                            prefix = f"{opt_label}."
                            if answer == opt_label:
                                text_lines.append(f"*{prefix} {opt_text}")
                            else:
                                text_lines.append(f"{prefix} {opt_text}")

                text_lines.append("")

            stream = BytesIO()
            stream.write("\n".join(text_lines).encode("utf-8"))
            stream.seek(0)

            return FileResponse(
                stream,
                as_attachment=True,
                filename=f"{safe_title}_{difficulty}.txt",
                content_type="text/plain"
            )

        # ══════════════════════════════════════════════════════════════════════
        #  EXCEL
        # ══════════════════════════════════════════════════════════════════════
        elif file_type == 'excel':
            rows = []
            for i, q in enumerate(questions, 1):
                qtype = (q.get('question_type') or '').lower()
                rows.append({
                    "SR_NO":       i,
                    "QUESTION":    q.get('question') or q.get('question_text') or '',
                    "A":           q.get('option_A') or q.get('optionA') or '',
                    "B":           q.get('option_B') or q.get('optionB') or '',
                    "C":           q.get('option_C') or q.get('optionC') or '',
                    "D":           q.get('option_D') or q.get('optionD') or '',
                    "CORRECT_ANS": q.get('correct_answer') or q.get('answer') or '',
                    "TYPE":        type_map.get(qtype, qtype.upper()),
                    "MARKS":       q.get('marks', 1),
                    "DIFFICULTY":  q.get('difficulty', difficulty),
                })

            df = pd.DataFrame(rows)
            stream = BytesIO()
            with pd.ExcelWriter(stream, engine="xlsxwriter") as writer:
                df.to_excel(writer, index=False, sheet_name="Questions")

                # ── basic column width formatting ─────────────────────────────
                ws = writer.sheets["Questions"]
                col_widths = {
                    "SR_NO": 6, "QUESTION": 55, "A": 25, "B": 25,
                    "C": 25,    "D": 25,         "CORRECT_ANS": 14,
                    "TYPE": 22, "MARKS": 7,       "DIFFICULTY": 10,
                }
                for col_num, col_name in enumerate(df.columns):
                    ws.set_column(col_num, col_num, col_widths.get(col_name, 15))

            stream.seek(0)
            return FileResponse(
                stream,
                as_attachment=True,
                filename=f"{safe_title}_{difficulty}.xlsx",
                content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )

        # ══════════════════════════════════════════════════════════════════════
        #  WORD  (.docx)  — same layout as text export, nicely formatted
        # ══════════════════════════════════════════════════════════════════════
        elif file_type == 'word':
            doc = DocxDocument()

            # ── document title ────────────────────────────────────────────────
            title_para = doc.add_heading(paper_title, level=0)
            title_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
            title_run = title_para.runs[0]
            title_run.font.color.rgb = RGBColor(0x1C, 0x4D, 0x8D)  # brand blue

            # ── subtitle: total marks + difficulty ────────────────────────────
            sub = doc.add_paragraph()
            sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
            sub_run = sub.add_run(f"Total Marks: {total_marks}   |   Difficulty: {difficulty.capitalize()}")
            sub_run.font.size   = Pt(11)
            sub_run.font.italic = True
            sub_run.font.color.rgb = RGBColor(0x4A, 0x55, 0x68)

            doc.add_paragraph()  # spacer

            for idx, q in enumerate(questions, 1):
                qtype  = (q.get('question_type') or '').lower()
                q_text = q.get('question') or q.get('question_text') or ''
                answer = q.get('correct_answer') or q.get('answer') or ''
                marks  = q.get('marks', 1)

                # ── question line ─────────────────────────────────────────────
                q_para = doc.add_paragraph()
                q_run  = q_para.add_run(f"Q{idx}. {q_text}")
                q_run.font.bold = True
                q_run.font.size = Pt(11)

                # marks badge on same para
                marks_run = q_para.add_run(f"  [{marks} mark{'s' if int(marks) != 1 else ''}]")
                marks_run.font.size  = Pt(9)
                marks_run.font.color.rgb = RGBColor(0x94, 0xA3, 0xB8)

                if qtype in ('sa', 'desc'):
                    ans_para = doc.add_paragraph()
                    ans_run  = ans_para.add_run(f"Answer: {answer}")
                    ans_run.font.italic = True
                    ans_run.font.color.rgb = RGBColor(0x2E, 0xCC, 0x8D)  # green
                    ans_run.font.size = Pt(10)

                elif qtype == 'tf':
                    for tf_opt in [('A', 'True'), ('B', 'False')]:
                        lbl, val = tf_opt
                        opt_para = doc.add_paragraph(style='List Bullet')
                        is_correct = (answer in ('A', 'True', 'true') and lbl == 'A') or \
                                     (answer in ('B', 'False', 'false') and lbl == 'B')
                        opt_run = opt_para.add_run(f"{lbl}.  {val}")
                        opt_run.font.size = Pt(10)
                        if is_correct:
                            opt_run.font.bold  = True
                            opt_run.font.color.rgb = RGBColor(0x2E, 0xCC, 0x8D)

                else:
                    # mcq / fitb
                    for lbl in ('A', 'B', 'C', 'D'):
                        opt = q.get(f'option_{lbl}') or q.get(f'option{lbl}') or ''
                        if not opt:
                            continue
                        opt_para = doc.add_paragraph(style='List Bullet')
                        opt_run  = opt_para.add_run(f"{lbl}.  {opt}")
                        opt_run.font.size = Pt(10)
                        if answer == lbl:
                            opt_run.font.bold  = True
                            opt_run.font.color.rgb = RGBColor(0x2E, 0xCC, 0x8D)  # correct = green

                doc.add_paragraph()  # blank line between questions

            # ── save to stream ────────────────────────────────────────────────
            stream = BytesIO()
            doc.save(stream)
            stream.seek(0)

            return FileResponse(
                stream,
                as_attachment=True,
                filename=f"{safe_title}_{difficulty}.docx",
                content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            )

        else:
            return HttpResponse("Invalid export type. Use: text | excel | word", status=400)

    except Exception as e:
        import traceback; traceback.print_exc()
        return JsonResponse({'error': str(e)}, status=500)
    
    
    
    
    
    
    
    
from django.contrib.auth import get_user_model


# ══════════════════════════════════════════════════════════════════════════════
#  PAGE VIEW
# ══════════════════════════════════════════════════════════════════════════════

@login_required
def question_bank_explorer(request):
    """
    Render the Question Bank Explorer page.
    Context:
      courses      — queryset for the Course filter dropdown
      is_elevated  — True for admin/superadmin
    """
    courses = get_visible_queryset(HierarchyCourse, request.user)
    return render(request, 'question_generation/question_bank_explorer.html', {
        'courses':     courses,
        'is_elevated': _is_elevated(request.user),
    })


# ══════════════════════════════════════════════════════════════════════════════
#  AJAX: Update a single question
#  ROLE: admin can edit any question | student can only edit questions in banks
#        they created
# ══════════════════════════════════════════════════════════════════════════════

@require_POST
@login_required
def ajax_update_question(request):
    try:
        body = json.loads(request.body)
    except Exception:
        return JsonResponse({'status': 'error', 'message': 'Invalid JSON'}, status=400)

    question_id = body.get('question_id')
    if not question_id:
        return JsonResponse({'status': 'error', 'message': 'question_id required'}, status=400)

    try:
        question = Question.objects.select_related('bank').get(id=question_id)
    except Question.DoesNotExist:
        return JsonResponse({'status': 'error', 'message': 'Question not found'}, status=404)

    # ── ROLE CHECK ────────────────────────────────────────────────────────────
    if not _is_elevated(request.user) and question.bank.created_by != request.user:
        return JsonResponse(
            {'status': 'error', 'message': 'Access denied: you can only edit questions in your own banks.'},
            status=403
        )

    # ── Apply updates ─────────────────────────────────────────────────────────
    new_text = (body.get('question_text') or '').strip()
    if not new_text:
        return JsonResponse({'status': 'error', 'message': 'question_text cannot be empty'}, status=400)

    question.question_text  = new_text
    question.option_a       = body.get('option_a') or None
    question.option_b       = body.get('option_b') or None
    question.option_c       = body.get('option_c') or None
    question.option_d       = body.get('option_d') or None
    question.correct_answer = (body.get('correct_answer') or '').strip()
    question.marks          = max(1, min(100, int(body.get('marks', 1) or 1)))
    question.difficulty     = body.get('difficulty', 'medium') or 'medium'
    question.save()

    # Refresh bank statistics
    try:
        question.bank.update_statistics()
    except Exception:
        pass

    return JsonResponse({
        'status':  'success',
        'message': 'Question updated successfully.',
        'question': {
            'id':             question.id,
            'question_text':  question.question_text,
            'question_type':  question.question_type,
            'option_a':       question.option_a,
            'option_b':       question.option_b,
            'option_c':       question.option_c,
            'option_d':       question.option_d,
            'correct_answer': question.correct_answer,
            'marks':          question.marks,
            'difficulty':     question.difficulty,
        }
    })


# ══════════════════════════════════════════════════════════════════════════════
#  AJAX: Delete a single question
#  ROLE: admin can delete any | student can only delete their own bank questions
# ══════════════════════════════════════════════════════════════════════════════

@require_POST
@login_required
def ajax_delete_question(request):
    try:
        body = json.loads(request.body)
    except Exception:
        return JsonResponse({'status': 'error', 'message': 'Invalid JSON'}, status=400)

    question_id = body.get('question_id')
    if not question_id:
        return JsonResponse({'status': 'error', 'message': 'question_id required'}, status=400)

    try:
        question = Question.objects.select_related('bank').get(id=question_id)
    except Question.DoesNotExist:
        return JsonResponse({'status': 'error', 'message': 'Question not found'}, status=404)

    # ── ROLE CHECK ────────────────────────────────────────────────────────────
    if not _is_elevated(request.user) and question.bank.created_by != request.user:
        return JsonResponse(
            {'status': 'error', 'message': 'Access denied: you can only delete questions in your own banks.'},
            status=403
        )

    bank = question.bank
    question.delete()

    try:
        bank.update_statistics()
    except Exception:
        pass

    return JsonResponse({'status': 'success', 'message': 'Question deleted.'})


# ══════════════════════════════════════════════════════════════════════════════
#  AJAX: List all users (for admin filter dropdown)
#  ROLE: admin/superadmin only
# ══════════════════════════════════════════════════════════════════════════════

@require_GET
@login_required
def ajax_get_users(request):
    if not _is_elevated(request.user):
        return JsonResponse({'status': 'error', 'message': 'Access denied.'}, status=403)

    User = get_user_model()
    users = User.objects.filter(is_active=True).order_by('first_name', 'username')
    data = []
    for u in users:
        full = u.get_full_name() or u.username
        data.append({'username': u.username, 'full_name': full, 'id': u.id,    'role': _get_role(u),   # ← add this
})

    return JsonResponse({'status': 'success', 'data': data})



@require_GET
@login_required
def ajax_doc_course_map(request):
    """
    Returns {document_name: [course_name, ...]} mapping ALL courses
    a document is linked to (directly or via leg/subject/chapter/topic/section).
    
    Since DocumentCourseMapping ALWAYS has a course FK (it's required/non-null),
    every single mapping row gives us a doc→course relationship regardless of
    whether the mapping also has leg/subject/chapter/topic/section set.
    """
    result = {}  # doc_name → set of course names
    
    for m in DocumentCourseMapping.objects.select_related(
        'course', 'document'
    ).filter(course__isnull=False):
        doc_name = m.document.document_name
        course_name = m.course.name
        if doc_name not in result:
            result[doc_name] = []
        if course_name not in result[doc_name]:
            result[doc_name].append(course_name)
    
    return JsonResponse({'status': 'success', 'data': result})

@require_POST
@login_required
def check_document_questions(request):
    """
    Check if the current user already has questions generated
    from any of the selected documents.
    Returns: {has_existing: bool, doc_names: [...], total_count: int}

    Uses source_documents_fk (M2M by ID) as the primary lookup.
    Falls back to the legacy source_documents JSON text field for
    older records that pre-date the M2M field.
    """
    try:
        body = json.loads(request.body)
    except Exception:
        return JsonResponse({'status': 'error', 'message': 'Invalid JSON'}, status=400)

    # Coerce incoming doc IDs to int safely
    raw_doc_ids = [d.get('id') for d in body.get('documents', []) if d.get('id')]
    clean_doc_ids = []
    for d in raw_doc_ids:
        try:
            clean_doc_ids.append(int(d))
        except (TypeError, ValueError):
            pass

    if not clean_doc_ids:
        return JsonResponse({'has_existing': False, 'total_count': 0, 'doc_names': []})

    # Verify the doc IDs actually exist in the DB
    existing_docs = UploadDocument.objects.filter(id__in=clean_doc_ids)
    if not existing_docs.exists():
        return JsonResponse({'has_existing': False, 'total_count': 0, 'doc_names': []})

    allowed_doc_ids  = set(existing_docs.values_list('id', flat=True))
    # id → name map, used when building the response
    doc_id_to_name   = {doc.id: doc.document_name for doc in existing_docs}

    # Scope banks to the requesting user (admins see all)
    if _is_elevated(request.user):
        user_banks = QuestionBank.objects.all()
    else:
        user_banks = QuestionBank.objects.filter(created_by=request.user)

    # ── Primary: M2M lookup by document ID ───────────────────────────────────
    matching_via_fk = Question.objects.filter(
        bank__in=user_banks,
        source_documents_fk__id__in=allowed_doc_ids,
    ).distinct()

    matched_doc_ids = set(
        matching_via_fk
        .values_list('source_documents_fk__id', flat=True)
        .filter(source_documents_fk__id__in=allowed_doc_ids)
    )
    total_count  = matching_via_fk.count()
    matched_docs = [doc_id_to_name[did] for did in matched_doc_ids if did in doc_id_to_name]

    # ── Fallback: legacy source_documents JSON text field ────────────────────
    # Only run if the M2M lookup found nothing (old records pre-M2M migration)
    if total_count == 0:
        selected_doc_names = list(doc_id_to_name.values())

        fallback_qs = Question.objects.filter(bank__in=user_banks)
        fallback_matched_docs = []
        fallback_count = 0

        for q in fallback_qs.iterator():
            try:
                srcs = json.loads(q.source_documents or '[]')
            except Exception:
                srcs = []
            if any(s in selected_doc_names for s in srcs):
                for s in srcs:
                    if s in selected_doc_names and s not in fallback_matched_docs:
                        fallback_matched_docs.append(s)
                fallback_count += 1

        total_count  = fallback_count
        matched_docs = fallback_matched_docs

    return JsonResponse({
        'has_existing': total_count > 0,
        'total_count':  total_count,
        'doc_names':    matched_docs,
    })