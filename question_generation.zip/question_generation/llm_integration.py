"""
LLM Integration Module for Question Generation
Handles communication with Ollama/LLM APIs for question generation
"""

import requests
import json
from typing import List, Dict, Any
from django.conf import settings


class LLMProvider:
    """Base class for LLM providers"""
    
    def __init__(self, base_url: str, model: str = None):
        self.base_url = base_url.rstrip('/')
        self.model = model or getattr(settings, 'OLLAMA_MODEL', 'mistral')
    
    def generate(self, prompt: str, context: str, **kwargs) -> str:
        """
        Generate response from LLM
        
        Args:
            prompt: System/instruction prompt
            context: Document context/chunks
            **kwargs: Additional parameters
        
        Returns:
            Generated text response
        """
        raise NotImplementedError


class OllamaProvider(LLMProvider):
    """Ollama LLM provider integration"""
    
    def generate(self, prompt: str, context: str, temperature: float = 0.6,
                max_tokens: int = 4096) -> str:
        """
        Generate questions using Ollama API
        
        Args:
            prompt: Instruction prompt
            context: Document chunks context
            temperature: Temperature for generation (0.0-1.0)
            max_tokens: Max tokens in response
        
        Returns:
            Generated text
            
        Raises:
            Exception: If API call fails
        """
        
        # Construct full prompt
        full_prompt = (
            f"{prompt}\n\n"
            f"DOCUMENT CONTEXT:\n"
            f"{context}\n\n"
            f"Generate the questions:"
        )
        
        try:
            response = requests.post(
                f"{self.base_url}/api/generate",
                json={
                    "model": self.model,
                    "prompt": full_prompt,
                    "temperature": temperature,
                    "num_predict": max_tokens,
                    "stream": False
                },
                timeout=300  # 5 minute timeout
            )
            
            if response.status_code != 200:
                raise Exception(f"Ollama API error: {response.status_code}")
            
            data = response.json()
            return data.get('response', '')
        
        except requests.exceptions.ConnectionError:
            raise Exception(f"Cannot connect to Ollama at {self.base_url}")
        except requests.exceptions.Timeout:
            raise Exception("Ollama request timed out (5 minutes)")
        except Exception as e:
            raise Exception(f"Ollama generation failed: {str(e)}")
    
    def stream_generate(self, prompt: str, context: str, 
                       temperature: float = 0.6) -> str:
        """
        Stream-based generation (for long responses)
        
        Args:
            prompt: Instruction prompt
            context: Document context
            temperature: Generation temperature
        
        Yields:
            Text chunks as generated
        """
        
        full_prompt = (
            f"{prompt}\n\n"
            f"DOCUMENT CONTEXT:\n"
            f"{context}\n\n"
            f"Generate the questions:"
        )
        
        try:
            response = requests.post(
                f"{self.base_url}/api/generate",
                json={
                    "model": self.model,
                    "prompt": full_prompt,
                    "temperature": temperature,
                    "stream": True
                },
                stream=True,
                timeout=300
            )
            
            if response.status_code != 200:
                raise Exception(f"Ollama API error: {response.status_code}")
            
            full_response = ""
            for line in response.iter_lines():
                if line:
                    data = json.loads(line)
                    chunk = data.get('response', '')
                    full_response += chunk
                    yield chunk
        
        except Exception as e:
            raise Exception(f"Ollama streaming failed: {str(e)}")


class LLMFactory:
    """Factory for creating LLM provider instances"""
    
    PROVIDERS = {
        'ollama': OllamaProvider,
    }
    
    @staticmethod
    def create(provider: str = 'ollama', 
               base_url: str = None,
               model: str = None) -> LLMProvider:
        """
        Create LLM provider instance
        
        Args:
            provider: Provider name ('ollama', etc.)
            base_url: API base URL
            model: Model name
        
        Returns:
            LLMProvider instance
        
        Raises:
            ValueError: If provider not found
        """
        
        if provider not in LLMFactory.PROVIDERS:
            raise ValueError(f"Unknown provider: {provider}")
        
        base_url = base_url or getattr(settings, 'MODEL_BASE_URL', 'http://localhost:11434')
        model = model or getattr(settings, 'OLLAMA_MODEL', 'mistral')
        
        provider_class = LLMFactory.PROVIDERS[provider]
        return provider_class(base_url, model)


class DocumentChunkManager:
    """Manages document chunks for RAG (Retrieval-Augmented Generation)"""
    
    def __init__(self, chunk_size: int = 1500, overlap: int = 200):
        """
        Initialize chunk manager
        
        Args:
            chunk_size: Characters per chunk
            overlap: Overlap between chunks
        """
        self.chunk_size = chunk_size
        self.overlap = overlap
    
    def chunk_text(self, text: str) -> List[str]:
        """
        Split text into overlapping chunks
        
        Args:
            text: Text to chunk
        
        Returns:
            List of text chunks
        """
        chunks = []
        text = text.strip()
        
        if len(text) <= self.chunk_size:
            return [text]
        
        # Split by sentences for better chunks
        sentences = self._split_sentences(text)
        current_chunk = ""
        
        for sentence in sentences:
            if len(current_chunk) + len(sentence) <= self.chunk_size:
                current_chunk += sentence
            else:
                if current_chunk:
                    chunks.append(current_chunk.strip())
                current_chunk = sentence
        
        if current_chunk:
            chunks.append(current_chunk.strip())
        
        return chunks
    
    def _split_sentences(self, text: str) -> List[str]:
        """Split text into sentences"""
        import re
        # Simple sentence splitter
        sentences = re.split(r'(?<=[.!?])\s+', text)
        return [s for s in sentences if s.strip()]
    
    def select_relevant_chunks(self, chunks: List[str], 
                              query: str, top_k: int = 5) -> List[str]:
        """
        Select most relevant chunks for a query using simple heuristics
        
        Args:
            chunks: List of text chunks
            query: Query/topic
            top_k: Number of top chunks to return
        
        Returns:
            Most relevant chunks
        """
        if len(chunks) <= top_k:
            return chunks
        
        # Simple relevance scoring based on keyword overlap
        query_words = set(query.lower().split())
        scores = []
        
        for chunk in chunks:
            chunk_words = set(chunk.lower().split())
            overlap = len(query_words & chunk_words)
            scores.append((chunk, overlap))
        
        # Sort by score and return top_k
        scores.sort(key=lambda x: x[1], reverse=True)
        return [chunk for chunk, score in scores[:top_k]]
    
    def combine_chunks(self, chunks: List[str], max_length: int = 4000) -> str:
        """
        Combine multiple chunks into single context
        
        Args:
            chunks: List of chunks
            max_length: Maximum combined length
        
        Returns:
            Combined context string
        """
        combined = ""
        
        for chunk in chunks:
            if len(combined) + len(chunk) <= max_length:
                combined += chunk + "\n\n"
            else:
                break
        
        return combined.strip()


class QuestionGenerationPipeline:
    """
    Complete pipeline for generating questions from documents
    """
    
    def __init__(self, llm_provider: LLMProvider = None, 
                 chunk_manager: DocumentChunkManager = None):
        """
        Initialize pipeline
        
        Args:
            llm_provider: LLM provider instance (creates default if None)
            chunk_manager: Chunk manager instance (creates default if None)
        """
        self.llm = llm_provider or LLMFactory.create()
        self.chunks = chunk_manager or DocumentChunkManager()
    
    def generate_batch(self, document_text: str, prompt: str,
                      page_range: tuple = None) -> str:
        """
        Generate questions from document in batch mode
        
        Args:
            document_text: Full document text
            prompt: Generation prompt (from QuestionGenerationService)
            page_range: (start_page, end_page) tuple for filtering
        
        Returns:
            Raw LLM output (questions)
        """
        
        # Chunk the document
        text_chunks = self.chunks.chunk_text(document_text)
        
        # Filter by page range if provided
        if page_range:
            # This is simplified - in practice would need page markers
            text_chunks = text_chunks
        
        # Select relevant chunks
        combined_context = self.chunks.combine_chunks(text_chunks)
        
        # Generate
        output = self.llm.generate(prompt, combined_context)
        
        return output
    
    def generate_streaming(self, document_text: str, prompt: str,
                          callback=None) -> str:
        """
        Generate with streaming output
        
        Args:
            document_text: Document text
            prompt: Generation prompt
            callback: Function to call with each text chunk
        
        Yields/Returns:
            Generated questions
        """
        
        text_chunks = self.chunks.chunk_text(document_text)
        combined_context = self.chunks.combine_chunks(text_chunks)
        
        full_output = ""
        for chunk in self.llm.stream_generate(prompt, combined_context):
            full_output += chunk
            if callback:
                callback(chunk)
            yield chunk
        
        return full_output
