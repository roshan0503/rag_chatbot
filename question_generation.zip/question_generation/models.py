# models.py

from django.db import models
from django.conf import settings
from masters.models import Section,Course,Leg,Topic,Subject,Chapter
from decimal import Decimal
from masters.upload_path import document_upload_path   # ← NEW import

class UploadDocument(models.Model):
    """
    Model 1: Stores uploaded document metadata
    """
    document_name = models.CharField(max_length=500)
 
    # ── NEW: which hierarchy level this file was uploaded at ──────────────
    upload_level = models.CharField(
        max_length=20,
        default='course',
        editable=False,
        help_text="Hierarchy level at which the document was uploaded "
                  "(course / leg / subject / chapter / topic / section)"
    )
    # ─────────────────────────────────────────────────────────────────────
 
    document_file = models.FileField(
        upload_to=document_upload_path,   # ← CHANGED (was 'uploaded_documents/%Y/%m/%d/')
        null=True,
        blank=True
    )
    file_size_mb = models.DecimalField(
        max_digits=10,
        decimal_places=4,
        null=True,
        blank=True,
        help_text="File size in megabytes"
    )
    uploaded_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='uploaded_documents'
    )
    upload_date_time = models.DateTimeField(auto_now_add=True)
 
    class Meta:
        db_table = 'upload_document'
        ordering = ['-upload_date_time']
        verbose_name = 'Upload Document'
        verbose_name_plural = 'Upload Documents'
 
    def __str__(self):
        return f"{self.id} - {self.document_name}"
 
    def save(self, *args, **kwargs):
        """Auto-calculate file_size_mb from the uploaded file if not set"""
        if self.document_file and not self.file_size_mb:
            try:
                size_bytes = self.document_file.size
                self.file_size_mb = Decimal(str(size_bytes)) / Decimal('1048576')
            except Exception:
                self.file_size_mb = Decimal('0.00')
        super().save(*args, **kwargs)
 

from masters.models import *
class DocumentCourseMapping(models.Model):
    course = models.ForeignKey(
        HierarchyCourse,                          # ← direct name
        on_delete=models.CASCADE,
        related_name='document_mappings',
        null=False,
        blank=False,
        help_text='Required. The course this document belongs to.'
    )
    leg = models.ForeignKey(
        Leg,                             # ← direct name
        on_delete=models.CASCADE,
        related_name='document_mappings',
        null=True,
        blank=True,
        help_text='Optional. The leg this document belongs to.'
    )
    subject = models.ForeignKey(
        Subject,                         # ← direct name
        on_delete=models.CASCADE,
        related_name='document_mappings',
        null=True,
        blank=True,
        help_text='Optional. The subject this document belongs to.'
    )
    chapter = models.ForeignKey(
        Chapter,                         # ← direct name
        on_delete=models.CASCADE,
        related_name='document_mappings',
        null=True,
        blank=True,
        help_text='Optional. The chapter this document belongs to.'
    )
    topic = models.ForeignKey(
        Topic,                           # ← direct name
        on_delete=models.CASCADE,
        related_name='document_mappings',
        null=True,
        blank=True,
        help_text='Optional. The topic this document belongs to.'
    )
    section = models.ForeignKey(
        Section,                         # ← direct name
        on_delete=models.CASCADE,
        related_name='document_mappings',
        null=True,
        blank=True,
        help_text='Optional. The section this document belongs to.'
    )
    document = models.ForeignKey(
        UploadDocument,                  # ← direct name
        on_delete=models.CASCADE,
        related_name='course_mappings',
        null=False,
        blank=False,
        help_text='Required. The uploaded document being mapped.'
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'document_course_mapping'
        ordering = ['-created_at']
        verbose_name = 'Document Course Mapping'
        verbose_name_plural = 'Document Course Mappings'
        unique_together = (
            'course', 'leg', 'subject', 'chapter', 'topic', 'section', 'document'
        )

    def __str__(self):
        parts = [f"Course: {self.course}"]
        if self.leg:
            parts.append(f"Leg: {self.leg}")
        if self.subject:
            parts.append(f"Subject: {self.subject}")
        if self.chapter:
            parts.append(f"Chapter: {self.chapter}")
        if self.topic:
            parts.append(f"Topic: {self.topic}")
        if self.section:
            parts.append(f"Section: {self.section}")
        parts.append(f"Doc: {self.document.document_name}")
        return " → ".join(parts)

    def clean(self):
        from django.core.exceptions import ValidationError

        errors = {}

        if self.section and not self.topic:
            errors['topic'] = 'Topic is required when Section is provided.'
        if self.topic and not self.chapter:
            errors['chapter'] = 'Chapter is required when Topic is provided.'
        if self.chapter and not self.subject:
            errors['subject'] = 'Subject is required when Chapter is provided.'
        if self.subject and not self.leg:
            errors['leg'] = 'Leg is required when Subject is provided.'

        if errors:
            raise ValidationError(errors)


class DocumentChunk(models.Model):
    """
    Model 3: Stores chunked text and embeddings for each document.
    
    Used for RAG (Retrieval-Augmented Generation) / vector search.
    """
    document = models.ForeignKey(
        UploadDocument,
        on_delete=models.CASCADE,
        related_name='chunks',
        null=False,
        blank=False,
        help_text='The document this chunk belongs to.'
    )
    chunk_index = models.PositiveIntegerField(
        default=0,
        help_text='Order/index of this chunk within the document.'
    )
    chunk = models.TextField(
        help_text='The text content of this chunk.'
    )
    embeddings = models.TextField(
        null=True,
        blank=True,
        help_text='JSON-serialized embedding vector for this chunk.'
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'document_chunk'
        ordering = ['document', 'chunk_index']
        verbose_name = 'Document Chunk'
        verbose_name_plural = 'Document Chunks'
        unique_together = ('document', 'chunk_index')

    def __str__(self):
        preview = self.chunk[:50] + '...' if len(self.chunk) > 50 else self.chunk
        return f"Doc {self.document_id} | Chunk {self.chunk_index}: {preview}"
    
    
    
    
    """
Models for storing generated questions and question papers
Add these to your question_generation/models.py
"""

from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
from masters.models import Course, Leg, Subject, Chapter, Topic, Section


class QuestionBank(models.Model):
    """
    Stores a collection of questions (a question paper/bank)
    """
    QUESTION_PAPER = 'paper'
    QUESTION_BANK = 'bank'
    TYPE_CHOICES = [
        (QUESTION_PAPER, 'Question Paper'),
        (QUESTION_BANK, 'Question Bank'),
    ]
    
    # Basic Info
    title = models.CharField(max_length=255, help_text="Name of the question paper/bank")
    description = models.TextField(blank=True, null=True, help_text="Description or notes")
    bank_type = models.CharField(
        max_length=20, 
        choices=TYPE_CHOICES, 
        default=QUESTION_PAPER,
        help_text="Is this a paper or a bank?"
    )
    
    # Metadata
    created_by = models.ForeignKey(
        User, 
        on_delete=models.PROTECT, 
        related_name='created_question_banks',
        help_text="User who created this"
    )
    uploaded_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='uploaded_question_banks',
        help_text="User who uploaded/modified this"
    )
    
    # Hierarchy Links (optional)
    course = models.ForeignKey(
        HierarchyCourse,
        on_delete=models.CASCADE,
        null=True,
        blank=True,
        help_text="Associated course"
    )
    leg = models.ForeignKey(
        Leg,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        help_text="Associated leg"
    )
    subject = models.ForeignKey(
        Subject,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        help_text="Associated subject"
    )
    chapter = models.ForeignKey(
        Chapter,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        help_text="Associated chapter"
    )
    topic = models.ForeignKey(
        Topic,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        help_text="Associated topic"
    )
    section = models.ForeignKey(
        Section,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        help_text="Associated section"
    )
    
    # Paper Settings
    total_marks = models.IntegerField(default=50, help_text="Total marks for paper")
    duration_minutes = models.IntegerField(null=True, blank=True, help_text="Time limit in minutes")
    
    # Statistics
    total_questions = models.IntegerField(default=0, help_text="Total number of questions")
    mcq_count = models.IntegerField(default=0)
    true_false_count = models.IntegerField(default=0)
    fill_blank_count = models.IntegerField(default=0)
    short_answer_count = models.IntegerField(default=0)
    descriptive_count = models.IntegerField(default=0)
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    keyword = models.CharField(
        blank=True,
        null=True,
        help_text="Keyword/topic filter used during question generation"
    )
    source_documents_fk = models.ManyToManyField(
        UploadDocument,
        blank=True,
        related_name='question_banks',
        help_text="All source documents used to generate this bank"
    )

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Question Bank'
        verbose_name_plural = 'Question Banks'
        indexes = [
            models.Index(fields=['created_by', '-created_at']),
            models.Index(fields=['course', 'subject']),
        ]
    
    def __str__(self):
        return f"{self.title} ({self.total_questions} Q's, {self.total_marks} marks)"
    
    def update_statistics(self):
        """Update question counts"""
        from .models import Question
        questions = self.questions.all()
        
        self.total_questions = questions.count()
        self.mcq_count = questions.filter(question_type='mcq').count()
        self.true_false_count = questions.filter(question_type='tf').count()
        self.fill_blank_count = questions.filter(question_type='fitb').count()
        self.short_answer_count = questions.filter(question_type='sa').count()
        self.descriptive_count = questions.filter(question_type='desc').count()
        
        # Calculate total marks
        self.total_marks = sum(q.marks for q in questions) or self.total_marks
        self.save()


class Question(models.Model):
    """
    Individual question stored in database
    """
    QUESTION_TYPES = [
        ('mcq', 'Multiple Choice Question'),
        ('tf', 'True/False'),
        ('fitb', 'Fill in the Blanks'),
        ('sa', 'Short Answer'),
        ('desc', 'Descriptive'),
    ]
    
    DIFFICULTY_CHOICES = [
        ('easy', 'Easy'),
        ('medium', 'Medium'),
        ('hard', 'Hard'),
    ]
    
    # Foreign Keys
    bank = models.ForeignKey(
        QuestionBank,
        on_delete=models.CASCADE,
        related_name='questions',
        help_text="Parent question bank"
    )
    source_documents_fk = models.ManyToManyField(
        UploadDocument,
        blank=True,
        related_name='questions',
        help_text="Source documents this question was generated from"
    )

    
    # Question Content
    question_text = models.TextField(help_text="The question")
    question_type = models.CharField(
        max_length=10,
        choices=QUESTION_TYPES,
        help_text="Type of question"
    )
    
    # Options (for MCQ and Fill Blank)
    option_a = models.TextField(blank=True, null=True, help_text="Option A")
    option_b = models.TextField(blank=True, null=True, help_text="Option B")
    option_c = models.TextField(blank=True, null=True, help_text="Option C")
    option_d = models.TextField(blank=True, null=True, help_text="Option D")
    
    # Answer
    correct_answer = models.TextField(help_text="Correct answer")
    explanation = models.TextField(blank=True, null=True, help_text="Answer explanation")
    
    # Metadata
    marks = models.IntegerField(default=1, help_text="Marks for this question")
    difficulty = models.CharField(
        max_length=10,
        choices=[('easy', 'Easy'), ('medium', 'Medium'), ('hard', 'Hard')],
        default='medium',
        blank=True,
    )
    # Source Information
    source_documents = models.TextField(blank=True, null=True, help_text="JSON list of source docs")
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['bank', 'id']
        verbose_name = 'Question'
        verbose_name_plural = 'Questions'
        indexes = [
            models.Index(fields=['bank', 'question_type']),
            models.Index(fields=['created_at']),
        ]
    
    def __str__(self):
        return f"{self.get_question_type_display()}: {self.question_text[:50]}..."
    
    def get_options_list(self):
        """Get list of non-empty options"""
        return [
            ('A', self.option_a),
            ('B', self.option_b),
            ('C', self.option_c),
            ('D', self.option_d),
        ]
    
    def get_formatted_options(self):
        """Get formatted options for display"""
        options = []
        for label, text in self.get_options_list():
            if text:
                options.append({
                    'label': label,
                    'text': text,
                    'is_correct': self.correct_answer == label
                })
        return options


class QuestionPaperVersion(models.Model):
    """
    Tracks versions of question papers (for versioning/audit)
    """
    bank = models.ForeignKey(
        QuestionBank,
        on_delete=models.CASCADE,
        related_name='versions'
    )
    
    version_number = models.IntegerField(help_text="Version number")
    created_by = models.ForeignKey(User, on_delete=models.PROTECT)
    created_at = models.DateTimeField(auto_now_add=True)
    
    # Changes
    change_summary = models.TextField(blank=True, null=True)
    
    class Meta:
        ordering = ['-version_number']
        verbose_name = 'Question Paper Version'
        unique_together = ['bank', 'version_number']
    
    def __str__(self):
        return f"{self.bank.title} - v{self.version_number}"


class QuestionBankExport(models.Model):
    """
    Tracks PDF exports of question banks
    """
    EXPORT_TYPES = [
        ('paper', 'Question Paper Only'),
        ('paper_answer', 'Paper with Answers'),
        ('answers_only', 'Answers Only'),
    ]
    
    bank = models.ForeignKey(
        QuestionBank,
        on_delete=models.CASCADE,
        related_name='exports'
    )
    
    export_type = models.CharField(max_length=20, choices=EXPORT_TYPES)
    created_by = models.ForeignKey(User, on_delete=models.PROTECT)
    created_at = models.DateTimeField(auto_now_add=True)
    
    # File
    pdf_file = models.FileField(
        upload_to='question_papers/%Y/%m/%d/',
        help_text="Generated PDF file"
    )
    
    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Question Bank Export'
    
    def __str__(self):
        return f"{self.bank.title} - {self.get_export_type_display()} ({self.created_at})"
    
    
class QuestionPaperLog(models.Model):
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='paper_logs',
        help_text='User who generated this paper'
    )
    source_documents_fk = models.ManyToManyField(
        UploadDocument,
        blank=True,
        related_name='paper_logs',
        help_text="Source documents used to generate this paper"
    )

    paper_name = models.CharField(
        max_length=255,
        help_text='Title of the generated paper'
    )
    total_questions = models.PositiveIntegerField(default=0)
    total_marks     = models.PositiveIntegerField(default=0)
    created_at      = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'question_paper_log'
        ordering = ['-created_at']
        verbose_name = 'Question Paper Log'
        verbose_name_plural = 'Question Paper Logs'

    def __str__(self):
        return f"{self.user.username} | {self.paper_name} | {self.created_at:%d %b %Y %H:%M}"