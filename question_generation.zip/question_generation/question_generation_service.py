"""
Question Generation Service
Handles multi-document question generation with chunking and duplicate detection
"""

import json
import re
import hashlib
from typing import List, Dict, Any, Tuple
from datetime import datetime
from django.db.models import Q
from django.conf import settings


class QuestionGenerationService:
    
    QUESTION_TYPES = {
        'mcq':  {'name': 'Multiple Choice Questions', 'description': '4 options per question, single correct answer', 'icon': 'list-ol'},
        'tf':   {'name': 'True / False',              'description': 'Simple true or false statements',               'icon': 'check-circle'},
        'fitb': {'name': 'Fill in the Blanks',        'description': 'Complete the sentence with missing words',      'icon': 'pencil-alt'},
        'sa':   {'name': 'Short Answer',              'description': '2–4 sentence answer expected',                  'icon': 'comment-dots'},
        'desc': {'name': 'Descriptive',               'description': 'Long-form, detailed response required',         'icon': 'file-alt'},
    }
    
    def __init__(self, user, base_model_url: str = None):
        self.user = user
        self.base_model_url = base_model_url or getattr(settings, 'MODEL_BASE_URL', 'http://localhost:11434')
        self.generated_questions = []
        self.generation_logs = []
    
    def validate_request(self, documents, total_marks, question_types):
        if not documents:
            return False, 'No documents provided.'
        for doc in documents:
            if 'id' not in doc:
                return False, 'Document must have an ID.'
        try:
            marks = int(total_marks)
            if not (1 <= marks <= 100):
                return False, 'Total marks must be between 1 and 100.'
        except (ValueError, TypeError):
            return False, 'Invalid total marks value.'
        if not question_types:
            return False, 'At least one question type is required.'
        valid_types = set(self.QUESTION_TYPES.keys())
        total_questions = 0
        for qt in question_types:
            qtype = qt.get('type')
            count = qt.get('count', 0)
            if qtype not in valid_types:
                return False, f'Unknown question type: {qtype}'
            try:
                count = int(count)
                if count < 1:
                    return False, f'Question count must be >= 1 for {qtype}'
                total_questions += count
            except (ValueError, TypeError):
                return False, f'Invalid count for question type: {qtype}'
        if total_questions == 0:
            return False, 'No questions requested.'
        return True, ''
    
    def prepare_generation_context(self, documents):
        return {'documents': [], 'total_chunks': 0, 'document_texts': {}}
    
    def generate_prompts_for_type(self, qtype: str, num_questions: int,
                                  difficulty_dist: Dict = None,
                                  difficulty: str = 'medium',
                                  keyword: str = '') -> str:
        """
        Generate LLM prompt for a specific question type.

        Args:
            qtype           : Question type (mcq, tf, fitb, sa, desc)
            num_questions   : Number of questions to generate
            difficulty_dist : Legacy — ignored when `difficulty` is given
            difficulty      : 'easy' | 'medium' | 'hard'  (default 'medium')
            keyword         : Optional topic/keyword — when provided, prompts LLM
                              to focus MAXIMUM questions on this specific topic.

        Returns:
            Formatted prompt string for LLM
        """
        difficulty = (difficulty or 'medium').lower()
        if difficulty not in ('easy', 'medium', 'hard'):
            difficulty = 'medium'

        difficulty_labels = {
            'easy':   'easy (basic recall, straightforward facts)',
            'medium': 'medium (application and comprehension)',
            'hard':   'hard (analysis, evaluation, and higher-order thinking)',
        }
        difficulty_text = f"ALL questions MUST be {difficulty_labels[difficulty]} difficulty level.\n"

        # ── KEYWORD FOCUS: only injected when a keyword is present ───────────
        keyword = (keyword or '').strip()
        keyword_focus = ''
        if keyword:
            keyword_focus = (
                f"TOPIC FOCUS: Make questions specifically about '{keyword}'. "
                f"Focus MAXIMUM questions on this topic — every question should "
                f"relate to '{keyword}' as closely as possible.\n"
            )
        # ─────────────────────────────────────────────────────────────────────

        base_instructions = (
            "You are a highly intelligent educational question generator. "
            "Generate ONLY from the provided context. "
            "Do NOT ask about page numbers, metadata, or non-educational content.\n"
            f"{difficulty_text}"
            f"{keyword_focus}"
        )

        type_prompts = {
            'mcq': (
                f"{base_instructions}\n"
                f"Generate EXACTLY {num_questions} multiple-choice questions.\n"
                "Requirements:\n"
                "- 4 options (A, B, C, D) per question\n"
                "- Options MUST be 3-4 words maximum\n"
                "- Single correct answer only\n"
                "- All questions MUST be UNIQUE\n"
                "- Incorrect options must be plausible but clearly wrong\n\n"
                "FORMAT (NO OTHER TEXT):\n"
                "**Question X**\nQuestion text here?\n"
                "A) Option\nB) Option\nC) Option\nD) Option\n"
                "**Correct Answer:** X\n\n"
            ),
            'tf': (
                f"{base_instructions}\n"
                f"Generate EXACTLY {num_questions} true/false questions.\n"
                "Requirements:\n"
                "- Each must be a declarative statement\n"
                "- 50% True, 50% False answers\n"
                "- All statements MUST be UNIQUE\n\n"
                "FORMAT (NO OTHER TEXT):\n"
                "**Question X**\nStatement here.\n"
                "**Correct Answer:** True/False\n\n"
            ),
            'fitb': (
                f"{base_instructions}\n"
                f"Generate EXACTLY {num_questions} fill-in-the-blank questions.\n"
                "Requirements:\n"
                "- EXACTLY ONE blank per question (______)\n"
                "- 4 different answer options (A, B, C, D)\n"
                "- All options must be valid text answers\n"
                "- All questions MUST be UNIQUE\n\n"
                "FORMAT (NO OTHER TEXT):\n"
                "**Question X**\nQuestion with ______ here.\n"
                "A) Option\nB) Option\nC) Option\nD) Option\n"
                "**Correct Answer:** X\n\n"
            ),
            'sa': (
                f"{base_instructions}\n"
                f"Generate EXACTLY {num_questions} short-answer questions.\n"
                "Requirements:\n"
                "- Answers should be 2-4 sentences\n"
                "- Questions must NOT contain their own answers\n"
                "- All questions MUST be UNIQUE\n\n"
                "FORMAT (NO OTHER TEXT):\n"
                "**Question X**\nQuestion here?\n"
                "**Correct Answer:** 2-4 sentence answer\n\n"
            ),
            'desc': (
                f"{base_instructions}\n"
                f"Generate EXACTLY {num_questions} descriptive questions.\n"
                "Requirements:\n"
                "- Answers MUST be 4+ detailed sentences\n"
                "- Questions should require explanation, analysis, or discussion\n"
                "- All questions MUST be UNIQUE\n\n"
                "FORMAT (NO OTHER TEXT):\n"
                "**Question X**\nQuestion here?\n"
                "**Correct Answer:** Detailed answer (4+ sentences)\n\n"
            )
        }

        return type_prompts.get(qtype, '')
    
    def parse_generated_questions(self, raw_output: str, qtype: str, user=None):
        questions = []
        output = re.sub(r'(Here are|Here\s+are|Generate|Below are) .{0,50}?\n\n', '', raw_output, flags=re.IGNORECASE)
        q_blocks = re.split(r'\*\*Question \d+\*\*', output)
        for block in q_blocks[1:]:
            block = block.strip()
            if not block:
                continue
            parsed = self._parse_question_block(block, qtype)
            if parsed and not self._is_duplicate(parsed, questions):
                questions.append(parsed)
        return questions
    
    def _parse_question_block(self, block, qtype):
        if qtype == 'mcq':   return self._parse_mcq(block)
        if qtype == 'tf':    return self._parse_true_false(block)
        if qtype == 'fitb':  return self._parse_fill_blank(block)
        if qtype == 'sa':    return self._parse_short_answer(block)
        if qtype == 'desc':  return self._parse_descriptive(block)
        return None
    
    def _parse_mcq(self, block):
        q_match = re.search(r'(.*?)\nA\)', block, re.DOTALL)
        if not q_match: return None
        question_text = q_match.group(1).strip()
        options = re.findall(r'([A-D])\)\s*(.*?)(?=\n[A-D]\)|\n\*\*Correct|$)', block, re.DOTALL)
        if len(options) < 4: return None
        ans_match = re.search(r'\*\*Correct Answer:\*\*\s*([A-D])', block)
        if not ans_match: return None
        return {
            'question': question_text, 'question_type': 'mcq', 'type': 'Multiple Choice Questions',
            'option_A': options[0][1].strip(), 'option_B': options[1][1].strip(),
            'option_C': options[2][1].strip(), 'option_D': options[3][1].strip(),
            'correct_answer': ans_match.group(1).strip(), 'difficulty': 'medium', 'marks': 1
        }
    
    def _parse_true_false(self, block):
        q_match = re.search(r'(.+?)\s*\*\*Correct Answer:\*\*', block, re.DOTALL)
        ans_match = re.search(r'\*\*Correct Answer:\*\*\s*(True|False)', block, re.IGNORECASE)
        if not q_match or not ans_match: return None
        correct = ans_match.group(1).strip()
        return {
            'question': q_match.group(1).strip(), 'question_type': 'tf', 'type': 'True / False',
            'option_A': 'True', 'option_B': 'False', 'option_C': '', 'option_D': '',
            'correct_answer': 'A' if correct.lower() == 'true' else 'B',
            'difficulty': 'medium', 'marks': 1
        }
    
    def _parse_fill_blank(self, block):
        q_match = re.search(r'^(.*?)\nA\)', block, re.DOTALL)
        opts_match = re.findall(r'([A-D])\)\s*(.*?)\n', block)
        ans_match = re.search(r'\*\*Correct Answer:\*\*\s*([A-D])', block, re.IGNORECASE)
        if not q_match or not opts_match or not ans_match: return None
        question_text = q_match.group(1).strip()
        options = {opt[0]: opt[1].strip() for opt in opts_match}
        correct_key = ans_match.group(1).strip()
        if "____" not in question_text:
            correct_text = options.get(correct_key, '')
            question_text = re.sub(re.escape(correct_text), "______", question_text, count=1, flags=re.IGNORECASE)
        return {
            'question': question_text, 'question_type': 'fitb', 'type': 'Fill in the Blanks',
            'option_A': options.get('A', ''), 'option_B': options.get('B', ''),
            'option_C': options.get('C', ''), 'option_D': options.get('D', ''),
            'correct_answer': correct_key, 'difficulty': 'medium', 'marks': 1
        }
    
    def _parse_short_answer(self, block):
        q_match = re.search(r'^(.*?)(?:\*\*Correct Answer:\*\*|$)', block, re.DOTALL | re.IGNORECASE)
        ans_match = re.search(r'\*\*Correct Answer:\*\*\s*(.*?)$', block, re.IGNORECASE)
        if not q_match or not ans_match: return None
        return {
            'question': q_match.group(1).strip(), 'question_type': 'sa', 'type': 'Short Answer',
            'option_A': '', 'option_B': '', 'option_C': '', 'option_D': '',
            'correct_answer': ans_match.group(1).strip(), 'difficulty': 'medium', 'marks': 2
        }
    
    def _parse_descriptive(self, block):
        q_match = re.search(r'^(.*?)\n\*\*Correct Answer:\*\*', block, re.DOTALL)
        ans_match = re.search(r'\*\*Correct Answer:\*\*(.*?)$', block, re.DOTALL)
        if not q_match or not ans_match: return None
        return {
            'question': q_match.group(1).strip(), 'question_type': 'desc', 'type': 'Descriptive',
            'option_A': '', 'option_B': '', 'option_C': '', 'option_D': '',
            'correct_answer': ans_match.group(1).strip(), 'difficulty': 'medium', 'marks': 4
        }
    
    def _is_duplicate(self, question, existing):
        q_text = self._normalize_text(question.get('question', ''))
        for existing_q in existing:
            if q_text == self._normalize_text(existing_q.get('question', '')):
                return True
        return False
    
    def _normalize_text(self, text):
        text = text.lower()
        text = re.sub(r'[^a-z0-9\s]', '', text)
        return re.sub(r'\s+', ' ', text).strip()
    
    def calculate_marks_distribution(self, total_marks, question_types):
        distribution = {}
        total_questions = sum(qt['count'] for qt in question_types)
        marks_per_q = total_marks / total_questions
        for qt in question_types:
            qtype = qt['type']
            count = qt['count']
            distribution[qtype] = {'count': count, 'marks_per_q': marks_per_q, 'total_marks': marks_per_q * count}
        return distribution
    
    def log_generation(self, document_id, qtype, requested_count, generated_count, status='completed', error=None):
        log_entry = {
            'document_id': document_id, 'question_type': qtype,
            'requested_count': requested_count, 'generated_count': generated_count,
            'status': status, 'error': error,
            'timestamp': datetime.now().isoformat(),
            'user_id': self.user.id if self.user else None
        }
        self.generation_logs.append(log_entry)
        return log_entry
    
    def get_summary(self):
        total_questions = len(self.generated_questions)
        by_type = {}
        for q in self.generated_questions:
            qtype = q.get('question_type', 'unknown')
            by_type[qtype] = by_type.get(qtype, 0) + 1
        return {'total_generated': total_questions, 'by_type': by_type,
                'generation_logs': self.generation_logs, 'timestamp': datetime.now().isoformat()}