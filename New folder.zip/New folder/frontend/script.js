/**
 * script.js - Frontend logic for AI Question Generator
 * Manages UI states and communicates with Django REST API.
 */

// ===== STATE =====
let documentId = null;
let selectedFile = null;

// ===== DOM REFS =====
const dropZone       = document.getElementById('dropZone');
const fileInput      = document.getElementById('fileInput');
const fileInfo       = document.getElementById('fileInfo');
const fileName       = document.getElementById('fileName');
const removeFileBtn  = document.getElementById('removeFileBtn');
const uploadBtn      = document.getElementById('uploadBtn');

const uploadSection   = document.getElementById('uploadSection');
const loaderSection   = document.getElementById('loaderSection');
const actionSection   = document.getElementById('actionSection');
const downloadSection = document.getElementById('downloadSection');

const loaderMessage       = document.getElementById('loaderMessage');
const generateQuestionsBtn = document.getElementById('generateQuestionsBtn');
const downloadExcelBtn    = document.getElementById('downloadExcelBtn');
const downloadTxtBtn      = document.getElementById('downloadTxtBtn');
const generateSetsBtn     = document.getElementById('generateSetsBtn');
const questionsCountText  = document.getElementById('questionsCountText');
const setsSuccess         = document.getElementById('setsSuccess');

// ===== SECTION TOGGLING =====
function showOnly(section) {
    [uploadSection, loaderSection, actionSection, downloadSection].forEach(s => {
        s.classList.add('hidden');
    });
    section.classList.remove('hidden');
}

function showLoader(msg) {
    loaderMessage.textContent = msg;
    showOnly(loaderSection);
}

// ===== FILE SELECTION =====
dropZone.addEventListener('click', () => fileInput.click());

dropZone.addEventListener('dragover', e => {
    e.preventDefault();
    dropZone.classList.add('dragover');
});

dropZone.addEventListener('dragleave', e => {
    e.preventDefault();
    dropZone.classList.remove('dragover');
});

dropZone.addEventListener('drop', e => {
    e.preventDefault();
    dropZone.classList.remove('dragover');
    if (e.dataTransfer.files.length) selectFile(e.dataTransfer.files[0]);
});

fileInput.addEventListener('change', e => {
    if (e.target.files.length) selectFile(e.target.files[0]);
});

function selectFile(file) {
    if (!file || file.type !== 'application/pdf') {
        alert('Please select a valid PDF file.');
        return;
    }
    selectedFile = file;
    fileName.textContent = file.name;
    fileInfo.classList.remove('hidden');
    uploadBtn.disabled = false;
}

removeFileBtn.addEventListener('click', () => {
    selectedFile = null;
    fileInput.value = '';
    fileInfo.classList.add('hidden');
    uploadBtn.disabled = true;
});

// ===== STEP 1: UPLOAD PDF =====
uploadBtn.addEventListener('click', async () => {
    if (!selectedFile) return;

    showLoader('Processing PDF and generating embeddings...');

    const formData = new FormData();
    formData.append('file', selectedFile);

    try {
        const res = await fetch('/api/upload-pdf/', { method: 'POST', body: formData });
        if (!res.ok) {
            const err = await res.json().catch(() => ({}));
            throw new Error(err.error || 'Upload failed');
        }
        const data = await res.json();
        documentId = data.document_id;

        // Move to Step 3 — "Generate Questions"
        showOnly(actionSection);
    } catch (err) {
        alert('Upload Error: ' + err.message);
        showOnly(uploadSection);
    }
});

// ===== STEP 2: GENERATE QUESTIONS =====
generateQuestionsBtn.addEventListener('click', async () => {
    if (!documentId) return;

    showLoader('Generating questions — this may take a few minutes...');

    try {
        const res = await fetch('/api/generate-questions/', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ document_id: documentId })
        });
        if (!res.ok) {
            const err = await res.json().catch(() => ({}));
            throw new Error(err.error || 'Generation failed');
        }
        const data = await res.json();
        questionsCountText.textContent = `${data.questions_generated} questions generated successfully!`;

        // Move to Step 4 — Downloads
        showOnly(downloadSection);
    } catch (err) {
        alert('Generation Error: ' + err.message);
        showOnly(actionSection);
    }
});

// ===== STEP 3: DOWNLOAD FILES =====
downloadExcelBtn.addEventListener('click', () => {
    window.open(`/api/export/?document_id=${documentId}&type=excel`, '_blank');
});

downloadTxtBtn.addEventListener('click', () => {
    window.open(`/api/export/?document_id=${documentId}&type=txt`, '_blank');
});

// ===== STEP 4: GENERATE 5 SETS =====
generateSetsBtn.addEventListener('click', async () => {
    if (!documentId) return;

    generateSetsBtn.disabled = true;
    showLoader('Creating 5 random question sets...');

    try {
        const res = await fetch(`/api/generate-sets/?document_id=${documentId}`);
        if (!res.ok) throw new Error('Set generation failed');
        const data = await res.json();

        // Auto-download the sets as a JSON file
        const blob = new Blob([JSON.stringify(data.sets, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'question_sets.json';
        a.click();
        URL.revokeObjectURL(url);

        // Return to download section and show success
        showOnly(downloadSection);
        setsSuccess.classList.remove('hidden');
        generateSetsBtn.disabled = true;
        generateSetsBtn.textContent = 'Sets Downloaded ✓';
    } catch (err) {
        alert('Error: ' + err.message);
        showOnly(downloadSection);
        generateSetsBtn.disabled = false;
    }
});
