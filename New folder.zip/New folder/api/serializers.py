from rest_framework import serializers
from .models import PDFDocument, Question

class PDFDocumentSerializer(serializers.ModelSerializer):
    class Meta:
        model = PDFDocument
        fields = ['id', 'file', 'uploaded_at']

class QuestionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Question
        fields = ['id', 'document', 'text', 'question_type', 'options', 'answer', 'created_at']

class QuestionSetSerializer(serializers.Serializer):
    mcq = QuestionSerializer(many=True)
    tf = QuestionSerializer(many=True)
    fib = QuestionSerializer(many=True)
