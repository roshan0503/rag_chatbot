from django.db import models
from django.contrib.postgres.fields import ArrayField

class Document(models.fields.files.FieldFile):
    # This is a model for tracking uploaded documents
    pass

class PDFDocument(models.Model):
    file = models.FileField(upload_to='pdfs/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    parsed_text = models.TextField(blank=True, null=True)
    
    def __str__(self):
        return f"PDF {self.id} - {self.uploaded_at.date()}"

class Question(models.Model):
    TYPE_CHOICES = (
        ('mcq', 'Multiple Choice'),
        ('tf', 'True/False'),
        ('fib', 'Fill in the Blanks'),
    )
    
    document = models.ForeignKey(PDFDocument, on_delete=models.CASCADE, related_name='questions')
    text = models.TextField()
    question_type = models.CharField(max_length=10, choices=TYPE_CHOICES)
    options = models.JSONField(blank=True, null=True) # ['Option A', 'Option B', 'Option C', 'Option D']
    answer = models.TextField()
    
    # Store embedding as an array of floats
    embedding = ArrayField(models.FloatField(), blank=True, null=True)
    
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"[{self.get_question_type_display()}] {self.text[:50]}"
