import os
import pandas as pd
from django.conf import settings
from openpyxl import Workbook

def export_questions_to_files(questions, document_id):
    outputs_dir = settings.OUTPUTS_DIR
    base_filename = f"document_{document_id}_questions"
    
    txt_path = os.path.join(outputs_dir, f"{base_filename}.txt")
    xlsx_path = os.path.join(outputs_dir, f"{base_filename}.xlsx")
    
    # Text Export
    with open(txt_path, 'w', encoding='utf-8') as f:
        for q in questions:
            f.write(f"Type: {q.get_question_type_display()}\n")
            f.write(f"Question: {q.text}\n")
            if q.options:
                f.write(f"Options: {', '.join(q.options)}\n")
            f.write(f"Answer: {q.answer}\n")
            f.write("-" * 40 + "\n")
            
    # Excel Export
    data = []
    for q in questions:
        data.append({
            "Type": q.get_question_type_display(),
            "Question": q.text,
            "Options": ", ".join(q.options) if q.options else "",
            "Answer": q.answer
        })
        
    df = pd.DataFrame(data)
    df.to_excel(xlsx_path, index=False)
    
    return txt_path, xlsx_path
