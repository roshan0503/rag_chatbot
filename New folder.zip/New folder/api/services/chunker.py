def chunk_text(text, chunk_size=1500, overlap=150):
    """Split text into overlapping chunks. Larger chunks = fewer LLM calls."""
    if not text:
        return []

    chunks = []
    start = 0
    text_length = len(text)

    while start < text_length:
        end = min(start + chunk_size, text_length)

        # Try to break at a sentence boundary (period + space)
        if end < text_length:
            last_period = text.rfind('. ', start, end)
            if last_period > start + chunk_size // 2:
                end = last_period + 2  # include the period and space

        chunks.append(text[start:end])

        if chunk_size <= overlap:
            break

        start += (end - start) - overlap

    return chunks
