import random

def generate_question_sets(questions, num_sets=5, counts=None):
    if counts is None:
        counts = {"mcq": 10, "tf": 10, "fib": 10}
        
    mcqs = [q for q in questions if q.question_type == 'mcq']
    tfs = [q for q in questions if q.question_type == 'tf']
    fibs = [q for q in questions if q.question_type == 'fib']
    
    sets = []
    for i in range(num_sets):
        set_mcqs = random.sample(mcqs, min(counts["mcq"], len(mcqs)))
        set_tfs = random.sample(tfs, min(counts["tf"], len(tfs)))
        set_fibs = random.sample(fibs, min(counts["fib"], len(fibs)))
        
        # We can return full serialized questions here so it's ready for the view response
        sets.append({
            "set_number": i + 1,
            "mcq": [{"id": q.id, "text": q.text, "options": q.options, "answer": q.answer} for q in set_mcqs],
            "tf": [{"id": q.id, "text": q.text, "answer": q.answer} for q in set_tfs],
            "fib": [{"id": q.id, "text": q.text, "answer": q.answer} for q in set_fibs]
        })
        
    return sets
