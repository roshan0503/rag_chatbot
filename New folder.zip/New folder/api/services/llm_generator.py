import os
import json
import requests
import time
import logging

logger = logging.getLogger(__name__)

def generate_questions_from_chunk(text, retries=3):
    """Generate questions from a single text chunk via OpenRouter."""
    api_key = os.getenv('OPENROUTER_API_KEY')
    url = "https://openrouter.ai/api/v1/chat/completions"

    prompt = f"""You are an AI that generates educational questions from text.
Read the following text and generate as many questions as possible.

Output ONLY a valid JSON object (no markdown, no explanation) with this exact schema:
{{
  "mcq": [
    {{"question": "...", "options": ["A", "B", "C", "D"], "answer": "A"}}
  ],
  "true_false": [
    {{"question": "...", "answer": "True"}}
  ],
  "fill_blanks": [
    {{"question": "... ____ ...", "answer": "..."}}
  ]
}}

Rules:
- Only use information from the text below. Do NOT hallucinate.
- Maximize the number of questions.
- If a type cannot be generated, use an empty array.
- Output ONLY valid JSON. No extra text.

Text:
{text}"""

    headers = {
        "Authorization": f"Bearer {api_key}",
        "HTTP-Referer": "http://localhost:8000",
        "Content-Type": "application/json"
    }

    data = {
        "model": "openai/gpt-oss-120b:free",
        "messages": [
            {"role": "system", "content": "You are a precise JSON-only question generator. Output raw JSON only."},
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.3
    }

    for attempt in range(retries):
        try:
            logger.info(f"LLM call attempt {attempt + 1}...")
            response = requests.post(url, headers=headers, json=data, timeout=120)
            response.raise_for_status()

            content = response.json()['choices'][0]['message']['content'].strip()

            # Strip markdown code fences if present
            if content.startswith("```json"):
                content = content[7:]
            if content.startswith("```"):
                content = content[3:]
            if content.endswith("```"):
                content = content[:-3]
            content = content.strip()

            parsed = json.loads(content)

            # Validate structure
            if 'mcq' in parsed and 'true_false' in parsed and 'fill_blanks' in parsed:
                total = len(parsed['mcq']) + len(parsed['true_false']) + len(parsed['fill_blanks'])
                logger.info(f"LLM returned {total} questions from this chunk.")
                return parsed
            else:
                raise ValueError("Missing required keys in JSON response")

        except json.JSONDecodeError as e:
            logger.warning(f"JSON parse error (attempt {attempt + 1}): {e}")
            time.sleep(1)
        except Exception as e:
            logger.warning(f"LLM error (attempt {attempt + 1}): {e}")
            time.sleep(2)

    logger.error("All LLM retries exhausted. Returning empty result.")
    return {"mcq": [], "true_false": [], "fill_blanks": []}
