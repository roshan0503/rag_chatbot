import os
import requests
import logging

logger = logging.getLogger(__name__)

def get_embedding(text):
    """Get embedding vector for a single text from Ollama."""
    ollama_url = os.getenv('OLLAMA_URL', 'http://localhost:11434/api/embeddings')
    if not ollama_url.endswith('api/embeddings') and not ollama_url.endswith('api/embeddings/'):
        ollama_url = ollama_url.rstrip('/') + '/api/embeddings'
    try:
        response = requests.post(ollama_url, json={
            "model": "nomic-embed-text",
            "prompt": text
        }, timeout=15)
        response.raise_for_status()
        return response.json().get('embedding', [])
    except Exception as e:
        logger.warning(f"Embedding error: {e}")
        return []


def get_embeddings_batch(texts):
    """Get embeddings for a list of texts. Returns list of embedding vectors."""
    results = []
    for text in texts:
        results.append(get_embedding(text))
    return results
