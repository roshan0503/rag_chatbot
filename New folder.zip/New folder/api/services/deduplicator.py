import numpy as np
from scipy.spatial.distance import cosine

def is_duplicate(new_embedding, existing_embeddings, threshold=0.85):
    """
    Checks if the new_embedding is too similar to any existing_embeddings
    using cosine similarity.
    threshold: similarity threshold (0.85 = 85% similar)
    """
    if not new_embedding or not existing_embeddings:
        return False
        
    new_vec = np.array(new_embedding)
    
    for emb in existing_embeddings:
        if not emb:
            continue
        
        vec = np.array(emb)
        try:
            distance = cosine(new_vec, vec)
            similarity = 1 - distance
            if similarity > threshold:
                return True
        except Exception:
            continue
            
    return False
