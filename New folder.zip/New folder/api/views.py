import os
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, generics
from django.conf import settings
from django.http import FileResponse

from .models import PDFDocument, Question
from .serializers import PDFDocumentSerializer, QuestionSerializer
from .services.pdf_parser import extract_text_from_pdf
from .services.chunker import chunk_text
from .services.llm_generator import generate_questions_from_chunk
from .services.embedding import get_embedding
from .services.deduplicator import is_duplicate
from .services.exporter import export_questions_to_files
from .services.set_generator import generate_question_sets

class UploadPDFView(APIView):
    def post(self, request, *args, **kwargs):
        file_obj = request.FILES.get('file')
        if not file_obj:
            return Response({"error": "No file uploaded"}, status=status.HTTP_400_BAD_REQUEST)
        
        # Save Document
        document = PDFDocument.objects.create(file=file_obj)
        file_path = document.file.path
        
        # Parse Text
        text = extract_text_from_pdf(file_path)
        document.parsed_text = text
        document.save()
        
        return Response({
            "message": "PDF processed successfully",
            "document_id": document.id
        }, status=status.HTTP_201_CREATED)

class GenerateQuestionsView(APIView):
    def post(self, request, *args, **kwargs):
        import logging
        from concurrent.futures import ThreadPoolExecutor, as_completed

        logger = logging.getLogger(__name__)

        document_id = request.data.get('document_id')
        if not document_id:
            return Response({"error": "document_id is required"}, status=status.HTTP_400_BAD_REQUEST)

        try:
            document = PDFDocument.objects.get(id=document_id)
        except PDFDocument.DoesNotExist:
            return Response({"error": "Document not found"}, status=status.HTTP_404_NOT_FOUND)

        text = document.parsed_text
        if not text:
            return Response({"error": "No text found in document"}, status=status.HTTP_400_BAD_REQUEST)

        # Chunk Text
        chunks = chunk_text(text)
        logger.info(f"PDF split into {len(chunks)} chunks.")

        # === STEP 1: Generate questions from all chunks (parallel) ===
        all_raw_questions = []  # list of (type, item) tuples

        def process_chunk(idx, chunk):
            logger.info(f"[Chunk {idx+1}/{len(chunks)}] Sending to LLM...")
            return generate_questions_from_chunk(chunk)

        with ThreadPoolExecutor(max_workers=3) as executor:
            futures = {executor.submit(process_chunk, i, c): i for i, c in enumerate(chunks)}
            for future in as_completed(futures):
                idx = futures[future]
                try:
                    result = future.result()
                    for item in result.get('mcq', []):
                        all_raw_questions.append(('mcq', item))
                    for item in result.get('true_false', []):
                        all_raw_questions.append(('tf', item))
                    for item in result.get('fill_blanks', []):
                        all_raw_questions.append(('fib', item))
                    logger.info(f"[Chunk {idx+1}] Done.")
                except Exception as e:
                    logger.error(f"[Chunk {idx+1}] Failed: {e}")

        logger.info(f"LLM generated {len(all_raw_questions)} raw questions total. Now deduplicating...")

        # === STEP 2: Deduplicate and save ===
        existing_embeddings = list(
            Question.objects.exclude(embedding__isnull=True)
                           .values_list('embedding', flat=True)
        )
        total_created = 0

        for q_type, item in all_raw_questions:
            q_text = item.get('question', '')
            if not q_text:
                continue

            emb = get_embedding(q_text)

            if not is_duplicate(emb, existing_embeddings):
                Question.objects.create(
                    document=document,
                    text=q_text,
                    question_type=q_type,
                    options=item.get('options', []) if q_type == 'mcq' else [],
                    answer=item.get('answer', ''),
                    embedding=emb
                )
                existing_embeddings.append(emb)
                total_created += 1

        logger.info(f"Saved {total_created} unique questions after deduplication.")

        return Response({
            "message": "Questions generated successfully",
            "document_id": document.id,
            "questions_generated": total_created
        }, status=status.HTTP_200_OK)

class QuestionListView(generics.ListAPIView):
    queryset = Question.objects.all().order_by('-created_at')
    serializer_class = QuestionSerializer

class ExportQuestionsView(APIView):
    def get(self, request, *args, **kwargs):
        document_id = request.query_params.get('document_id')
        if document_id:
            questions = Question.objects.filter(document_id=document_id)
        else:
            questions = Question.objects.all()
            
        if not questions.exists():
            return Response({"error": "No questions found to export"}, status=status.HTTP_404_NOT_FOUND)
            
        txt_path, xlsx_path = export_questions_to_files(questions, document_id or "all")
        
        # We can return URLs if we served them via static/media, but simple way is to return the local paths or file download.
        # Let's return the URLs relative to MEDIA if they were saved in MEDIA, but they are in OUTPUTS_DIR.
        # Let's serve the Excel file directly as an example or return paths.
        export_type = request.query_params.get('type', 'excel')
        
        if export_type == 'txt':
            return FileResponse(open(txt_path, 'rb'), as_attachment=True, filename=os.path.basename(txt_path))
        else:
            return FileResponse(open(xlsx_path, 'rb'), as_attachment=True, filename=os.path.basename(xlsx_path))

class GenerateSetsView(APIView):
    def get(self, request, *args, **kwargs):
        document_id = request.query_params.get('document_id')
        if document_id:
            questions = Question.objects.filter(document_id=document_id)
        else:
            questions = Question.objects.all()
            
        sets = generate_question_sets(list(questions))
        
        return Response({
            "message": "Sets generated successfully",
            "sets": sets
        }, status=status.HTTP_200_OK)
