from django.urls import path
from .views import UploadPDFView, GenerateQuestionsView, QuestionListView, ExportQuestionsView, GenerateSetsView

urlpatterns = [
    path('upload-pdf/', UploadPDFView.as_view(), name='upload_pdf'),
    path('generate-questions/', GenerateQuestionsView.as_view(), name='generate_questions'),
    path('questions/', QuestionListView.as_view(), name='question_list'),
    path('export/', ExportQuestionsView.as_view(), name='export'),
    path('generate-sets/', GenerateSetsView.as_view(), name='generate_sets'),
]
