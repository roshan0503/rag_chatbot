import os
import shutil
from flask import Flask, render_template, request, jsonify, session
from langchain_community.document_loaders import PyPDFLoader, TextLoader, Docx2txtLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_ollama import OllamaEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_ollama import ChatOllama
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage

app = Flask(__name__)
app.secret_key = 'super_secret_key_for_session_management'  # Change this in production
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['VECTOR_STORE_PATH'] = 'vectorstore'

# Ensure directories exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['VECTOR_STORE_PATH'], exist_ok=True)

# Global variables for RAG
EMBEDDING_MODEL = "nomic-embed-text"
LLM_MODEL = "gemma3:4b"
OLLAMA_BASE_URL = "http://localhost:11434"

def get_vectorstore():
    """Load the FAISS vector store if it exists."""
    if os.path.exists(os.path.join(app.config['VECTOR_STORE_PATH'], "index.faiss")):
        embeddings = OllamaEmbeddings(model=EMBEDDING_MODEL, base_url=OLLAMA_BASE_URL)
        try:
            return FAISS.load_local(
                app.config['VECTOR_STORE_PATH'], 
                embeddings, 
                allow_dangerous_deserialization=True
            )
        except Exception as e:
            print(f"Error loading vector store: {e}")
            return None
    return None

@app.route('/')
def index():
    return render_template('upload.html')

@app.route('/process', methods=['POST'])
def process_document():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400

    if file:
        # Save file
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(file_path)

        # Determine loader
        ext = os.path.splitext(file.filename)[1].lower()
        loader = None
        if ext == '.pdf':
            loader = PyPDFLoader(file_path)
        elif ext == '.txt':
            loader = TextLoader(file_path, encoding='utf-8')
        elif ext in ['.docx', '.doc']:
            loader = Docx2txtLoader(file_path)
        else:
            return jsonify({'error': 'Unsupported file type'}), 400

        try:
            # Load and split
            docs = loader.load()
            text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
            splits = text_splitter.split_documents(docs)

            # Embed and store
            embeddings = OllamaEmbeddings(model=EMBEDDING_MODEL, base_url=OLLAMA_BASE_URL)
            vectorstore = FAISS.from_documents(documents=splits, embedding=embeddings)
            vectorstore.save_local(app.config['VECTOR_STORE_PATH'])

            # Clear previous chat history on new upload if desired, strictly requested to persist history in session but context changes
            session['chat_history'] = [] 
            
            return jsonify({'message': 'Document processed successfully'})
        except Exception as e:
            return jsonify({'error': str(e)}), 500

@app.route('/chat')
def chat():
    return render_template('chat.html')

@app.route('/ask', methods=['POST'])
def ask():
    user_query = request.json.get('query')
    if not user_query:
        return jsonify({'error': 'Empty query'}), 400

    vectorstore = get_vectorstore()
    if not vectorstore:
        return jsonify({'error': 'No document processed yet. Please upload a file.'}), 400

    # Retrieve context
    retriever = vectorstore.as_retriever(search_type="similarity", search_kwargs={"k": 4})
    retrieved_docs = retriever.invoke(user_query)
    context_text = "\n\n".join([doc.page_content for doc in retrieved_docs])

    # Prepare Prompt
    system_prompt = (
        "You are a helpful AI assistant. Use the following pieces of context and the chat history to answer the user's question. "
        "If the answer is not in the context or chat history, say you don’t know.\n\n"
        "Context:\n{context}"
    )
    
    # Manage History (Last 10 messages -> 5 exchanges)
    if 'chat_history' not in session:
        session['chat_history'] = []
    
    history_messages = []
    # Take last 6 messages from history (3 exchanges) to provide better context
    recent_history = session['chat_history'][-6:] 
    
    for msg in recent_history:
        if msg['role'] == 'user':
            history_messages.append(HumanMessage(content=msg['content']))
        else:
            history_messages.append(AIMessage(content=msg['content']))

    # Construct final prompt messages
    final_messages = [SystemMessage(content=system_prompt.format(context=context_text))]
    final_messages.extend(history_messages)
    final_messages.append(HumanMessage(content=user_query))

    # Invoke Model
    try:
        llm = ChatOllama(model=LLM_MODEL, base_url=OLLAMA_BASE_URL)
        response = llm.invoke(final_messages)
        answer = response.content

        # Update History
        session['chat_history'].append({'role': 'user', 'content': user_query})
        session['chat_history'].append({'role': 'assistant', 'content': answer})
        session.modified = True

        return jsonify({'answer': answer})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/clear_history', methods=['POST'])
def clear_history():
    session['chat_history'] = []
    return jsonify({'message': 'History cleared'})

if __name__ == '__main__':
    app.run(debug=True, port=5000)
