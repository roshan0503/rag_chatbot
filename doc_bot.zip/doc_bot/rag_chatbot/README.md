# Local RAG Chatbot

A fully local RAG (Retrieval-Augmented Generation) chatbot using Flask, Ollama, FAISS, and LangChain.

## Prerequisites

1.  **Install Ollama**: [Download Ollama](https://ollama.com/)
2.  **Pull Models**: Run the following commands in your terminal to download the necessary models:
    ```bash
    ollama pull gemma3:4b
    ollama pull nomic-embed-text
    ```
3.  **Python 3.10+**: Ensure you have Python installed.

## Installation

1.  Navigate to the project directory:
    ```bash
    cd rag_chatbot
    ```
2.  Install dependencies:
    ```bash
    pip install -r requirements.txt
    ```

## Usage

1.  **Start the Flask App**:
    ```bash
    python app.py
    ```
2.  **Open Browser**:
    Go to `http://127.0.0.1:5000`
3.  **Upload Document**:
    - Upload a PDF, TXT, or DOCX file.
    - Wait for the "Document processed successfully" message.
4.  **Start Chatting**:
    - Click "Start Chat".
    - Ask questions about your document.

## Features

-   **Privacy Focused**: Runs 100% locally. No data leaves your machine.
-   **Multi-File Support**: PDF, TXT, DOCX.
-   **Conversation Memory**: Remembers context of the last few messages.
-   **Modern UI**: Clean, responsive interface with easy reading experience.
