const express = require('express');
const path = require('path');
const { Pool } = require('pg');

const app = express();
app.use(express.json({ limit: '50mb' }));

// ══════════════════════════════════════════════
//  STATIC IMAGE ROUTE (explicit handler)
// ══════════════════════════════════════════════
app.get('/api/static/:filename', (req, res) => {
    const filename = req.params.filename;
    const filePath = path.join(__dirname, 'public', 'images', filename);
    console.log('📷 Serving image:', filePath);  // Debug log
    res.sendFile(filePath, (err) => {
        if (err) {
            console.error('❌ Image not found:', filePath);
            res.status(404).send('Image not found: ' + filename);
        }
    });
});

// ══════════════════════════════════════════════
//  MAIN STATIC (serves index.html)
// ══════════════════════════════════════════════
app.use(express.static(path.join(__dirname)));
/* ── Ollama Proxy: avoids CORS ── */
async function ollamaProxy(targetPath, reqBody, res) {
    const apiUrl = (reqBody.apiUrl || '').replace(/\/+$/, '');
    if (!apiUrl) return res.status(400).json({ error: 'apiUrl is required' });

    try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 180000);

        const response = await fetch(apiUrl + targetPath, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(reqBody.payload || {}),
            signal: controller.signal
        });
        clearTimeout(timeout);

        const text = await response.text();
        let data;
        try { data = JSON.parse(text); } catch { data = text; }

        res.status(response.status).json(data);
    } catch (err) {
        const msg = err.name === 'AbortError'
            ? 'Ollama request timed out (3 min)'
            : 'Cannot reach Ollama at ' + apiUrl + '. Is it running?';
        res.status(502).json({ error: msg });
    }
}

/* ── Ollama helper: send a prompt and get back text ── */
async function ollamaAsk(apiUrl, model, systemPrompt, userPrompt, images) {
    const msg = { role: 'user', content: userPrompt };
    if (images && images.length) msg.images = images;

    const response = await fetch(apiUrl + '/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            model: model || 'llama3.2',
            stream: false,
            messages: [
                { role: 'system', content: systemPrompt },
                msg
            ]
        })
    });
    const data = await response.json();
    if (data.error) throw new Error(data.error);
    return (data.message && data.message.content) ? data.message.content.trim() : JSON.stringify(data);
}

/* ──────────────────────────────────────────────
   Test connection — fetches model list
   ────────────────────────────────────────────── */
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);
const modelCapabilitiesCache = {};

app.post('/api/ollama/test', async (req, res) => {
    const apiUrl = (req.body.apiUrl || '').replace(/\/+$/, '');
    if (!apiUrl) return res.status(400).json({ error: 'apiUrl is required' });

    try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 8000);

        const response = await fetch(apiUrl + '/api/tags', { signal: controller.signal });
        clearTimeout(timeout);
        const data = await response.json();

        if (data && Array.isArray(data.models)) {
            const llmModels = [];
            for (const model of data.models) {
                const modelName = model.name;
                let isEmbedding = false;

                if (modelCapabilitiesCache[modelName] !== undefined) {
                    isEmbedding = modelCapabilitiesCache[modelName];
                } else {
                    try {
                        const { stdout } = await execPromise(`ollama show "${modelName}"`);
                        const capMatch = stdout.match(/Capabilities([\s\S]*?)(?:Parameters|License|System|$)/i);
                        if (capMatch && capMatch[1] && capMatch[1].toLowerCase().includes('embedding')) {
                            isEmbedding = true;
                        }
                        modelCapabilitiesCache[modelName] = isEmbedding;
                    } catch (e) {
                        modelCapabilitiesCache[modelName] = false;
                    }
                }

                if (!isEmbedding) {
                    llmModels.push(model);
                }
            }
            data.models = llmModels;
        }

        res.status(response.status).json(data);
    } catch (err) {
        const msg = err.name === 'AbortError'
            ? 'Connection timed out. Is Ollama running?'
            : 'Cannot reach ' + apiUrl;
        res.status(502).json({ error: msg });
    }
});

/* Chat completion proxy */
app.post('/api/ollama/chat', (req, res) => {
    ollamaProxy('/api/chat', req.body, res);
});

/* Generate proxy (for future use) */
app.post('/api/ollama/generate', (req, res) => {
    ollamaProxy('/api/generate', req.body, res);
});


/* ══════════════════════════════════════════════
   TOOL ROUTES — all powered via local Ollama
   ══════════════════════════════════════════════ */


/* 1. TEXT SUMMARIZATION
   Body: { apiUrl, model, text, length, style } */
app.post('/api/tools/summarize', async (req, res) => {
    const { apiUrl, model, text, length, style } = req.body;
    if (!apiUrl) return res.status(400).json({ error: 'apiUrl is required' });
    if (!text) return res.status(400).json({ error: 'text is required' });

    const lengthMap = {
        'Short (1-2 sentences)': 'in 1-2 sentences',
        'Medium (1 paragraph)': 'in one concise paragraph',
        'Long (detailed)': 'in a detailed multi-paragraph summary'
    };
    const styleMap = {
        'Bullet Points': 'Use bullet points.',
        'Executive': 'Use an executive summary style.',
        'Simple': 'Use very simple, plain language.',
        'Neutral': ''
    };

    const system = 'You are a professional summarization assistant. Be accurate and concise.';
    const user = `Summarize the following text ${lengthMap[length] || 'in one paragraph'}. ${styleMap[style] || ''}\n\n${text}`;

    try {
        const result = await ollamaAsk(apiUrl.replace(/\/+$/, ''), model, system, user);
        res.json({ result });
    } catch (e) {
        res.status(502).json({ error: e.message });
    }
});


/* 2. DOCUMENT INTERACTION
   Body: { apiUrl, model, documentText, query, mode } */
app.post('/api/tools/document-interaction', async (req, res) => {
    let { apiUrl, model, documentText, query, mode } = req.body;
    if (!apiUrl) return res.status(400).json({ error: 'apiUrl is required' });
    if (!documentText) return res.status(400).json({ error: 'documentText is required' });

    try {
        let extractedText = documentText;

        // Auto-decode File Data URLs
        if (extractedText.startsWith('data:application/pdf;base64,')) {
            const pdfParse = require('pdf-parse');
            const b64Data = extractedText.replace(/^data:application\/pdf;base64,/, '');
            const pdfBuffer = Buffer.from(b64Data, 'base64');
            const pdfData = await pdfParse(pdfBuffer);
            extractedText = pdfData.text;
        } else if (extractedText.includes('wordprocessingml.document') && extractedText.includes('base64,')) {
            const mammoth = require('mammoth');
            const b64Data = extractedText.split(',')[1];
            const buffer = Buffer.from(b64Data, 'base64');
            const docData = await mammoth.extractRawText({ buffer: buffer });
            extractedText = docData.value;
        } else if (extractedText.startsWith('data:text/plain;base64,')) {
            const b64Data = extractedText.split(',')[1];
            extractedText = Buffer.from(b64Data, 'base64').toString('utf8');
        }

        const system = `You are a strict document analysis assistant. You must answer the user's question based strictly and exclusively on the provided Document Context. Do NOT use outside knowledge. If the answer cannot be found in the document, reply: "I cannot answer this based on the provided document."`;
        const user = `Document Context:\n"""\n${extractedText}\n"""\n\nQuestion:\n${query || 'What is this document about?'}`;

        const result = await ollamaAsk(apiUrl.replace(/\/+$/, ''), model, system, user);
        res.json({ result });
    } catch (e) {
        res.status(502).json({ error: e.message });
    }
});


/* 3. TEXT TO QUERY (Generate SQL + Execute + Return Data)
   Body: { apiUrl, model, text/prompt, ddl, dialect, host, port, database, user, password } */
app.post('/api/tools/text-to-query', async (req, res) => {
    const { apiUrl, model, text, prompt, ddl, dialect, host, port: dbPort, database: dbName, user: dbUser, password: dbPassword } = req.body;

    if (!apiUrl) return res.status(400).json({ error: 'apiUrl is required' });

    const userQuestion = (prompt || text || '').trim();
    if (!userQuestion) return res.status(400).json({ error: 'text/prompt (your question) is required' });

    const dbType = dialect || 'PostgreSQL';

    // ── EXTRACT TABLE NAMES FROM DDL ──
    let extractedTables = [];
    if (ddl) {
        const tableMatches = ddl.match(/CREATE\s+TABLE\s+(\w+)\s*\(/gi);
        if (tableMatches) {
            extractedTables = tableMatches.map(m => m.replace(/CREATE\s+TABLE\s+/i, '').replace(/\s*\(.*/, '').trim());
        }
    }

    // ── BUILD SYSTEM PROMPT WITH EXPLICIT TABLE NAMES ──
    let system = `You are an expert SQL developer for ${dbType}.

ABSOLUTE RULES - VIOLATION WILL CAUSE FAILURE:`;

    if (extractedTables.length > 0) {
        system += `\n\n🔴 THE ONLY TABLES THAT EXIST IN THIS DATABASE ARE (USE THESE EXACT NAMES):\n`;
        extractedTables.forEach((t, i) => system += `   ${i + 1}. "${t}"\n`);
        system += `\n🔴 DO NOT use any other table names. Do not pluralize or modify these names.`;
        system += `\n🔴 If user asks for "employees", use "${extractedTables.find(t => t.toLowerCase().includes('employ')) || extractedTables[0]}"`;
        system += `\n🔴 If user asks for "users", check if there's a similar table above first.`;
    }

    system += `\n\nRULES:
1. Return ONLY raw SQL - no explanations, no markdown code blocks, no \`\`\`sql wrappers
2. Use EXACT column names from the schema provided
3. Use proper JOINs with foreign keys shown in schema
4. Add LIMIT 100 at end of SELECT queries`;

    let userPrompt = '';
    if (ddl && ddl.trim()) {
        userPrompt = `## COMPLETE DATABASE SCHEMA:
\`\`\`sql
 ${ddl}
\`\`\`

AVAILABLE TABLES: [${extractedTables.join(', ')}]

QUESTION: "${userQuestion}"

Write the SQL query using ONLY tables listed above.`;
    } else {
        userPrompt = `QUESTION: "${userQuestion}"\n\nGenerate SQL query.`;
    }

    try {
        // ── STEP 1: Generate SQL using Ollama ──
        const url = apiUrl.replace(/\/+$/, '');
        const response = await fetch(url + '/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model: model || 'llama3.2',
                stream: false,
                messages: [
                    { role: 'system', content: system },
                    { role: 'user', content: userPrompt }
                ],
                options: { temperature: 0.01, top_p: 0.9 }
            })
        });
        const data = await response.json();
        if (data.error) return res.status(502).json({ error: data.error });

        let sqlQuery = (data.message && data.message.content)
            ? data.message.content.trim() : JSON.stringify(data);

        // Clean up markdown
        sqlQuery = sqlQuery
            .replace(/^```sql\n?/gi, '')
            .replace(/^```SQL\n?/gi, '')
            .replace(/^```\n?/g, '')
            .replace(/\n?```$/g, '')
            .replace(/^--.*$/gm, '')
            .trim();

        // ── STEP 1.5: POST-PROCESSING - Fix wrong table names ──
        if (extractedTables.length > 0) {
            extractedTables.forEach(table => {
                // Common wrong guesses - replace with correct table name
                const wrongNames = [
                    table + 's',           // employee -> employees
                    table.replace(/e$/, ''), // employee -> employ
                    table.replace(/ee$/, 'y'), // employee -> employy
                    table.slice(0, -1),   // employee -> employee
                    table.toLowerCase(),
                    table.charAt(0).toUpperCase() + table.slice(1)
                ];

                // Also handle common English pluralizations
                if (table.endsWith('y')) {
                    wrongNames.push(table.replace(/y$/, 'ies')); // category -> categories
                } else {
                    wrongNames.push(table + 's');
                    wrongNames.push(table + 'es');
                }

                wrongNames.forEach(wrong => {
                    // Case-insensitive replacement in SQL keywords context
                    const regex = new RegExp(`\\b${wrong}\\b`, 'gi');
                    sqlQuery = sqlQuery.replace(regex, table);
                });
            });

            // Specific fix: employees -> employeee, user -> users etc.
            const specificFixes = {
                'employees': 'employeee',
                'employee': 'employeee',
                'employe': 'employeee',
                'genders': 'Gender',
                'gender': 'Gender',
                'organizations': 'organization',
                'designation': 'designation',
                'designations': 'designation',
                'qualifications': 'qualification',
                'lab_nos': 'Lab_no',
                'lab_no': 'Lab_no'
            };

            Object.entries(specificFixes).forEach(([wrong, correct]) => {
                if (extractedTables.includes(correct)) {
                    const regex = new RegExp(`\\b${wrong}\\b`, 'gi');
                    sqlQuery = sqlQuery.replace(regex, correct);
                }
            });
        }

        if (sqlQuery && !sqlQuery.endsWith(';')) sqlQuery += ';';

        // ── STEP 2: Execute Query & Return Data ──
        let executionResult = null;
        let columnHeaders = [];
        let rowData = [];
        let rowCount = 0;

        if (host && dbName && dbUser) {
            const Pool = require('pg').Pool;
            const pool = new Pool({
                host,
                port: parseInt(dbPort) || 5432,
                database: dbName,
                user: dbUser,
                password: dbPassword || '',
                ssl: false
            });

            try {
                const client = await pool.connect();

                const safePrefixes = ['SELECT', 'SHOW', 'DESCRIBE', 'EXPLAIN', 'WITH'];
                const firstWord = sqlQuery.split(/\s+/)[0]?.toUpperCase();

                if (!safePrefixes.includes(firstWord)) {
                    executionResult = { error: '⚠️ Only SELECT/SHOW queries allowed.' };
                } else {
                    const queryResult = await client.query(sqlQuery);
                    rowCount = queryResult.rowCount || 0;

                    if (queryResult.fields && queryResult.fields.length > 0) {
                        columnHeaders = queryResult.fields.map(f => f.name);
                    }

                    rowData = queryResult.rows.map(row => {
                        const obj = {};
                        columnHeaders.forEach(col => {
                            let val = row[col];
                            if (val === null) val = 'NULL';
                            else if (val instanceof Date) val = val.toISOString().slice(0, 19).replace('T', ' ');
                            else if (typeof val === 'object') val = JSON.stringify(val);
                            obj[col] = String(val);
                        });
                        return obj;
                    });

                    executionResult = { success: true, rowCount, columns: columnHeaders, rows: rowData };
                }

                client.release();
            } catch (queryErr) {
                executionResult = { error: `❌ Error: ${queryErr.message}` };
            } finally {
                await pool.end();
            }
        }

        // ── STEP 3: Build Beautiful Table Output ──
        let output = '';

        output += `╔═══════════════════════════════════════════════════════╗\n`;
        output += `║  📊 TEXT TO QUERY RESULTS                              ║\n`;
        output += `╚═══════════════════════════════════════════════════════╝\n\n`;
        output += `❓ Question: "${userQuestion}"\n\n`;

        output += `┌──────────────────────────────────────────────────────┐\n`;
        output += `│  🔧 GENERATED SQL QUERY                               │\n`;
        output += `└──────────────────────────────────────────────────────┘\n\n`;
        output += `${sqlQuery}\n\n`;

        output += `┌──────────────────────────────────────────────────────┐\n`;
        output += `│  📋 EXECUTION RESULTS                                 │\n`;
        output += `└──────────────────────────────────────────────────────┘\n`;

        if (executionResult && executionResult.success) {
            output += `\n✅ Status: SUCCESS  |  📊 Rows: ${rowCount}  |  📑 Columns: ${columnHeaders.length}\n\n`;

            if (rowCount === 0) {
                output += `┌──────────────────────────────────────────┐\n`;
                output += `│  ⚠️  No matching data found              │\n`;
                output += `└──────────────────────────────────────────┘\n`;
            } else {
                const colWidths = columnHeaders.map(h => Math.min(Math.max(String(h).length, ...rowData.map(r => String(r[h] || '').length)), 22));
                const totalWidth = colWidths.reduce((a, b) => a + b + 3, 0) + 1;

                output += `┌${'─'.repeat(totalWidth)}┐\n`;

                let headerLine = '│';
                columnHeaders.forEach((col, i) => { headerLine += ' ' + col.padEnd(colWidths[i]) + ' │'; });
                output += headerLine + '\n';

                output += `├${'─'.repeat(totalWidth)}┤\n`;

                const displayRows = rowData.slice(0, 50);
                displayRows.forEach(row => {
                    let line = '│';
                    columnHeaders.forEach((col, i) => {
                        let cellVal = String(row[col] || '');
                        if (cellVal.length > colWidths[i]) cellVal = cellVal.substring(0, colWidths[i] - 2) + '..';
                        line += ' ' + cellVal.padEnd(colWidths[i]) + ' │';
                    });
                    output += line + '\n';
                });

                output += `└${'─'.repeat(totalWidth)}┘\n`;

                if (rowData.length > 50) output += `\n... and ${rowData.length - 50} more rows\n`;
            }
        } else if (executionResult && executionResult.error) {
            output += `\n${executionResult.error}\n`;
            if (!host || !dbName) output += `\n💡 Connect Database Node to execute!\n`;
        } else {
            output += `\n⏳ No database connected.\n💡 Connect Database Node → Text to Query Node\n`;
        }

        res.json({ result: output, query: sqlQuery, data: executionResult?.rows || null, columns: columnHeaders, rowCount });

    } catch (e) {
        console.error('Text to Query Error:', e.message);
        res.status(502).json({ error: e.message });
    }
});
/* 4. PHOTOSENSE
   Body: { apiUrl, model, imageBase64, analysisType, confidence }
   Note: requires a vision-capable model (e.g. llava) */
app.post('/api/tools/photosense', async (req, res) => {
    const { apiUrl, model, imageBase64, analysisType, confidence } = req.body;
    if (!apiUrl) return res.status(400).json({ error: 'apiUrl is required' });
    if (!imageBase64) return res.status(400).json({ error: 'imageBase64 is required' });

    const typePrompts = {
        'Full Analysis': 'Perform a full analysis: describe the scene, objects, people, text visible, colors, and mood.',
        'Object Detection': 'List all objects you detect in this image with their approximate locations.',
        'Face Detection': 'Detect and describe any faces or people in this image.',
        'OCR / Text': 'Extract and transcribe all visible text in this image.',
        'Scene Classification': 'Classify the scene (indoor/outdoor, type of location, time of day, etc.).',
        'Emotion Detection': 'Detect the emotions and expressions of people in this image.'
    };

    const promptText = typePrompts[analysisType] || typePrompts['Full Analysis'];

    try {
        const url = apiUrl.replace(/\/+$/, '');
        const base64 = imageBase64.replace(/^data:image\/\w+;base64,/, '');

        const response = await fetch(url + '/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model: model || 'llava',
                stream: false,
                messages: [{
                    role: 'user',
                    content: promptText,
                    images: [base64]
                }]
            })
        });
        const data = await response.json();
        if (data.error) return res.status(502).json({ error: data.error });
        const result = (data.message && data.message.content) ? data.message.content.trim() : JSON.stringify(data);
        res.json({ result });
    } catch (e) {
        res.status(502).json({ error: e.message });
    }
});


/* 5. LANGUAGE TRANSLATOR
   Body: { apiUrl, model, text, sourceLang, targetLang, tone } */
app.post('/api/tools/translate', async (req, res) => {
    const { apiUrl, model, text, sourceLang, targetLang, tone } = req.body;
    if (!apiUrl) return res.status(400).json({ error: 'apiUrl is required' });
    if (!text) return res.status(400).json({ error: 'text is required' });

    const toneNote = tone === 'Formal' ? 'Use formal language.' : tone === 'Casual' ? 'Use casual, conversational language.' : 'Use precise technical language.';
    const srcNote = sourceLang && sourceLang !== 'Auto Detect' ? `from ${sourceLang}` : '';

    const system = `You are a professional translator. Translate text accurately. ${toneNote} Return ONLY the translated text, nothing else.`;
    const user = `Translate the following text ${srcNote} to ${targetLang || 'Hindi'}:\n\n${text}`;

    try {
        const result = await ollamaAsk(apiUrl.replace(/\/+$/, ''), model, system, user);
        res.json({ result });
    } catch (e) {
        res.status(502).json({ error: e.message });
    }
});


/* 6. CONTENT GENERATION
   Body: { apiUrl, model, topic, contentType, tone, wordCount } */
app.post('/api/tools/content-generation', async (req, res) => {
    const { apiUrl, model, topic, contentType, tone, wordCount } = req.body;
    if (!apiUrl) return res.status(400).json({ error: 'apiUrl is required' });
    if (!topic) return res.status(400).json({ error: 'topic is required' });

    const wordMap = {
        'Short (~100 words)': 'approximately 100 words',
        'Medium (~300 words)': 'approximately 300 words',
        'Long (~600 words)': 'approximately 600 words'
    };

    const system = `You are an expert content writer. Write in a ${tone || 'Professional'} tone.`;
    const user = `Write a ${contentType || 'Blog Post'} about the following topic in ${wordMap[wordCount] || 'approximately 300 words'}.\n\nTopic / Brief:\n${topic}`;

    try {
        const result = await ollamaAsk(apiUrl.replace(/\/+$/, ''), model, system, user);
        res.json({ result });
    } catch (e) {
        res.status(502).json({ error: e.message });
    }
});


/* 7. CHANGE DETECTION
   Body: { apiUrl, model, original, modified, mode, format } */
app.post('/api/tools/change-detection', async (req, res) => {
    const { apiUrl, model, original, modified, mode, format } = req.body;
    if (!apiUrl) return res.status(400).json({ error: 'apiUrl is required' });
    if (!original) return res.status(400).json({ error: 'original (in1) input is required' });
    if (!modified) return res.status(400).json({ error: 'modified (in2) input is required' });

    const formatNote = {
        'Unified Diff': 'Present it as a unified diff (+ for additions, - for removals).',
        'Side by Side': 'Present changes in a side-by-side comparison format.',
        'Summary Only': 'Provide a plain English summary of what changed.'
    };

    // Check if inputs look like images (base64)
    const isImageOriginal = original.startsWith('data:image') || (original.length > 200 && !original.includes(' '));
    const isImageModified = modified.startsWith('data:image') || (modified.length > 200 && !modified.includes(' '));

    if (isImageOriginal && isImageModified) {
        // Vision-based comparison
        try {
            const url = apiUrl.replace(/\/+$/, '');
            const b1 = original.replace(/^data:image\/\w+;base64,/, '');
            const b2 = modified.replace(/^data:image\/\w+;base64,/, '');

            const response = await fetch(url + '/api/chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    model: model || 'llava',
                    stream: false,
                    messages: [{
                        role: 'user',
                        content: `You are a visual change detection AI. I will show you two images. Compare them carefully and describe ALL differences you can find. ${formatNote[format] || formatNote['Summary Only']} Mode: ${mode || 'Visual Change (Image)'}. The first image is the ORIGINAL and the second is the MODIFIED version.`,
                        images: [b1, b2]
                    }]
                })
            });
            const data = await response.json();
            if (data.error) return res.status(502).json({ error: data.error });
            const result = (data.message && data.message.content) ? data.message.content.trim() : JSON.stringify(data);
            return res.json({ result });
        } catch (e) {
            return res.status(502).json({ error: e.message });
        }
    }

    // Text-based comparison
    const system = 'You are a precise change detection assistant. Compare inputs exactly.';
    const user = `Compare the following two texts and detect all changes.\nMode: ${mode || 'Text Diff'}. ${formatNote[format] || formatNote['Summary Only']}\n\n--- ORIGINAL ---\n${original}\n\n--- MODIFIED ---\n${modified}`;

    try {
        const result = await ollamaAsk(apiUrl.replace(/\/+$/, ''), model, system, user);
        res.json({ result });
    } catch (e) {
        res.status(502).json({ error: e.message });
    }
});


/* 8. NET CRAWLER
   Body: { url, extractType, depth, selector }
   Note: crawls via server-side fetch (no Ollama needed for basic extraction) */
app.post('/api/tools/net-crawler', async (req, res) => {
    const { url, extractType, depth, selector, apiUrl, model } = req.body;
    if (!url) return res.status(400).json({ error: 'url is required' });

    try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 30000);

        const response = await fetch(url, {
            signal: controller.signal,
            headers: { 'User-Agent': 'Mozilla/5.0 (compatible; FlowCraft-Crawler/1.0)' }
        });
        clearTimeout(timeout);

        const html = await response.text();

        const stripTags = (s) => s.replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
            .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
            .replace(/<[^>]+>/g, ' ')
            .replace(/\s{2,}/g, ' ')
            .trim();

        const extractLinks = (s) => {
            const re = /href=["']([^"']+)["']/gi;
            const links = []; let m;
            while ((m = re.exec(s)) !== null) links.push(m[1]);
            return [...new Set(links)].slice(0, 100).join('\n');
        };

        const extractImages = (s) => {
            const re = /src=["']([^"']+\.(jpg|jpeg|png|gif|webp|svg))["']/gi;
            const imgs = []; let m;
            while ((m = re.exec(s)) !== null) imgs.push(m[1]);
            return [...new Set(imgs)].slice(0, 50).join('\n');
        };

        const extractHeadings = (s) => {
            const re = /<h[1-6][^>]*>([\s\S]*?)<\/h[1-6]>/gi;
            const heads = []; let m;
            while ((m = re.exec(s)) !== null) heads.push(stripTags(m[1]));
            return heads.join('\n');
        };

        let rawResult = '';
        switch (extractType) {
            case 'Links Only': rawResult = extractLinks(html); break;
            case 'Images Only': rawResult = extractImages(html); break;
            case 'Headings & Summary': rawResult = extractHeadings(html); break;
            case 'Structured Data':
            case 'Custom Selector':
            case 'Full Page Text':
            default: rawResult = stripTags(html).slice(0, 8000); break;
        }

        if (apiUrl && model && extractType !== 'Links Only' && extractType !== 'Images Only') {
            const system = 'You are a web data extraction assistant. Analyze the crawled content and present it clearly.';
            const user = `Extracted content from ${url}:\n\n${rawResult}\n\nProvide a clean, structured summary.`;
            try {
                const aiResult = await ollamaAsk(apiUrl.replace(/\/+$/, ''), model, system, user);
                return res.json({ result: aiResult, raw: rawResult });
            } catch (_) { /* fall through to raw */ }
        }

        res.json({ result: rawResult });
    } catch (e) {
        if (e.name === 'AbortError') return res.status(504).json({ error: 'Crawl timed out (30s)' });
        res.status(502).json({ error: 'Failed to fetch URL: ' + e.message });
    }
});


/* 9. YOUTUBE DEEP SCANNER (Channel Mode + Single Video)
   Body: { apiUrl, model, youtubeUrl, channel, analysisType, language, videoCount } */
app.post('/api/tools/youtube-scanner', async (req, res) => {
    const { apiUrl, model, youtubeUrl, channel, analysisType, language, videoCount } = req.body;
    if (!apiUrl) return res.status(400).json({ error: 'apiUrl is required' });

    // ═══ CHANNEL NAME → ID MAP (Backend Only - Hidden from User) ═══
    const channelMap = {
        'Aaj Tak': 'UCt4t-jeY85JegMlZ-E5UWtA',
        'ANI': 'UCtFQDgA8J8_iiwc5-KoAQlg',
        'Saama Tv': 'UCg4pOcQ9GUsh72iyD2n-jJA',
        'Career247': 'UCHyu2gwfAkOXWroIjvxVUCg',
        'Ary News': 'UCKZ9Tg4jFww1VbBtzW1UIeA',
        'Indian Air Force': 'UC4k15Q51NS6ws5Xkt-GDBBw',
        'ADGPI-INDIAN ARMY': 'UCvfH3RaugUbIqY-80iOED4Q',
        'ISPR Official': 'UCEwlPFzuck7KyNAnsujkkFg',
        'Indian Defence Updates': 'UCWUFwrNEs9MnFTc8LcQh8Pg',
        'US army': 'UCs6bj7e__tT_m3sxxhazhA',
        'NDTV News': 'UC9CYT9gSNLevX5YE2dN-K0Q',
        'DD News': 'UCGDQNvybfDDeGTf4GtigXaw',
        'Republic World': 'UCwqusr8YDwM-3mE0TfJHzw',
        'Zee News': 'UCIvaYmXn910QMdemBG3v1pQ',
        'WION': 'UC_gUM8rL-Lrg6O3adPW9K1g',
        'First-Post News': 'UCef1-8eOpJgud7szVPlZQAQ',
        'Al Jazeera English': 'UNye-wNBqNL5ZzHSJj3l8Bg'
    };

    let channelId = null;
    let channelName = '';
    let targetVideoId = null;

    // ── Determine mode: Channel or Manual URL ──
    if (channel && channel !== '-- Enter URL Manually --') {
        // Look up channel name in map
        channelId = channelMap[channel];
        channelName = channel;

        if (!channelId) {
            return res.status(400).json({ error: `Channel "${channel}" not found in database` });
        }
    }

    // If manual URL provided, extract video ID
    if (youtubeUrl && youtubeUrl.trim()) {
        const idMatch = youtubeUrl.match(/(?:v=|youtu\.be\/|embed\/|shorts\/)([A-Za-z0-9_-]{11})/);
        if (idMatch) targetVideoId = idMatch[1];
    }

    // If no input provided, just return the stable video directly (bypassing validation)
    if (!channelId && !targetVideoId) {
        const videoPath = '/api/static/sample.mp4'; // TODO: Update this
        return res.json({ result: `╔══════════════════════════════════════════════════════════╗\n║  🎬 YOUTUBE DEEP SCANNER — STABLE VIDEO                 ║\n╚══════════════════════════════════════════════════════════╝\n\n[VID_START]${videoPath}[VID_END]\n` });
    }

    try {
        let output = '';

        // ══════════════════════════════════════
        //   MODE 1: CHANNEL ANALYSIS
        // ══════════════════════════════════════
        if (channelId) {
            const countMap = { 'Latest 1 Video': 1, 'Latest 3 Videos': 3, 'Latest 5 Videos': 5, 'Latest 10 Videos': 10 };
            const maxVideos = countMap[videoCount] || 3;

            output += `╔══════════════════════════════════════════════════════════╗\n`;
            output += `║  🎬 YOUTUBE DEEP SCANNER — CHANNEL ANALYSIS             ║\n`;
            output += `╚══════════════════════════════════════════════════════════╝\n\n`;
            output += `📺  Channel : ${channelName}\n`;
            output += `🔍  Analysis: ${analysisType || 'Summary'}\n`;
            output += `📊  Videos  : Latest ${maxVideos}\n`;
            output += `──────────────────────────────────────────────────────────\n\n`;

            // Fetch channel's latest videos via RSS feed (no API key needed)
            const rssUrl = `https://www.youtube.com/feeds/videos.xml?channel_id=${channelId}`;

            const controller = new AbortController();
            setTimeout(() => controller.abort(), 15000);

            const rssRes = await fetch(rssUrl, { signal: controller.signal });

            if (!rssRes.ok) {
                return res.status(502).json({ error: `Failed to fetch channel "${channelName}". RSS error: ${rssRes.status}` });
            }

            const rssText = await rssRes.text();
            const entryMatches = rssText.match(/<entry>([\s\S]*?)<\/entry>/g) || [];

            if (entryMatches.length === 0) {
                output += `⚠️  No videos found for channel "${channelName}". The channel may have no public uploads.\n`;
                return res.json({ result: output });
            }

            // Parse video entries
            let videosToProcess = [];
            for (let i = 0; i < Math.min(entryMatches.length, maxVideos); i++) {
                const entry = entryMatches[i];
                const titleMatch = entry.match(/<title[^>]*>([^<]+)<\/title>/);
                const vidMatch = entry.match(/yt:videoId>([^<]+)</);
                const pubMatch = entry.match(/<published>([^<]+)<\/published>/);

                if (vidMatch) {
                    videosToProcess.push({
                        id: vidMatch[1],
                        title: titleMatch ? titleMatch[1].trim() : 'Unknown',
                        published: pubMatch ? pubMatch[1] : ''
                    });
                }
            }

            output += `📹 Found ${videosToProcess.length} recent video(s)\n\n`;

            // Process each video
            for (let idx = 0; idx < videosToProcess.length; idx++) {
                const video = videosToProcess[idx];

                output += `┌────────────────────────────────────────────────────┐\n`;
                output += `│  📌 VIDEO ${idx + 1} of ${videosToProcess.length}\n`;
                output += `└────────────────────────────────────────────────────┘\n`;
                output += `Title: ${video.title}\n`;
                output += `Link : https://www.youtube.com/watch?v=${video.id}\n\n`;

                // Get transcript
                let transcript = '';
                try {
                    const langCode = language === 'Auto' ? 'en' : (language?.toLowerCase()?.slice(0, 2) || 'en');
                    const ttUrl = `https://www.youtube.com/api/timedtext?v=${video.id}&lang=${langCode}&fmt=json3`;
                    const ttRes = await fetch(ttUrl, { headers: { 'User-Agent': 'Mozilla/5.0' } });
                    const ttData = await ttRes.json();

                    if (ttData.events) {
                        transcript = ttData.events
                            .filter(e => e.segs)
                            .map(e => e.segs.map(s => s.utf8).join(''))
                            .join(' ')
                            .replace(/\s+/g, ' ')
                            .trim()
                            .slice(0, 5000);
                    }
                } catch (_) {
                    transcript = '(Transcript not available for this video)';
                }

                // AI Analysis prompt based on type
                const prompts = {
                    'Full Transcript': `Return the FULL transcript exactly as-is:\n\n${transcript}`,
                    'Summary': `Summarize this YouTube video titled "${video.title}" in 3-5 concise sentences:\n\n${transcript}`,
                    'Key Insights': `Extract 5-10 key insights from "${video.title}":\n\n${transcript}`,
                    'Chapter Breakdown': `Create a chapter/timestamp breakdown for "${video.title}":\n\n${transcript}`,
                    'Comment Sentiment': `Analyze what audience sentiment would be for "${video.title}":\n\n${transcript}`,
                    'Topic Tags': `Generate 10-15 relevant topic tags/keywords for "${video.title}":\n\n${transcript}`
                };

                const systemPrompt = 'You are an expert YouTube content analyst. Provide clear, actionable insights.';
                const userPrompt = prompts[analysisType] || prompts['Summary'];

                try {
                    const url = apiUrl.replace(/\/+$/, '');
                    const aiRes = await fetch(url + '/api/chat', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            model: model || 'llama3.2',
                            stream: false,
                            messages: [
                                { role: 'system', content: systemPrompt },
                                { role: 'user', content: userPrompt }
                            ]
                        })
                    });
                    const aiData = await aiRes.json();
                    const result = aiData.message?.content ? aiData.message.content.trim() : JSON.stringify(aiData);

                    output += `📋 Analysis Result:\n${'─'.repeat(50)}\n${result}\n\n`;
                } catch (aiErr) {
                    output += `⚠️  AI Error: ${aiErr.message}\n\n`;
                }
            }

            output += `╔══════════════════════════════════════════════════════════╗\n`;
            output += `║  ✅ COMPLETE — Analyzed ${videosToProcess.length} video(s) from "${channelName}"    ║\n`;
            output += `╚══════════════════════════════════════════════════════════╝\n`;

        } else {
            // ══════════════════════════════════════
            //   MODE 2: SINGLE VIDEO (Manual URL)
            // ══════════════════════════════════════
            if (!targetVideoId) {
                return res.status(400).json({ error: 'Invalid YouTube URL format' });
            }

            const pageRes = await fetch(`https://www.youtube.com/watch?v=${targetVideoId}`, {
                headers: { 'User-Agent': 'Mozilla/5.0' }
            });
            const pageHtml = await pageRes.text();

            const titleMatch = pageHtml.match(/<title>([^<]+)<\/title>/);
            const title = titleMatch ? titleMatch[1].replace(' - YouTube', '').trim() : targetVideoId;

            let transcript = '';
            try {
                const langCode = language === 'Auto' ? 'en' : (language?.toLowerCase()?.slice(0, 2) || 'en');
                const ttUrl = `https://www.youtube.com/api/timedtext?v=${targetVideoId}&lang=${langCode}&fmt=json3`;
                const ttRes = await fetch(ttUrl, { headers: { 'User-Agent': 'Mozilla/5.0' } });
                const ttData = await ttRes.json();

                if (ttData.events) {
                    transcript = ttData.events
                        .filter(e => e.segs)
                        .map(e => e.segs.map(s => s.utf8).join(''))
                        .join(' ')
                        .replace(/\s+/g, ' ')
                        .trim()
                        .slice(0, 6000);
                }
            } catch (_) {
                transcript = '(Transcript not available)';
            }

            const prompts = {
                'Full Transcript': `Return FULL transcript:\n\n${transcript}`,
                'Summary': `Summarize "${title}" in 3-5 sentences:\n\n${transcript}`,
                'Key Insights': `List 5-10 insights from "${title}":\n\n${transcript}`,
                'Chapter Breakdown': `Create chapters for "${title}":\n\n${transcript}`,
                'Comment Sentiment': `Sentiment analysis of "${title}":\n\n${transcript}`,
                'Topic Tags': `Tags for "${title}":\n\n${transcript}`
            };

            output += `╔══════════════════════════════════════════════════════════╗\n`;
            output += `║  🎬 YOUTUBE DEEP SCANNER — VIDEO ANALYSIS               ║\n`;
            output += `╚══════════════════════════════════════════════════════════╝\n\n`;
            output += `📺 Title   : ${title}\n`;
            output += `🔗 URL     : https://www.youtube.com/watch?v=${targetVideoId}\n`;
            output += `🔍 Type    : ${analysisType}\n`;
            output += `──────────────────────────────────────────────────────────\n\n`;

            const url = apiUrl.replace(/\/+$/, '');
            const aiRes = await fetch(url + '/api/chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    model: model || 'llama3.2',
                    stream: false,
                    messages: [
                        { role: 'system', content: 'You are a YouTube content analyst.' },
                        { role: 'user', content: prompts[analysisType] || prompts['Summary'] }
                    ]
                })
            });
            const aiData = await aiRes.json();
            const result = aiData.message?.content ? aiData.message.content.trim() : JSON.stringify(aiData);

            output += `${result}\n`;
        }

        // Add a stable video to the output
        const videoPath = '/api/static/sample.mp4'; // TODO: Update this to the actual video path
        output += `\n\n[VID_START]${videoPath}[VID_END]\n`;

        res.json({ result: output });

    } catch (e) {
        console.error('YouTube Scanner Error:', e.message);
        res.status(502).json({ error: e.message });
    }
});

/* 10. RETOUCH AI */
app.post('/api/tools/retouch-ai', async (req, res) => {
    const { apiUrl, model, imageBase64, operation, strength } = req.body;
    if (!apiUrl) return res.status(400).json({ error: 'apiUrl is required' });
    if (!imageBase64) return res.status(400).json({ error: 'imageBase64 is required' });

    const opPrompts = {
        'Auto Enhance': 'Describe what enhancements this image needs (brightness, contrast, saturation, sharpness). Be specific with values.',
        'Background Remove': 'Describe the main subject and background of this image for background removal processing.',
        'Background Replace': 'Describe the main subject to keep and suggest 3 replacement background options.',
        'Skin Retouching': 'Analyze the skin tones and texture in this image. Describe what retouching steps are needed.',
        'Color Correction': 'Analyze the color balance of this image. Describe specific color correction needed (white balance, hue, saturation).',
        'Upscale (2x)': 'Analyze the image quality and describe what details should be enhanced when upscaling 2x.',
        'Upscale (4x)': 'Analyze the image quality and describe what details should be enhanced when upscaling 4x.',
        'Noise Reduction': 'Analyze the noise level in this image and describe the noise reduction approach needed.',
        'Object Removal': 'Identify objects in this image that could be removed, and describe the inpainting approach.'
    };

    const strengthNote = { 'Subtle': 'Apply subtle, minimal changes.', 'Medium': 'Apply moderate changes.', 'Strong': 'Apply strong, prominent changes.' };

    try {
        const base64 = imageBase64.replace(/^data:image\/\w+;base64,/, '');
        const url = apiUrl.replace(/\/+$/, '');

        const response = await fetch(url + '/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model: model || 'llava',
                stream: false,
                messages: [{
                    role: 'user',
                    content: `You are a professional photo retouching AI. ${opPrompts[operation] || opPrompts['Auto Enhance']} ${strengthNote[strength] || ''}`,
                    images: [base64]
                }]
            })
        });
        const data = await response.json();
        if (data.error) return res.status(502).json({ error: data.error });
        const result = (data.message && data.message.content) ? data.message.content.trim() : JSON.stringify(data);
        res.json({ result, operation, strength });
    } catch (e) {
        res.status(502).json({ error: e.message });
    }
});


/* ══════════════════════════════════════════════
      POSTGRES MEMORY NODE
      Body: { host, port, database, user, password }
      ══════════════════════════════════════════════ */
app.post('/api/postgres/init', async (req, res) => {
    const { host, port, database, user, password } = req.body;

    if (!host || !database || !user) {
        return res.status(400).json({ error: 'host, database, and user are required' });
    }

    const pool = new Pool({ host, port: port || 5432, database, user, password, ssl: false });

    try {
        const client = await pool.connect();
        try {
            // Ensure table exists
            await client.query(`
                                CREATE TABLE IF NOT EXISTS chat_history (
                                        id SERIAL PRIMARY KEY,
                                        session_id VARCHAR(255) NOT NULL,
                                        role VARCHAR(50) NOT NULL,
                                        content TEXT NOT NULL,
                                        created_at TIMESTAMP DEFAULT NOW()
                                )
                        `);
            res.json({ success: true, message: 'Connected and table ready' });
        } finally {
            client.release();
        }
    } catch (err) {
        console.error('Postgres Init Error:', err.message);
        res.status(500).json({ error: err.message });
    } finally {
        await pool.end();
    }
});

// GET / POST History
app.all('/api/postgres/history', async (req, res) => {
    const { host, port, database, user, password, session_id, role, content } = req.body;
    if (!host || !database || !user || !session_id) {
        return res.status(400).json({ error: 'host, database, user, and session_id are required' });
    }

    const pool = new Pool({ host, port: port || 5432, database, user, password, ssl: false });
    try {
        const client = await pool.connect();
        try {
            if (req.method === 'POST') {
                if (!role || !content) return res.status(400).json({ error: 'role and content required' });
                await client.query('INSERT INTO chat_history (session_id, role, content) VALUES ($1, $2, $3)', [session_id, role, content]);
                res.json({ success: true });
            } else {
                const result = await client.query('SELECT role, content, created_at FROM chat_history WHERE session_id = $1 ORDER BY id ASC', [session_id]);
                res.json({ history: result.rows });
            }
        } finally {
            client.release();
        }
    } catch (err) {
        console.error('Postgres History Error:', err.message);
        res.status(500).json({ error: err.message });
    } finally {
        await pool.end();
    }
});


app.post('/api/postgres/databases', async (req, res) => {
    const { host, port, user, password } = req.body;
    if (!host || !user) {
        return res.status(400).json({ error: 'host and user are required' });
    }

    const pool = new Pool({ host, port: port || 5432, database: 'postgres', user, password, ssl: false });
    try {
        const client = await pool.connect();
        try {
            const result = await client.query('SELECT datname FROM pg_database WHERE datistemplate = false');
            const dbs = result.rows.map(r => r.datname);
            res.json({ databases: dbs });
        } finally {
            client.release();
        }
    } catch (err) {
        console.error('Postgres Databases Error:', err.message);
        res.status(500).json({ error: err.message });
    } finally {
        await pool.end();
    }
});

app.post('/api/postgres/tables', async (req, res) => {
    const { host, port, database, user, password } = req.body;
    if (!host || !database || !user) {
        return res.status(400).json({ error: 'host, database, and user are required' });
    }

    const pool = new Pool({ host, port: port || 5432, database, user, password, ssl: false });
    try {
        const client = await pool.connect();
        try {
            const result = await client.query("SELECT tablename FROM pg_catalog.pg_tables WHERE schemaname != 'pg_catalog' AND schemaname != 'information_schema'");
            const tables = result.rows.map(r => r.tablename);
            res.json({ tables });
        } finally {
            client.release();
        }
    } catch (err) {
        console.error('Postgres Tables Error:', err.message);
        res.status(500).json({ error: err.message });
    } finally {
        await pool.end();
    }
});


app.post('/api/postgres/ddl', async (req, res) => {
    const { host, port, database, user, password, table } = req.body;
    if (!host || !database || !user || !table) {
        return res.status(400).json({ error: 'host, database, user, and table are required' });
    }

    const pool = new Pool({ host, port: port || 5432, database, user, password, ssl: false });
    try {
        const client = await pool.connect();
        try {
            let ddlList = [];
            let tablesToProcess = [table];
            let processedTables = new Set();

            while (tablesToProcess.length > 0) {
                const currentTable = tablesToProcess.shift();
                if (processedTables.has(currentTable)) continue;
                processedTables.add(currentTable);

                const colRes = await client.query('SELECT column_name, data_type, character_maximum_length FROM information_schema.columns WHERE table_name = $1 ORDER BY ordinal_position', [currentTable]);
                if (colRes.rows.length === 0) continue;

                const pkRes = await client.query(`
                    SELECT kcu.column_name
                    FROM information_schema.table_constraints tc
                    JOIN information_schema.key_column_usage kcu ON tc.constraint_name = kcu.constraint_name AND tc.table_schema = kcu.table_schema
                    WHERE tc.constraint_type = 'PRIMARY KEY' AND tc.table_name = $1
                `, [currentTable]);
                const pks = pkRes.rows.map(r => r.column_name);

                const fkRes = await client.query(`
                    SELECT kcu.column_name, ccu.table_name AS foreign_table_name, ccu.column_name AS foreign_column_name
                    FROM information_schema.table_constraints AS tc
                    JOIN information_schema.key_column_usage AS kcu ON tc.constraint_name = kcu.constraint_name AND tc.table_schema = kcu.table_schema
                    JOIN information_schema.constraint_column_usage AS ccu ON ccu.constraint_name = tc.constraint_name AND ccu.table_schema = tc.table_schema
                    WHERE tc.constraint_type = 'FOREIGN KEY' AND tc.table_name = $1
                `, [currentTable]);

                let stmt = `CREATE TABLE ${currentTable} (\\n`;
                let cols = [];
                colRes.rows.forEach(r => {
                    let type = r.data_type === 'USER-DEFINED' ? 'VARCHAR' : r.data_type;
                    let def = `  ${r.column_name} ${type}`;
                    if (r.character_maximum_length) def += `(${r.character_maximum_length})`;
                    cols.push(def);
                });
                if (pks.length > 0) {
                    cols.push(`  PRIMARY KEY (${pks.join(', ')})`);
                }
                fkRes.rows.forEach(r => {
                    cols.push(`  FOREIGN KEY (${r.column_name}) REFERENCES ${r.foreign_table_name}(${r.foreign_column_name})`);
                    if (!processedTables.has(r.foreign_table_name)) {
                        tablesToProcess.push(r.foreign_table_name);
                    }
                });

                stmt += cols.join(',\\n') + '\\n);';
                ddlList.push(stmt);
            }

            const finalDdl = ddlList.reverse().join('\\n\\n');
            res.json({ ddl: finalDdl });
        } finally {
            client.release();
        }
    } catch (err) {
        console.error('Postgres DDL Error:', err.message);
        res.status(500).json({ error: err.message });
    } finally {
        await pool.end();
    }
});



/* ══════════════════════════════════════════════
   START SERVER
   ══════════════════════════════════════════════ */

const PORT = 3000;
const HOST = '192.168.56.1';

app.listen(PORT, HOST, () => {
    console.log('╔══════════════════════════════════════╗');
    console.log('║  FlowCraft server running            ║');
    console.log(`║  Network: http://${HOST}:${PORT}      ║`);
    console.log(`║  Local:   http://localhost:${PORT}     ║`);
    console.log('╚══════════════════════════════════════╝');
});