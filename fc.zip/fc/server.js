const express = require('express');
const path = require('path');
const { Pool } = require('pg');

const app = express();
app.use(express.json({ limit: '50mb' }));
app.use(express.static(path.join(__dirname)));

/* ── Ollama Proxy: avoids CORS ── */
async function ollamaProxy(targetPath, reqBody, res) {
    const apiUrl = (reqBody.apiUrl || '').replace(/\/+$/, '');
    if (!apiUrl) return res.status(400).json({ error: 'apiUrl is required' });

    try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 180000);

        const response = await fetch(apiUrl + targetPath, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(reqBody.payload || {}),
            signal: controller.signal
        });
        clearTimeout(timeout);

        const text = await response.text();
        let data;
        try { data = JSON.parse(text); } catch { data = text; }

        res.status(response.status).json(data);
    } catch (err) {
        const msg = err.name === 'AbortError'
            ? 'Ollama request timed out (3 min)'
            : 'Cannot reach Ollama at ' + apiUrl + '. Is it running?';
        res.status(502).json({ error: msg });
    }
}

/* ── Ollama helper: send a prompt and get back text ── */
async function ollamaAsk(apiUrl, model, systemPrompt, userPrompt, images) {
    const msg = { role: 'user', content: userPrompt };
    if (images && images.length) msg.images = images;

    const response = await fetch(apiUrl + '/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            model: model || 'llama3.2',
            stream: false,
            messages: [
                { role: 'system', content: systemPrompt },
                msg
            ]
        })
    });
    const data = await response.json();
    if (data.error) throw new Error(data.error);
    return (data.message && data.message.content) ? data.message.content.trim() : JSON.stringify(data);
}

/* ──────────────────────────────────────────────
   Test connection — fetches model list
   ────────────────────────────────────────────── */
app.post('/api/ollama/test', async (req, res) => {
    const apiUrl = (req.body.apiUrl || '').replace(/\/+$/, '');
    if (!apiUrl) return res.status(400).json({ error: 'apiUrl is required' });

    try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 8000);

        const response = await fetch(apiUrl + '/api/tags', { signal: controller.signal });
        clearTimeout(timeout);
        const data = await response.json();
        res.status(response.status).json(data);
    } catch (err) {
        const msg = err.name === 'AbortError'
            ? 'Connection timed out. Is Ollama running?'
            : 'Cannot reach ' + apiUrl;
        res.status(502).json({ error: msg });
    }
});

/* Chat completion proxy */
app.post('/api/ollama/chat', (req, res) => {
    ollamaProxy('/api/chat', req.body, res);
});

/* Generate proxy (for future use) */
app.post('/api/ollama/generate', (req, res) => {
    ollamaProxy('/api/generate', req.body, res);
});


/* ══════════════════════════════════════════════
   TOOL ROUTES — all powered via local Ollama
   ══════════════════════════════════════════════ */

/* 1. TEXT SUMMARIZATION
   Body: { apiUrl, model, text, length, style } */
app.post('/api/tools/summarize', async (req, res) => {
    const { apiUrl, model, text, length, style } = req.body;
    if (!apiUrl) return res.status(400).json({ error: 'apiUrl is required' });
    if (!text) return res.status(400).json({ error: 'text is required' });

    const lengthMap = {
        'Short (1-2 sentences)': 'in 1-2 sentences',
        'Medium (1 paragraph)': 'in one concise paragraph',
        'Long (detailed)': 'in a detailed multi-paragraph summary'
    };
    const styleMap = {
        'Bullet Points': 'Use bullet points.',
        'Executive': 'Use an executive summary style.',
        'Simple': 'Use very simple, plain language.',
        'Neutral': ''
    };

    const system = 'You are a professional summarization assistant. Be accurate and concise.';
    const user = `Summarize the following text ${lengthMap[length] || 'in one paragraph'}. ${styleMap[style] || ''}\n\n${text}`;

    try {
        const result = await ollamaAsk(apiUrl.replace(/\/+$/, ''), model, system, user);
        res.json({ result });
    } catch (e) {
        res.status(502).json({ error: e.message });
    }
});


/* 2. DOCUMENT INTERACTION
   Body: { apiUrl, model, documentText, query, mode } */
app.post('/api/tools/document-interaction', async (req, res) => {
    const { apiUrl, model, documentText, query, mode } = req.body;
    if (!apiUrl) return res.status(400).json({ error: 'apiUrl is required' });
    if (!documentText) return res.status(400).json({ error: 'documentText is required' });

    const modeInstructions = {
        'Q&A': 'Answer the user\'s question based strictly on the document.',
        'Extract Key Points': 'Extract the key points from the document as a numbered list.',
        'Summarize': 'Provide a clear summary of the entire document.',
        'Find Data': 'Find and list all relevant data, numbers, and facts from the document.'
    };

    const system = `You are a document analysis assistant. ${modeInstructions[mode] || modeInstructions['Q&A']}`;
    const user = `Document:\n"""\n${documentText}\n"""\n\n${query || 'What is this document about?'}`;

    try {
        const result = await ollamaAsk(apiUrl.replace(/\/+$/, ''), model, system, user);
        res.json({ result });
    } catch (e) {
        res.status(502).json({ error: e.message });
    }
});


/* 3. TEXT TO QUERY
   Body: { apiUrl, model, text, dialect, schema } */
app.post('/api/tools/text-to-query', async (req, res) => {
    const { apiUrl, model, text, dialect, schema } = req.body;
    if (!apiUrl) return res.status(400).json({ error: 'apiUrl is required' });
    if (!text) return res.status(400).json({ error: 'text is required' });

    const system = `You are a database expert. Convert natural language to a ${dialect || 'SQL'} query. Return ONLY the query, no explanation.`;
    const user = `Schema / Context:\n${schema || 'No schema provided.'}\n\nConvert this to a ${dialect || 'SQL'} query:\n"${text}"`;

    try {
        const result = await ollamaAsk(apiUrl.replace(/\/+$/, ''), model, system, user);
        res.json({ result });
    } catch (e) {
        res.status(502).json({ error: e.message });
    }
});


/* 4. PHOTOSENSE
   Body: { apiUrl, model, imageBase64, analysisType, confidence }
   Note: requires a vision-capable model (e.g. llava) */
app.post('/api/tools/photosense', async (req, res) => {
    const { apiUrl, model, imageBase64, analysisType, confidence } = req.body;
    if (!apiUrl) return res.status(400).json({ error: 'apiUrl is required' });
    if (!imageBase64) return res.status(400).json({ error: 'imageBase64 is required' });

    const typePrompts = {
        'Full Analysis': 'Perform a full analysis: describe the scene, objects, people, text visible, colors, and mood.',
        'Object Detection': 'List all objects you detect in this image with their approximate locations.',
        'Face Detection': 'Detect and describe any faces or people in this image.',
        'OCR / Text': 'Extract and transcribe all visible text in this image.',
        'Scene Classification': 'Classify the scene (indoor/outdoor, type of location, time of day, etc.).',
        'Emotion Detection': 'Detect the emotions and expressions of people in this image.'
    };

    const promptText = typePrompts[analysisType] || typePrompts['Full Analysis'];

    try {
        const url = apiUrl.replace(/\/+$/, '');
        const base64 = imageBase64.replace(/^data:image\/\w+;base64,/, '');

        const response = await fetch(url + '/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model: model || 'llava',
                stream: false,
                messages: [{
                    role: 'user',
                    content: promptText,
                    images: [base64]
                }]
            })
        });
        const data = await response.json();
        if (data.error) return res.status(502).json({ error: data.error });
        const result = (data.message && data.message.content) ? data.message.content.trim() : JSON.stringify(data);
        res.json({ result });
    } catch (e) {
        res.status(502).json({ error: e.message });
    }
});


/* 5. LANGUAGE TRANSLATOR
   Body: { apiUrl, model, text, sourceLang, targetLang, tone } */
app.post('/api/tools/translate', async (req, res) => {
    const { apiUrl, model, text, sourceLang, targetLang, tone } = req.body;
    if (!apiUrl) return res.status(400).json({ error: 'apiUrl is required' });
    if (!text) return res.status(400).json({ error: 'text is required' });

    const toneNote = tone === 'Formal' ? 'Use formal language.' : tone === 'Casual' ? 'Use casual, conversational language.' : 'Use precise technical language.';
    const srcNote = sourceLang && sourceLang !== 'Auto Detect' ? `from ${sourceLang}` : '';

    const system = `You are a professional translator. Translate text accurately. ${toneNote} Return ONLY the translated text, nothing else.`;
    const user = `Translate the following text ${srcNote} to ${targetLang || 'Hindi'}:\n\n${text}`;

    try {
        const result = await ollamaAsk(apiUrl.replace(/\/+$/, ''), model, system, user);
        res.json({ result });
    } catch (e) {
        res.status(502).json({ error: e.message });
    }
});


/* 6. CONTENT GENERATION
   Body: { apiUrl, model, topic, contentType, tone, wordCount } */
app.post('/api/tools/content-generation', async (req, res) => {
    const { apiUrl, model, topic, contentType, tone, wordCount } = req.body;
    if (!apiUrl) return res.status(400).json({ error: 'apiUrl is required' });
    if (!topic) return res.status(400).json({ error: 'topic is required' });

    const wordMap = {
        'Short (~100 words)': 'approximately 100 words',
        'Medium (~300 words)': 'approximately 300 words',
        'Long (~600 words)': 'approximately 600 words'
    };

    const system = `You are an expert content writer. Write in a ${tone || 'Professional'} tone.`;
    const user = `Write a ${contentType || 'Blog Post'} about the following topic in ${wordMap[wordCount] || 'approximately 300 words'}.\n\nTopic / Brief:\n${topic}`;

    try {
        const result = await ollamaAsk(apiUrl.replace(/\/+$/, ''), model, system, user);
        res.json({ result });
    } catch (e) {
        res.status(502).json({ error: e.message });
    }
});


/* 7. CHANGE DETECTION
   Body: { apiUrl, model, original, modified, mode, format } */
app.post('/api/tools/change-detection', async (req, res) => {
    const { apiUrl, model, original, modified, mode, format } = req.body;
    if (!apiUrl) return res.status(400).json({ error: 'apiUrl is required' });
    if (!original) return res.status(400).json({ error: 'original (in1) input is required' });
    if (!modified) return res.status(400).json({ error: 'modified (in2) input is required' });

    const formatNote = {
        'Unified Diff': 'Present it as a unified diff (+ for additions, - for removals).',
        'Side by Side': 'Present changes in a side-by-side comparison format.',
        'Summary Only': 'Provide a plain English summary of what changed.'
    };

    // Check if inputs look like images (base64)
    const isImageOriginal = original.startsWith('data:image') || (original.length > 200 && !original.includes(' '));
    const isImageModified = modified.startsWith('data:image') || (modified.length > 200 && !modified.includes(' '));

    if (isImageOriginal && isImageModified) {
        // Vision-based comparison
        try {
            const url = apiUrl.replace(/\/+$/, '');
            const b1 = original.replace(/^data:image\/\w+;base64,/, '');
            const b2 = modified.replace(/^data:image\/\w+;base64,/, '');

            const response = await fetch(url + '/api/chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    model: model || 'llava',
                    stream: false,
                    messages: [{
                        role: 'user',
                        content: `You are a visual change detection AI. I will show you two images. Compare them carefully and describe ALL differences you can find. ${formatNote[format] || formatNote['Summary Only']} Mode: ${mode || 'Visual Change (Image)'}. The first image is the ORIGINAL and the second is the MODIFIED version.`,
                        images: [b1, b2]
                    }]
                })
            });
            const data = await response.json();
            if (data.error) return res.status(502).json({ error: data.error });
            const result = (data.message && data.message.content) ? data.message.content.trim() : JSON.stringify(data);
            return res.json({ result });
        } catch (e) {
            return res.status(502).json({ error: e.message });
        }
    }

    // Text-based comparison
    const system = 'You are a precise change detection assistant. Compare inputs exactly.';
    const user = `Compare the following two texts and detect all changes.\nMode: ${mode || 'Text Diff'}. ${formatNote[format] || formatNote['Summary Only']}\n\n--- ORIGINAL ---\n${original}\n\n--- MODIFIED ---\n${modified}`;

    try {
        const result = await ollamaAsk(apiUrl.replace(/\/+$/, ''), model, system, user);
        res.json({ result });
    } catch (e) {
        res.status(502).json({ error: e.message });
    }
});


/* 8. NET CRAWLER
   Body: { url, extractType, depth, selector }
   Note: crawls via server-side fetch (no Ollama needed for basic extraction) */
app.post('/api/tools/net-crawler', async (req, res) => {
    const { url, extractType, depth, selector, apiUrl, model } = req.body;
    if (!url) return res.status(400).json({ error: 'url is required' });

    try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 30000);

        const response = await fetch(url, {
            signal: controller.signal,
            headers: { 'User-Agent': 'Mozilla/5.0 (compatible; FlowCraft-Crawler/1.0)' }
        });
        clearTimeout(timeout);

        const html = await response.text();

        const stripTags = (s) => s.replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
            .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
            .replace(/<[^>]+>/g, ' ')
            .replace(/\s{2,}/g, ' ')
            .trim();

        const extractLinks = (s) => {
            const re = /href=["']([^"']+)["']/gi;
            const links = []; let m;
            while ((m = re.exec(s)) !== null) links.push(m[1]);
            return [...new Set(links)].slice(0, 100).join('\n');
        };

        const extractImages = (s) => {
            const re = /src=["']([^"']+\.(jpg|jpeg|png|gif|webp|svg))["']/gi;
            const imgs = []; let m;
            while ((m = re.exec(s)) !== null) imgs.push(m[1]);
            return [...new Set(imgs)].slice(0, 50).join('\n');
        };

        const extractHeadings = (s) => {
            const re = /<h[1-6][^>]*>([\s\S]*?)<\/h[1-6]>/gi;
            const heads = []; let m;
            while ((m = re.exec(s)) !== null) heads.push(stripTags(m[1]));
            return heads.join('\n');
        };

        let rawResult = '';
        switch (extractType) {
            case 'Links Only': rawResult = extractLinks(html); break;
            case 'Images Only': rawResult = extractImages(html); break;
            case 'Headings & Summary': rawResult = extractHeadings(html); break;
            case 'Structured Data':
            case 'Custom Selector':
            case 'Full Page Text':
            default: rawResult = stripTags(html).slice(0, 8000); break;
        }

        if (apiUrl && model && extractType !== 'Links Only' && extractType !== 'Images Only') {
            const system = 'You are a web data extraction assistant. Analyze the crawled content and present it clearly.';
            const user = `Extracted content from ${url}:\n\n${rawResult}\n\nProvide a clean, structured summary.`;
            try {
                const aiResult = await ollamaAsk(apiUrl.replace(/\/+$/, ''), model, system, user);
                return res.json({ result: aiResult, raw: rawResult });
            } catch (_) { /* fall through to raw */ }
        }

        res.json({ result: rawResult });
    } catch (e) {
        if (e.name === 'AbortError') return res.status(504).json({ error: 'Crawl timed out (30s)' });
        res.status(502).json({ error: 'Failed to fetch URL: ' + e.message });
    }
});


/* 9. YOUTUBE DEEP SCANNER */
app.post('/api/tools/youtube-scanner', async (req, res) => {
    const { apiUrl, model, youtubeUrl, analysisType, language } = req.body;
    if (!apiUrl) return res.status(400).json({ error: 'apiUrl is required' });
    if (!youtubeUrl) return res.status(400).json({ error: 'youtubeUrl is required' });

    const idMatch = youtubeUrl.match(/(?:v=|youtu\.be\/|embed\/|shorts\/)([A-Za-z0-9_-]{11})/);
    if (!idMatch) return res.status(400).json({ error: 'Invalid YouTube URL — could not extract video ID' });
    const videoId = idMatch[1];

    try {
        const pageRes = await fetch(`https://www.youtube.com/watch?v=${videoId}`, {
            headers: { 'User-Agent': 'Mozilla/5.0' }
        });
        const pageHtml = await pageRes.text();

        const titleMatch = pageHtml.match(/<title>([^<]+)<\/title>/);
        const title = titleMatch ? titleMatch[1].replace(' - YouTube', '').trim() : videoId;

        let transcript = '';
        try {
            const timedtextUrl = `https://www.youtube.com/api/timedtext?v=${videoId}&lang=${language === 'Auto' || !language ? 'en' : language.toLowerCase().slice(0, 2)}&fmt=json3`;
            const ttRes = await fetch(timedtextUrl, { headers: { 'User-Agent': 'Mozilla/5.0' } });
            const ttData = await ttRes.json();
            if (ttData.events) {
                transcript = ttData.events
                    .filter(e => e.segs)
                    .map(e => e.segs.map(s => s.utf8).join(''))
                    .join(' ')
                    .replace(/\s+/g, ' ')
                    .trim()
                    .slice(0, 6000);
            }
        } catch (_) { transcript = '(Transcript not available for this video)'; }

        const analysisPrompts = {
            'Full Transcript': `Return the full transcript text as-is:\n\n${transcript}`,
            'Summary': `Summarize this YouTube video titled "${title}" in 3-5 sentences based on the transcript:\n\n${transcript}`,
            'Key Insights': `List 5-10 key insights from this YouTube video titled "${title}":\n\n${transcript}`,
            'Chapter Breakdown': `Create a chapter breakdown with timestamps for this YouTube video titled "${title}":\n\n${transcript}`,
            'Comment Sentiment': `Based on the content of this video titled "${title}", predict likely audience sentiment and reaction:\n\n${transcript}`,
            'Topic Tags': `Generate 10-15 relevant topic tags/keywords for this YouTube video titled "${title}":\n\n${transcript}`
        };

        const system = 'You are a YouTube content analyst. Be concise and insightful.';
        const user = analysisPrompts[analysisType] || analysisPrompts['Summary'];

        const result = await ollamaAsk(apiUrl.replace(/\/+$/, ''), model, system, user);
        res.json({ result, videoId, title });
    } catch (e) {
        res.status(502).json({ error: e.message });
    }
});


/* 10. RETOUCH AI */
app.post('/api/tools/retouch-ai', async (req, res) => {
    const { apiUrl, model, imageBase64, operation, strength } = req.body;
    if (!apiUrl) return res.status(400).json({ error: 'apiUrl is required' });
    if (!imageBase64) return res.status(400).json({ error: 'imageBase64 is required' });

    const opPrompts = {
        'Auto Enhance': 'Describe what enhancements this image needs (brightness, contrast, saturation, sharpness). Be specific with values.',
        'Background Remove': 'Describe the main subject and background of this image for background removal processing.',
        'Background Replace': 'Describe the main subject to keep and suggest 3 replacement background options.',
        'Skin Retouching': 'Analyze the skin tones and texture in this image. Describe what retouching steps are needed.',
        'Color Correction': 'Analyze the color balance of this image. Describe specific color correction needed (white balance, hue, saturation).',
        'Upscale (2x)': 'Analyze the image quality and describe what details should be enhanced when upscaling 2x.',
        'Upscale (4x)': 'Analyze the image quality and describe what details should be enhanced when upscaling 4x.',
        'Noise Reduction': 'Analyze the noise level in this image and describe the noise reduction approach needed.',
        'Object Removal': 'Identify objects in this image that could be removed, and describe the inpainting approach.'
    };

    const strengthNote = { 'Subtle': 'Apply subtle, minimal changes.', 'Medium': 'Apply moderate changes.', 'Strong': 'Apply strong, prominent changes.' };

    try {
        const base64 = imageBase64.replace(/^data:image\/\w+;base64,/, '');
        const url = apiUrl.replace(/\/+$/, '');

        const response = await fetch(url + '/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model: model || 'llava',
                stream: false,
                messages: [{
                    role: 'user',
                    content: `You are a professional photo retouching AI. ${opPrompts[operation] || opPrompts['Auto Enhance']} ${strengthNote[strength] || ''}`,
                    images: [base64]
                }]
            })
        });
        const data = await response.json();
        if (data.error) return res.status(502).json({ error: data.error });
        const result = (data.message && data.message.content) ? data.message.content.trim() : JSON.stringify(data);
        res.json({ result, operation, strength });
    } catch (e) {
        res.status(502).json({ error: e.message });
    }
});


/* ══════════════════════════════════════════════
      POSTGRES MEMORY NODE
      Body: { host, port, database, user, password }
      ══════════════════════════════════════════════ */
app.post('/api/postgres/init', async (req, res) => {
    const { host, port, database, user, password } = req.body;

    if (!host || !database || !user) {
        return res.status(400).json({ error: 'host, database, and user are required' });
    }

    const pool = new Pool({ host, port: port || 5432, database, user, password, ssl: false });

    try {
        const client = await pool.connect();
        try {
            // Ensure table exists
            await client.query(`
                                CREATE TABLE IF NOT EXISTS chat_history (
                                        id SERIAL PRIMARY KEY,
                                        session_id VARCHAR(255) NOT NULL,
                                        role VARCHAR(50) NOT NULL,
                                        content TEXT NOT NULL,
                                        created_at TIMESTAMP DEFAULT NOW()
                                )
                        `);
            res.json({ success: true, message: 'Connected and table ready' });
        } finally {
            client.release();
        }
    } catch (err) {
        console.error('Postgres Init Error:', err.message);
        res.status(500).json({ error: err.message });
    } finally {
        await pool.end();
    }
});

// GET / POST History
app.all('/api/postgres/history', async (req, res) => {
    const { host, port, database, user, password, session_id, role, content } = req.body;
    if (!host || !database || !user || !session_id) {
        return res.status(400).json({ error: 'host, database, user, and session_id are required' });
    }

    const pool = new Pool({ host, port: port || 5432, database, user, password, ssl: false });
    try {
        const client = await pool.connect();
        try {
            if (req.method === 'POST') {
                if (!role || !content) return res.status(400).json({ error: 'role and content required' });
                await client.query('INSERT INTO chat_history (session_id, role, content) VALUES ($1, $2, $3)', [session_id, role, content]);
                res.json({ success: true });
            } else {
                const result = await client.query('SELECT role, content, created_at FROM chat_history WHERE session_id = $1 ORDER BY id ASC', [session_id]);
                res.json({ history: result.rows });
            }
        } finally {
            client.release();
        }
    } catch (err) {
        console.error('Postgres History Error:', err.message);
        res.status(500).json({ error: err.message });
    } finally {
        await pool.end();
    }
});


/* ══════════════════════════════════════════════
   START SERVER
   ══════════════════════════════════════════════ */
const PORT = 3000;
const HOST = '192.168.56.1';

app.listen(PORT, HOST, () => {
    console.log('╔══════════════════════════════════════╗');
    console.log('║  FlowCraft server running            ║');
    console.log(`║  Network: http://${HOST}:${PORT}      ║`);
    console.log(`║  Local:   http://localhost:${PORT}     ║`);
    console.log('╚══════════════════════════════════════╝');
});