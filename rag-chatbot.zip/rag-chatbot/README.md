# 🧠 LocalDoc Chat - Production RAG Document Chatbot

A complete, production-ready **Retrieval Augmented Generation (RAG)** chatbot that runs **100% locally** with no cloud dependencies. Built with Flask, Ollama, and FAISS.

![License](https://img.shields.io/badge/license-MIT-blue.svg)
![Python](https://img.shields.io/badge/python-3.9%2B-brightgreen)
![Flask](https://img.shields.io/badge/flask-3.0-black)

## ✨ Features

- 🔒 **Fully Local** - No cloud APIs, no data leaves your machine
- 📄 **Multi-Format Support** - PDF, DOCX, TXT documents
- 🎨 **Premium UI** - ChatGPT-style interface with dark/light modes
- 🚀 **Production-Ready** - Clean architecture, error handling, security
- 🔍 **Accurate Answers** - Only uses uploaded document content (no hallucinations)
- ⚡ **Fast Search** - FAISS vector similarity for instant retrieval
- 📊 **Source Attribution** - Shows exact chunks used for answers

## 🏗️ Architecture

```
User uploads document
    ↓
Text extraction (PDF/DOCX/TXT)
    ↓
Recursive text chunking (1000 chars, 200 overlap)
    ↓
Embedding generation (nomic-embed-text via Ollama)
    ↓
FAISS vector store (local persistence)
    ↓
User asks question
    ↓
Similarity search (top-k chunks)
    ↓
RAG prompt construction
    ↓
LLM generation (gemma3:4b via Ollama)
    ↓
Answer + sources returned
```

## 📋 Prerequisites

- **Python 3.9+**
- **Ollama** installed and running
- **8GB+ RAM** recommended
- **Modern web browser**

## 🚀 Quick Start

### 1. Install Ollama

```bash
# macOS
brew install ollama

# Linux
curl -fsSL https://ollama.com/install.sh | sh

# Windows - Download from https://ollama.com
```

### 2. Pull Required Models

```bash
# LLM for answer generation
ollama pull gemma3:4b

# Embedding model for vector search
ollama pull nomic-embed-text
```

**Verify Ollama is running:**
```bash
ollama list
# Should show both gemma3:4b and nomic-embed-text
```

### 3. Install Python Dependencies

```bash
# Create virtual environment (recommended)
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### 4. Run the Application

```bash
python app.py
```

The server will start at **http://localhost:5000**

## 💻 Usage

### Upload a Document

1. Open http://localhost:5000 in your browser
2. Drag & drop or click to upload a PDF, DOCX, or TXT file
3. Wait for processing (progress bar shows status)
4. Document appears in the sidebar when ready

### Ask Questions

1. Type your question in the input field at the bottom
2. Press Enter or click the send button
3. Receive AI-generated answer based on your document
4. Click "View source chunks" to see exact passages used

### Features

- **Theme Toggle** - Switch between dark and light modes
- **Clear Chat** - Start fresh with a new document
- **Source Attribution** - Every answer shows which parts of the document were used
- **Typing Indicators** - Real-time feedback while generating

## 📁 Project Structure

```
rag-chatbot/
├── app.py                  # Main Flask application
├── requirements.txt        # Python dependencies
├── README.md              # This file
│
├── rag/                   # RAG components
│   ├── __init__.py
│   ├── loader.py          # Document loading (PDF/DOCX/TXT)
│   ├── splitter.py        # Recursive text splitting
│   ├── embeddings.py      # Ollama embedding generation
│   ├── vector_store.py    # FAISS vector storage
│   └── llm.py             # Ollama LLM integration
│
├── templates/
│   └── index.html         # Frontend UI
│
├── static/
│   └── js/
│       └── app.js         # Frontend JavaScript
│
├── data/
│   └── faiss_index/       # Persisted vector indices
│
└── uploads/               # Temporary document storage
```

## 🔧 Configuration

### Ollama Settings

Edit the following in your respective files if Ollama runs on a different port:

**In `rag/embeddings.py` and `rag/llm.py`:**
```python
ollama_url = "http://localhost:11434"  # Default Ollama URL
```

### Chunk Size

**In `app.py`:**
```python
splitter = DocumentSplitter(
    chunk_size=1000,      # Characters per chunk
    chunk_overlap=200     # Overlap between chunks
)
```

### File Upload Limits

**In `app.py`:**
```python
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50MB limit
```

## 🧪 Example Test Workflow

1. **Upload a Document**
   ```
   - Download a sample PDF (e.g., research paper, manual)
   - Upload via the interface
   - Wait for "Document processed successfully!" notification
   ```

2. **Test Questions**
   ```
   - "What is this document about?"
   - "Summarize the main points"
   - "What does it say about [specific topic]?"
   - "Can you find information about [X]?"
   ```

3. **Verify Grounding**
   ```
   - Ask a question that's NOT in the document
   - Expected response: "I cannot find this information in the uploaded document."
   ```

4. **Check Sources**
   ```
   - Click "View source chunks" on any answer
   - Verify the response matches the highlighted passages
   ```

## 🔐 Security Features

- ✅ File type validation (PDF, DOCX, TXT only)
- ✅ File size limits (50MB max)
- ✅ Secure filename handling
- ✅ Input sanitization
- ✅ No prompt injection vulnerabilities
- ✅ Separation of system and user prompts

## 🎨 UI Features

- **Modern Design** - Custom fonts (Sora, JetBrains Mono)
- **Smooth Animations** - Message slide-ins, typing indicators
- **Responsive** - Works on desktop and mobile
- **Accessibility** - Proper contrast ratios, keyboard navigation
- **Dark/Light Modes** - Persistent theme preference

## 🐛 Troubleshooting

### "Cannot connect to Ollama"

```bash
# Check if Ollama is running
ollama list

# Start Ollama if needed
ollama serve

# Verify the port (default: 11434)
curl http://localhost:11434/api/tags
```

### "Error processing document"

- Verify file is a valid PDF, DOCX, or TXT
- Check file isn't corrupted
- Ensure file size is under 50MB
- Try a simpler document first

### "No response generated"

```bash
# Check if model is available
ollama list

# Re-pull the model if needed
ollama pull gemma3:4b
```

### High Memory Usage

- Use smaller documents (< 10MB)
- Reduce chunk_size to 500
- Use a smaller model: `ollama pull gemma2:2b`

## 📊 Performance

- **Document Upload**: ~10-30 seconds (depends on size)
- **Question Answering**: ~3-10 seconds
- **Memory Usage**: ~2-4GB (with gemma3:4b)
- **Supported Doc Size**: Up to 50MB

## 🔄 Tech Stack

| Component | Technology |
|-----------|-----------|
| Backend | Flask 3.0 |
| LLM | Gemma 3 (4B params) via Ollama |
| Embeddings | nomic-embed-text via Ollama |
| Vector DB | FAISS (Facebook AI Similarity Search) |
| Text Splitting | Recursive Character Splitter |
| Document Parsing | PyPDF2, python-docx |
| Frontend | Vanilla JavaScript, CSS |

## 🚫 What This Does NOT Do

- ❌ Use OpenAI or any cloud APIs
- ❌ Send data to external servers
- ❌ Hallucinate answers from outside knowledge
- ❌ Require internet connection (after initial setup)
- ❌ Store conversation history permanently

## 🤝 Contributing

This is a complete reference implementation. Feel free to:

- Add more document types (HTML, Markdown, etc.)
- Implement streaming responses
- Add conversation memory
- Support multiple documents
- Add user authentication
- Deploy with Docker

## 📝 License

MIT License - See LICENSE file for details

## 🙏 Acknowledgments

- **Ollama** - Local LLM runtime
- **FAISS** - Efficient similarity search
- **Anthropic** - Inspiration from Claude's interface
- **Google** - Gemma model family

## 📞 Support

For issues or questions:
1. Check the troubleshooting section
2. Verify Ollama is running with correct models
3. Check server logs in terminal
4. Review browser console for frontend errors

---

**Built with ❤️ for privacy-conscious AI enthusiasts**

Run AI locally. Own your data. 🔒
