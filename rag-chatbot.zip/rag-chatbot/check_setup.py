#!/usr/bin/env python3
"""
Setup Verification Script
Checks if all dependencies and Ollama models are ready
"""

import sys
import subprocess
import importlib

def check_python_version():
    """Check Python version"""
    print("🐍 Checking Python version...")
    version = sys.version_info
    if version.major >= 3 and version.minor >= 9:
        print(f"   ✅ Python {version.major}.{version.minor}.{version.micro}")
        return True
    else:
        print(f"   ❌ Python {version.major}.{version.minor}.{version.micro} - Need 3.9+")
        return False

def check_dependencies():
    """Check if required Python packages are installed"""
    print("\n📦 Checking Python dependencies...")
    
    required = {
        'flask': 'Flask',
        'PyPDF2': 'PyPDF2',
        'docx': 'python-docx',
        'numpy': 'numpy',
        'faiss': 'faiss-cpu',
        'requests': 'requests'
    }
    
    missing = []
    for module, package in required.items():
        try:
            importlib.import_module(module)
            print(f"   ✅ {package}")
        except ImportError:
            print(f"   ❌ {package} - Not installed")
            missing.append(package)
    
    if missing:
        print(f"\n   Install missing packages with:")
        print(f"   pip install {' '.join(missing)}")
        return False
    
    return True

def check_ollama():
    """Check if Ollama is installed and running"""
    print("\n🦙 Checking Ollama...")
    
    try:
        result = subprocess.run(['ollama', 'list'], 
                              capture_output=True, 
                              text=True, 
                              timeout=5)
        
        if result.returncode == 0:
            print("   ✅ Ollama is installed and running")
            return True, result.stdout
        else:
            print("   ❌ Ollama command failed")
            return False, None
    
    except FileNotFoundError:
        print("   ❌ Ollama not found - Install from https://ollama.com")
        return False, None
    
    except Exception as e:
        print(f"   ❌ Error checking Ollama: {e}")
        return False, None

def check_ollama_models(ollama_output):
    """Check if required Ollama models are available"""
    print("\n🤖 Checking Ollama models...")
    
    required_models = {
        'gemma3:4b': 'LLM for answer generation',
        'nomic-embed-text': 'Embedding model for vectors'
    }
    
    missing = []
    for model, description in required_models.items():
        if model in ollama_output:
            print(f"   ✅ {model} - {description}")
        else:
            print(f"   ❌ {model} - {description}")
            missing.append(model)
    
    if missing:
        print(f"\n   Pull missing models with:")
        for model in missing:
            print(f"   ollama pull {model}")
        return False
    
    return True

def check_directories():
    """Check if required directories exist"""
    print("\n📁 Checking directories...")
    
    import os
    
    dirs = [
        'uploads',
        'data/faiss_index',
        'templates',
        'static/js',
        'rag'
    ]
    
    all_exist = True
    for dir_path in dirs:
        if os.path.exists(dir_path):
            print(f"   ✅ {dir_path}")
        else:
            print(f"   ❌ {dir_path} - Missing")
            all_exist = False
    
    return all_exist

def main():
    """Run all checks"""
    print("=" * 60)
    print("LocalDoc Chat - Setup Verification")
    print("=" * 60)
    
    checks = []
    
    # Python version
    checks.append(check_python_version())
    
    # Dependencies
    checks.append(check_dependencies())
    
    # Ollama installation
    ollama_ok, ollama_output = check_ollama()
    checks.append(ollama_ok)
    
    # Ollama models
    if ollama_ok and ollama_output:
        checks.append(check_ollama_models(ollama_output))
    else:
        checks.append(False)
    
    # Directory structure
    checks.append(check_directories())
    
    # Final result
    print("\n" + "=" * 60)
    if all(checks):
        print("✅ ALL CHECKS PASSED!")
        print("\nYou're ready to run the application:")
        print("   python app.py")
    else:
        print("❌ SOME CHECKS FAILED")
        print("\nPlease fix the issues above before running the application.")
    print("=" * 60)

if __name__ == '__main__':
    main()
