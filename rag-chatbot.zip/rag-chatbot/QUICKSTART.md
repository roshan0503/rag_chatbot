# ⚡ Quick Start Guide

Get LocalDoc Chat running in 5 minutes!

## 1️⃣ Install Ollama

### macOS
```bash
brew install ollama
```

### Linux
```bash
curl -fsSL https://ollama.com/install.sh | sh
```

### Windows
Download from: https://ollama.com/download

## 2️⃣ Pull Models

```bash
# LLM for answers (~2.5GB)
ollama pull gemma3:4b

# Embeddings for search (~274MB)
ollama pull nomic-embed-text

# Verify
ollama list
```

## 3️⃣ Install Python Dependencies

```bash
# Create virtual environment
python3 -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Install packages
pip install -r requirements.txt
```

## 4️⃣ Verify Setup

```bash
python check_setup.py
```

Should show all ✅ checkmarks.

## 5️⃣ Run the App

```bash
# Easy way
./run.sh

# Or manually
python app.py
```

## 6️⃣ Open Browser

```
http://localhost:5000
```

## 7️⃣ Upload & Chat

1. Upload `sample_document.txt` (or any PDF/DOCX/TXT)
2. Wait for processing
3. Ask questions!

---

## Test Questions

Try these with the sample document:

- "What is LocalDoc Chat?"
- "What file formats are supported?"
- "What is the capital of France?" ← Should say "not in document"

---

## Troubleshooting One-Liners

```bash
# Is Ollama running?
ollama list

# Start Ollama
ollama serve

# Check models
ollama list

# Reinstall dependencies
pip install -r requirements.txt --force-reinstall

# Check setup
python check_setup.py
```

---

## Common Issues

❌ **"Cannot connect to Ollama"**  
→ Run `ollama serve` in a separate terminal

❌ **"Model not found"**  
→ Run `ollama pull gemma3:4b`

❌ **"Import Error"**  
→ Run `pip install -r requirements.txt`

❌ **"Port already in use"**  
→ Change port in `app.py`: `app.run(port=5001)`

---

## Project Structure

```
rag-chatbot/
├── app.py              # Main Flask app
├── requirements.txt    # Dependencies
├── run.sh             # Start script
├── check_setup.py     # Setup checker
│
├── rag/               # RAG components
│   ├── loader.py      # Document loading
│   ├── splitter.py    # Text chunking
│   ├── embeddings.py  # Vector embeddings
│   ├── vector_store.py # FAISS search
│   └── llm.py         # Answer generation
│
├── templates/
│   └── index.html     # UI
│
└── static/js/
    └── app.js         # Frontend logic
```

---

## What's Happening Under the Hood?

1. **Upload** → Extract text from document
2. **Chunk** → Split into ~1000 char pieces
3. **Embed** → Convert to vectors (nomic-embed-text)
4. **Store** → Save in FAISS index
5. **Query** → Convert question to vector
6. **Search** → Find top 4 similar chunks
7. **Generate** → LLM creates answer (gemma3:4b)
8. **Return** → Show answer + sources

---

## Next Steps

✨ **Customize**:
- Edit colors in `templates/index.html`
- Adjust chunk size in `app.py`
- Change number of retrieved chunks

🚀 **Extend**:
- Add conversation memory
- Support multiple documents
- Implement streaming responses
- Add user authentication

🎯 **Deploy**:
- Run on a local server
- Use Docker for containerization
- Set up reverse proxy with nginx

---

**Need more help?** See `INSTALLATION.md` for detailed guide.

**Enjoy your privacy-first AI assistant!** 🔒
