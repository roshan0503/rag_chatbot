// LocalDoc Chat - Chat Interface Logic

const DOM = {
    input: document.getElementById('chatInput'),
    sendBtn: document.getElementById('sendBtn'),
    messages: document.getElementById('messages'),
    docName: document.getElementById('docName'),
    docChunks: document.getElementById('docChunks'),
    docSize: document.getElementById('docSize')
};

let isProcessing = false;

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    // Focus input
    DOM.input.focus();

    // Event Listeners
    DOM.sendBtn.addEventListener('click', sendMessage);

    DOM.input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });

    // Auto-resize input
    DOM.input.addEventListener('input', function () {
        this.style.height = 'auto';
        this.style.height = Math.min(this.scrollHeight, 150) + 'px';
    });
});

async function sendMessage() {
    const query = DOM.input.value.trim();
    if (!query || isProcessing) return;

    // UI Updates
    DOM.input.value = '';
    DOM.input.style.height = 'auto';
    addMessage(query, 'user');
    isProcessing = true;
    showTyping();

    try {
        const response = await fetch('/api/chat', {  // Updated to /api/chat
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ query })
        });

        const data = await response.json();
        removeTyping();

        if (response.ok) {
            addMessage(data.answer, 'ai', data.sources);
        } else {
            addMessage(data.error || "System Error", 'ai');
        }
    } catch (err) {
        removeTyping();
        addMessage("Connection Lost. Please check server.", 'ai');
    } finally {
        isProcessing = false;
        // Re-focus input for flow
        DOM.input.focus();
    }
}

function addMessage(text, type, sources = null) {
    const div = document.createElement('div');
    div.className = `message ${type}`;

    const avatar = type === 'user' ? '👻' : '🤖';

    // Parse Markdown if AI
    const content = type === 'ai' ? marked.parse(text) : text;

    div.innerHTML = `
        <div class="avatar">${avatar}</div>
        <div class="bubble markdown-content">${content}</div>
    `;

    DOM.messages.appendChild(div);
    scrollToBottom();
}

function showTyping() {
    const div = document.createElement('div');
    div.className = 'message ai searching';
    div.id = 'typingIndicator';
    div.innerHTML = `
        <div class="avatar">🤖</div>
        <div class="bubble">
            <div class="typing">
                <div class="dot"></div>
                <div class="dot"></div>
                <div class="dot"></div>
            </div>
        </div>
    `;
    DOM.messages.appendChild(div);
    scrollToBottom();
}

function removeTyping() {
    const el = document.getElementById('typingIndicator');
    if (el) el.remove();
}

function scrollToBottom() {
    DOM.messages.scrollTop = DOM.messages.scrollHeight;
}
