"""
LocalDoc Chat - Production RAG Document Chatbot
Flask backend with Ollama integration
"""

import os
import json
from flask import Flask, request, jsonify, render_template, send_from_directory
from werkzeug.utils import secure_filename
from rag.loader import DocumentLoader
from rag.splitter import DocumentSplitter
from rag.embeddings import EmbeddingGenerator
from rag.vector_store import VectorStore
from rag.llm import LLMHandler

# Flask app initialization
app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50MB max file size
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['FAISS_INDEX_PATH'] = 'data/faiss_index'

# Allowed file extensions
ALLOWED_EXTENSIONS = {'pdf', 'docx', 'txt'}

# Global variables for RAG components
vector_store = None
current_document = None

def allowed_file(filename):
    """Check if file extension is allowed"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    """Serve the landing page (upload)"""
    return render_template('landing.html')

@app.route('/chat', methods=['GET'])
def chat_page():
    """Serve the chat interface"""
    # Optional: Check if document is loaded, else redirect to /
    # For now, let the frontend handle the redirect
    return render_template('chat.html')

@app.route('/upload', methods=['POST'])
def upload_document():
    """
    Handle document upload and processing
    - Validate file
    - Extract text
    - Split into chunks
    - Generate embeddings
    - Store in FAISS
    """
    global vector_store, current_document
    
    try:
        # Check if file is present
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        
        file = request.files['file']
        
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        if not allowed_file(file.filename):
            return jsonify({'error': 'File type not supported. Use PDF, DOCX, or TXT'}), 400
        
        # Secure filename and save
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        # Step 1: Load and extract text
        loader = DocumentLoader()
        text = loader.load(filepath)
        
        if not text or len(text.strip()) < 10:
            os.remove(filepath)
            return jsonify({'error': 'Could not extract meaningful text from document'}), 400
        
        # Step 2: Split text into chunks
        splitter = DocumentSplitter(chunk_size=1000, chunk_overlap=200)
        chunks = splitter.split(text)
        
        if not chunks:
            os.remove(filepath)
            return jsonify({'error': 'Failed to split document into chunks'}), 400
        
        # Step 3: Generate embeddings
        embedding_gen = EmbeddingGenerator()
        embeddings = embedding_gen.generate_embeddings(chunks)
        
        # Step 4: Store in FAISS
        vector_store = VectorStore(app.config['FAISS_INDEX_PATH'])
        vector_store.create_index(embeddings, chunks)
        
        current_document = {
            'filename': filename,
            'chunks': len(chunks),
            'characters': len(text)
        }
        
        return jsonify({
            'success': True,
            'message': 'Document processed successfully',
            'document': current_document
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Error processing document: {str(e)}'}), 500

# Global variables
conversation_history = []  # List of message dicts {'role': 'user/assistant', 'content': '...'}

@app.route('/api/chat', methods=['POST'])
def chat_api():
    """
    Handle chat requests with history support
    """
    global vector_store, current_document, conversation_history
    
    try:
        # Check if document is loaded
        if vector_store is None or current_document is None:
            return jsonify({'error': 'Please upload a document first'}), 400
        
        data = request.get_json()
        query = data.get('query', '').strip()
        
        if not query:
            return jsonify({'error': 'Query cannot be empty'}), 400
            
        # Add user query to history
        conversation_history.append({'role': 'user', 'content': query})
        
        # Keep history manageable (last 10 messages)
        if len(conversation_history) > 10:
            conversation_history = conversation_history[-10:]
        
        # Step 1: Retrieval (Hybrid)
        retrieved_chunks = vector_store.search(query, k=5, fetch_k=25)
        
        # Step 2: Build Context & History String
        context_str = "\n\n".join([f"[Chunk {i+1}]: {chunk}" for i, chunk in enumerate(retrieved_chunks)])
        
        history_str = ""
        for msg in conversation_history[:-1]: # Exclude current query which is at the end
            role = "User" if msg['role'] == 'user' else "Assistant"
            history_str += f"{role}: {msg['content']}\n"
            
        # Step 3: Prompt Engineering
        rag_prompt = f"""You are a helpful, professional document assistant.
        
        INSTRUCTIONS:
        1. If I greet you (e.g., "Hi", "Hello"), reply politely and offer help. You do NOT need the document for this.
        2. For questions, answer ONLY using the provided Document Context.
        3. Use the Conversation History to understand follow-up questions (e.g., if I ask "What is his email?" after asking about a person).
        4. If the answer is not in the Document Context and it's not a greeting, say "I couldn't find that information in the document."
        
        Document Context:
        {context_str}
        
        Conversation History:
        {history_str}
        
        Current Question:
        {query}
        
        Answer:"""
        
        # Step 4: LLM Generation
        llm = LLMHandler()
        answer = llm.generate_answer(rag_prompt)
        
        # Add assistant response to history
        conversation_history.append({'role': 'assistant', 'content': answer})
        
        return jsonify({
            'answer': answer,
            'sources': [] # Hidden as per user request
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Error generating answer: {str(e)}'}), 500

@app.route('/status', methods=['GET'])
def status():
    """Get current system status"""
    global current_document
    
    return jsonify({
        'document_loaded': current_document is not None,
        'current_document': current_document
    }), 200

@app.route('/clear', methods=['POST'])
def clear():
    """Clear current document and chat"""
    global vector_store, current_document, conversation_history
    
    vector_store = None
    current_document = None
    conversation_history = []
    
    # Clear uploaded files
    for filename in os.listdir(app.config['UPLOAD_FOLDER']):
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        try:
            os.remove(filepath)
        except:
            pass
    
    return jsonify({'success': True, 'message': 'Chat cleared'}), 200

if __name__ == '__main__':
    # Create necessary directories
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    os.makedirs(app.config['FAISS_INDEX_PATH'], exist_ok=True)
    
    print("=" * 60)
    print("LocalDoc Chat - RAG Document Chatbot")
    print("=" * 60)
    print("Starting server at http://localhost:5000")
    print("Make sure Ollama is running with:")
    print("  - gemma3:4b (LLM)")
    print("  - nomic-embed-text (Embeddings)")
    print("=" * 60)
    
    app.run(debug=True, host='0.0.0.0', port=5000)
