"""
Vector Store Module
Uses FAISS for efficient similarity search
"""

import os
import pickle
import numpy as np
import faiss
from typing import List, Optional
from rag.embeddings import EmbeddingGenerator

class VectorStore:
    """FAISS-based vector store for document chunks"""
    
    def __init__(self, index_path: str):
        """
        Initialize vector store
        
        Args:
            index_path: Path to save/load FAISS index
        """
        self.index_path = index_path
        self.index = None
        self.chunks = []
        self.embedding_generator = EmbeddingGenerator()
        
        # FAISS index file paths
        self.index_file = os.path.join(index_path, 'faiss.index')
        self.chunks_file = os.path.join(index_path, 'chunks.pkl')
    
    def create_index(self, embeddings: np.ndarray, chunks: List[str]):
        """
        Create FAISS index from embeddings
        
        Args:
            embeddings: NumPy array of embeddings
            chunks: List of text chunks corresponding to embeddings
        """
        if embeddings.shape[0] != len(chunks):
            raise ValueError("Number of embeddings must match number of chunks")
        
        # Get embedding dimension
        dimension = embeddings.shape[1]
        
        # Create FAISS index (using L2 distance)
        self.index = faiss.IndexFlatL2(dimension)
        
        # Add embeddings to index
        self.index.add(embeddings)
        
        # Store chunks
        self.chunks = chunks
        
        # Save to disk
        self._save_index()
        
        print(f"✓ Created FAISS index with {len(chunks)} chunks (dimension: {dimension})")
    
    def search(self, query: str, k: int = 5, fetch_k: int = 20) -> List[str]:
        """
        Search for most similar chunks to query using Hybrid Search (Vector + Keyword Reranking)
        
        Args:
            query: Search query
            k: Number of results to return
            fetch_k: Number of candidates to fetch from vector store before reranking
            
        Returns:
            List of most similar text chunks
        """
        # Load index if not in memory
        if self.index is None:
            self._load_index()
        
        if self.index is None or not self.chunks:
            raise Exception("No index found. Please upload a document first.")
        
        # Generate query embedding
        query_embedding = self.embedding_generator.generate_query_embedding(query)
        query_embedding = query_embedding.reshape(1, -1)
        
        # Search FAISS index - Fetch more candidates for reranking
        # Ensure we don't request more than available
        actual_fetch_k = min(fetch_k, len(self.chunks))
        distances, indices = self.index.search(query_embedding, actual_fetch_k)
        
        # Retrieve candidate chunks
        candidate_chunks = [self.chunks[idx] for idx in indices[0]]
        
        # Rerank candidates based on keyword overlap
        final_results = self._rerank_chunks(query, candidate_chunks, k)
        
        return final_results

    def _rerank_chunks(self, query: str, chunks: List[str], k: int) -> List[str]:
        """
        Rerank chunks based on keyword matching
        
        Args:
            query: Original query
            chunks: Candidate chunks from vector search
            k: Number of results to return
            
        Returns:
            Top k chunks after reranking
        """
        if not chunks:
            return []
            
        # tokenize query (simple whitespace split, lowercase)
        query_terms = set(query.lower().split())
        
        # Remove common stop words (optional, keep it simple for now)
        stop_words = {'a', 'an', 'the', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by'}
        query_terms = {term for term in query_terms if term not in stop_words}
        
        if not query_terms:
            return chunks[:k]
            
        chunk_scores = []
        
        for i, chunk in enumerate(chunks):
            chunk_lower = chunk.lower()
            score = 0
            
            # 1. Exact term matching score
            matches = 0
            for term in query_terms:
                if term in chunk_lower:
                    matches += 1
            
            # keyword_score is percentage of query terms found
            keyword_score = matches / len(query_terms)
            
            # 2. Vector rank score (inverse of position)
            # The earlier it appeared in vector search, the higher the score
            # i is 0-indexed, so we use len(chunks)-i as a simple score
            vector_score = (len(chunks) - i) / len(chunks)
            
            # Combined score: We weight keyword matching heavily
            # If a chunk has many keywords, it should bubble up
            final_score = (keyword_score * 0.7) + (vector_score * 0.3)
            
            chunk_scores.append((final_score, chunk))
            
        # Sort by score descending
        chunk_scores.sort(key=lambda x: x[0], reverse=True)
        
        # Return top k chunks
        return [chunk for _, chunk in chunk_scores[:k]]
    
    def _save_index(self):
        """Save FAISS index and chunks to disk"""
        try:
            os.makedirs(self.index_path, exist_ok=True)
            
            # Save FAISS index
            faiss.write_index(self.index, self.index_file)
            
            # Save chunks
            with open(self.chunks_file, 'wb') as f:
                pickle.dump(self.chunks, f)
            
            print(f"✓ Saved index to {self.index_path}")
        
        except Exception as e:
            raise Exception(f"Error saving index: {str(e)}")
    
    def _load_index(self):
        """Load FAISS index and chunks from disk"""
        try:
            if not os.path.exists(self.index_file) or not os.path.exists(self.chunks_file):
                return
            
            # Load FAISS index
            self.index = faiss.read_index(self.index_file)
            
            # Load chunks
            with open(self.chunks_file, 'rb') as f:
                self.chunks = pickle.load(f)
            
            print(f"✓ Loaded index from {self.index_path} ({len(self.chunks)} chunks)")
        
        except Exception as e:
            print(f"Warning: Could not load index: {str(e)}")
            self.index = None
            self.chunks = []
    
    def clear(self):
        """Clear the index and chunks"""
        self.index = None
        self.chunks = []
        
        # Delete files
        if os.path.exists(self.index_file):
            os.remove(self.index_file)
        if os.path.exists(self.chunks_file):
            os.remove(self.chunks_file)
