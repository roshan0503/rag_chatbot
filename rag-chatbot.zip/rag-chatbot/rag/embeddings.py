"""
Embedding Generator Module
Uses Ollama's nomic-embed-text model for local embeddings
"""

import requests
from typing import List
import numpy as np

class EmbeddingGenerator:
    """Generate embeddings using Ollama's nomic-embed-text model"""
    
    def __init__(self, model: str = "nomic-embed-text", ollama_url: str = "http://localhost:11434"):
        """
        Initialize embedding generator
        
        Args:
            model: Ollama embedding model name
            ollama_url: Ollama API URL
        """
        self.model = model
        self.ollama_url = ollama_url
        self.embed_endpoint = f"{ollama_url}/api/embeddings"
    
    def generate_embeddings(self, texts: List[str]) -> np.ndarray:
        """
        Generate embeddings for a list of texts
        
        Args:
            texts: List of text chunks
            
        Returns:
            NumPy array of embeddings (shape: [num_texts, embedding_dim])
        """
        if not texts:
            raise ValueError("No texts provided for embedding generation")
        
        embeddings = []
        
        for i, text in enumerate(texts):
            try:
                embedding = self._get_embedding(text)
                embeddings.append(embedding)
                
                # Progress indication
                if (i + 1) % 10 == 0:
                    print(f"Generated embeddings for {i + 1}/{len(texts)} chunks")
            
            except Exception as e:
                raise Exception(f"Error generating embedding for chunk {i}: {str(e)}")
        
        return np.array(embeddings, dtype=np.float32)
    
    def generate_query_embedding(self, query: str) -> np.ndarray:
        """
        Generate embedding for a single query
        
        Args:
            query: Query text
            
        Returns:
            NumPy array embedding
        """
        embedding = self._get_embedding(query)
        return np.array(embedding, dtype=np.float32)
    
    def _get_embedding(self, text: str) -> List[float]:
        """
        Get embedding from Ollama API
        
        Args:
            text: Input text
            
        Returns:
            Embedding vector
        """
        try:
            payload = {
                "model": self.model,
                "prompt": text
            }
            
            response = requests.post(
                self.embed_endpoint,
                json=payload,
                timeout=30
            )
            
            if response.status_code != 200:
                raise Exception(f"Ollama API error: {response.status_code} - {response.text}")
            
            result = response.json()
            embedding = result.get('embedding')
            
            if not embedding:
                raise Exception("No embedding returned from Ollama")
            
            return embedding
        
        except requests.exceptions.ConnectionError:
            raise Exception(
                "Cannot connect to Ollama. Make sure Ollama is running at " + self.ollama_url
            )
        
        except requests.exceptions.Timeout:
            raise Exception("Ollama request timed out")
        
        except Exception as e:
            raise Exception(f"Error calling Ollama API: {str(e)}")
