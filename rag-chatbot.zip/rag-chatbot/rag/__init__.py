"""
RAG (Retrieval Augmented Generation) Package
Local document chatbot components
"""

__version__ = "1.0.0"
