"""
Document Loader Module
Supports PDF, DOCX, and TXT files
"""

import os
from typing import Optional
import PyPDF2
from docx import Document

class DocumentLoader:
    """Load and extract text from various document formats"""
    
    def __init__(self):
        self.supported_formats = ['.pdf', '.docx', '.txt']
    
    def load(self, filepath: str) -> Optional[str]:
        """
        Load document and extract text
        
        Args:
            filepath: Path to document file
            
        Returns:
            Extracted text or None if failed
        """
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"File not found: {filepath}")
        
        # Get file extension
        _, ext = os.path.splitext(filepath)
        ext = ext.lower()
        
        if ext not in self.supported_formats:
            raise ValueError(f"Unsupported file format: {ext}")
        
        # Route to appropriate loader
        if ext == '.pdf':
            return self._load_pdf(filepath)
        elif ext == '.docx':
            return self._load_docx(filepath)
        elif ext == '.txt':
            return self._load_txt(filepath)
        
        return None
    
    def _load_pdf(self, filepath: str) -> str:
        """Extract text from PDF"""
        text = []
        
        try:
            with open(filepath, 'rb') as file:
                pdf_reader = PyPDF2.PdfReader(file)
                
                for page_num in range(len(pdf_reader.pages)):
                    page = pdf_reader.pages[page_num]
                    page_text = page.extract_text()
                    if page_text:
                        text.append(page_text)
            
            return '\n\n'.join(text)
        
        except Exception as e:
            raise Exception(f"Error reading PDF: {str(e)}")
    
    def _load_docx(self, filepath: str) -> str:
        """Extract text from DOCX"""
        try:
            doc = Document(filepath)
            text = []
            
            for paragraph in doc.paragraphs:
                if paragraph.text.strip():
                    text.append(paragraph.text)
            
            return '\n\n'.join(text)
        
        except Exception as e:
            raise Exception(f"Error reading DOCX: {str(e)}")
    
    def _load_txt(self, filepath: str) -> str:
        """Extract text from TXT"""
        try:
            with open(filepath, 'r', encoding='utf-8') as file:
                return file.read()
        
        except UnicodeDecodeError:
            # Try with different encoding
            try:
                with open(filepath, 'r', encoding='latin-1') as file:
                    return file.read()
            except Exception as e:
                raise Exception(f"Error reading TXT: {str(e)}")
        
        except Exception as e:
            raise Exception(f"Error reading TXT: {str(e)}")
