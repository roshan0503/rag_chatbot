"""
Document Splitter Module
Implements RecursiveCharacterTextSplitter
"""

from typing import List

class DocumentSplitter:
    """
    Split documents into chunks using recursive character-based splitting
    Similar to LangChain's RecursiveCharacterTextSplitter
    """
    
    def __init__(self, chunk_size: int = 1000, chunk_overlap: int = 200):
        """
        Initialize splitter
        
        Args:
            chunk_size: Maximum size of each chunk
            chunk_overlap: Number of characters to overlap between chunks
        """
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        
        # Separators in order of preference (from largest to smallest)
        self.separators = [
            "\n\n",  # Double newline (paragraphs)
            "\n",    # Single newline
            ". ",    # Sentences
            "! ",    # Sentences
            "? ",    # Sentences
            "; ",    # Clauses
            ", ",    # Phrases
            " ",     # Words
            ""       # Characters
        ]
    
    def split(self, text: str) -> List[str]:
        """
        Split text into chunks
        
        Args:
            text: Input text to split
            
        Returns:
            List of text chunks
        """
        if not text:
            return []
        
        # Clean text
        text = text.strip()
        
        # Split recursively
        chunks = self._split_text(text, self.separators)
        
        # Filter out empty chunks
        chunks = [chunk.strip() for chunk in chunks if chunk.strip()]
        
        return chunks
    
    def _split_text(self, text: str, separators: List[str]) -> List[str]:
        """
        Recursively split text using separators
        
        Args:
            text: Text to split
            separators: List of separators to try
            
        Returns:
            List of text chunks
        """
        final_chunks = []
        
        # Use the first separator
        separator = separators[0] if separators else ""
        
        # If no separator, split by character
        if separator == "":
            return self._split_by_character(text)
        
        # Split by separator
        splits = text.split(separator)
        
        # Good splits that don't need further splitting
        good_splits = []
        
        for split in splits:
            if len(split) < self.chunk_size:
                good_splits.append(split)
            else:
                # This split is too large, need to split further
                if good_splits:
                    # Merge good splits first
                    merged = self._merge_splits(good_splits, separator)
                    final_chunks.extend(merged)
                    good_splits = []
                
                # Recursively split the large chunk with next separator
                if len(separators) > 1:
                    sub_chunks = self._split_text(split, separators[1:])
                    final_chunks.extend(sub_chunks)
                else:
                    # No more separators, split by character
                    final_chunks.extend(self._split_by_character(split))
        
        # Don't forget remaining good splits
        if good_splits:
            merged = self._merge_splits(good_splits, separator)
            final_chunks.extend(merged)
        
        return final_chunks
    
    def _merge_splits(self, splits: List[str], separator: str) -> List[str]:
        """
        Merge small splits into chunks of appropriate size
        
        Args:
            splits: List of text splits
            separator: Separator used
            
        Returns:
            List of merged chunks
        """
        chunks = []
        current_chunk = []
        current_length = 0
        
        for split in splits:
            split_length = len(split)
            
            # Add separator length if not first item
            if current_chunk:
                split_length += len(separator)
            
            # Check if adding this split would exceed chunk size
            if current_length + split_length > self.chunk_size and current_chunk:
                # Save current chunk
                chunks.append(separator.join(current_chunk))
                
                # Start new chunk with overlap
                # Keep last part of previous chunk for overlap
                overlap_text = separator.join(current_chunk)
                if len(overlap_text) > self.chunk_overlap:
                    # Find good breaking point for overlap
                    overlap_start = len(overlap_text) - self.chunk_overlap
                    overlap_chunk = overlap_text[overlap_start:]
                    current_chunk = [overlap_chunk, split] if overlap_chunk else [split]
                    current_length = len(separator.join(current_chunk))
                else:
                    current_chunk = [split]
                    current_length = split_length
            else:
                # Add to current chunk
                current_chunk.append(split)
                current_length += split_length
        
        # Add remaining chunk
        if current_chunk:
            chunks.append(separator.join(current_chunk))
        
        return chunks
    
    def _split_by_character(self, text: str) -> List[str]:
        """
        Split text by character when no separators work
        
        Args:
            text: Text to split
            
        Returns:
            List of chunks
        """
        chunks = []
        start = 0
        
        while start < len(text):
            end = start + self.chunk_size
            
            # Extract chunk
            chunk = text[start:end]
            chunks.append(chunk)
            
            # Move start position with overlap
            start = end - self.chunk_overlap
            
            # Ensure we make progress
            if start <= 0:
                start = end
        
        return chunks
