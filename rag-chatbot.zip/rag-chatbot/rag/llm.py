"""
LLM Handler Module
Uses Ollama's gemma3:4b for answer generation
"""

import requests
import json
from typing import Optional

class LLMHandler:
    """Handle LLM interactions with Ollama"""
    
    def __init__(self, model: str = "gemma3:4b", ollama_url: str = "http://localhost:11434"):
        """
        Initialize LLM handler
        
        Args:
            model: Ollama LLM model name
            ollama_url: Ollama API URL
        """
        self.model = model
        self.ollama_url = ollama_url
        self.generate_endpoint = f"{ollama_url}/api/generate"
    
    def generate_answer(self, prompt: str, temperature: float = 0.3, max_tokens: int = 1000) -> str:
        """
        Generate answer using Ollama LLM
        
        Args:
            prompt: RAG prompt with context and question
            temperature: Sampling temperature (lower = more focused)
            max_tokens: Maximum tokens to generate
            
        Returns:
            Generated answer text
        """
        try:
            payload = {
                "model": self.model,
                "prompt": prompt,
                "stream": False,
                "options": {
                    "temperature": temperature,
                    "num_predict": max_tokens
                }
            }
            
            response = requests.post(
                self.generate_endpoint,
                json=payload,
                timeout=60  # Longer timeout for generation
            )
            
            if response.status_code != 200:
                raise Exception(f"Ollama API error: {response.status_code} - {response.text}")
            
            result = response.json()
            answer = result.get('response', '').strip()
            
            if not answer:
                raise Exception("No response generated from LLM")
            
            return answer
        
        except requests.exceptions.ConnectionError:
            raise Exception(
                f"Cannot connect to Ollama. Make sure Ollama is running at {self.ollama_url} "
                f"and the model '{self.model}' is available."
            )
        
        except requests.exceptions.Timeout:
            raise Exception("LLM request timed out. The query might be too complex.")
        
        except Exception as e:
            raise Exception(f"Error calling Ollama LLM: {str(e)}")
    
    def stream_answer(self, prompt: str, temperature: float = 0.3):
        """
        Generate answer with streaming (for future use)
        
        Args:
            prompt: RAG prompt with context and question
            temperature: Sampling temperature
            
        Yields:
            Chunks of generated text
        """
        try:
            payload = {
                "model": self.model,
                "prompt": prompt,
                "stream": True,
                "options": {
                    "temperature": temperature
                }
            }
            
            response = requests.post(
                self.generate_endpoint,
                json=payload,
                stream=True,
                timeout=60
            )
            
            if response.status_code != 200:
                raise Exception(f"Ollama API error: {response.status_code}")
            
            for line in response.iter_lines():
                if line:
                    chunk = json.loads(line)
                    if 'response' in chunk:
                        yield chunk['response']
        
        except Exception as e:
            raise Exception(f"Error streaming from Ollama: {str(e)}")
