#!/bin/bash

# LocalDoc Chat - Run Script
# This script checks dependencies and starts the application

echo "=========================================="
echo "LocalDoc Chat - Starting Up"
echo "=========================================="
echo ""

# Check if Python is available
if ! command -v python3 &> /dev/null; then
    echo "❌ Python3 not found. Please install Python 3.9 or higher."
    exit 1
fi

# Check if Ollama is running
echo "🦙 Checking Ollama..."
if ! command -v ollama &> /dev/null; then
    echo "❌ Ollama not found. Please install from https://ollama.com"
    exit 1
fi

# Try to list models
if ollama list &> /dev/null; then
    echo "✅ Ollama is running"
else
    echo "⚠️  Ollama may not be running. Starting Ollama..."
    ollama serve &
    sleep 2
fi

# Check for required models
echo ""
echo "🤖 Checking required models..."

MODELS_OK=true

if ollama list | grep -q "gemma3:4b"; then
    echo "✅ gemma3:4b found"
else
    echo "❌ gemma3:4b not found"
    echo "   Run: ollama pull gemma3:4b"
    MODELS_OK=false
fi

if ollama list | grep -q "nomic-embed-text"; then
    echo "✅ nomic-embed-text found"
else
    echo "❌ nomic-embed-text not found"
    echo "   Run: ollama pull nomic-embed-text"
    MODELS_OK=false
fi

if [ "$MODELS_OK" = false ]; then
    echo ""
    echo "❌ Missing required models. Please pull them first."
    exit 1
fi

# Check Python dependencies
echo ""
echo "📦 Checking Python dependencies..."

if python3 -c "import flask, PyPDF2, docx, numpy, faiss, requests" 2> /dev/null; then
    echo "✅ All dependencies installed"
else
    echo "⚠️  Some dependencies missing. Installing..."
    pip3 install -r requirements.txt
fi

# Start the application
echo ""
echo "=========================================="
echo "🚀 Starting LocalDoc Chat..."
echo "=========================================="
echo ""
echo "Server will be available at:"
echo "   http://localhost:5000"
echo ""
echo "Press Ctrl+C to stop the server"
echo ""

python3 app.py
