# 🚀 LocalDoc Chat - Complete Installation Guide

This guide will walk you through setting up LocalDoc Chat from scratch.

## Table of Contents
1. [System Requirements](#system-requirements)
2. [Install Ollama](#install-ollama)
3. [Install Python Dependencies](#install-python-dependencies)
4. [Verify Setup](#verify-setup)
5. [Run the Application](#run-the-application)
6. [Test the System](#test-the-system)
7. [Troubleshooting](#troubleshooting)

---

## System Requirements

### Minimum Requirements
- **OS**: macOS, Linux, or Windows
- **RAM**: 8GB (16GB recommended for larger documents)
- **Storage**: 10GB free space (for models)
- **Python**: 3.9 or higher
- **Internet**: Required for initial model download only

### Recommended Specifications
- **RAM**: 16GB+
- **CPU**: 4+ cores
- **GPU**: Optional (CPU-only works fine)

---

## Install Ollama

Ollama provides the local LLM infrastructure. Install it based on your OS:

### macOS
```bash
brew install ollama
```

### Linux
```bash
curl -fsSL https://ollama.com/install.sh | sh
```

### Windows
Download and run the installer from: https://ollama.com/download/windows

### Verify Installation
```bash
ollama --version
```

You should see version information.

### Start Ollama (if not auto-started)
```bash
ollama serve
```

Leave this running in a terminal window.

---

## Download Required Models

### 1. Download LLM (Gemma 3)
```bash
ollama pull gemma3:4b
```

**Expected size**: ~2.5GB  
**Time**: 2-10 minutes depending on connection  

This model generates answers to your questions.

### 2. Download Embedding Model
```bash
ollama pull nomic-embed-text
```

**Expected size**: ~274MB  
**Time**: 30 seconds - 2 minutes

This model converts text to vectors for similarity search.

### 3. Verify Models
```bash
ollama list
```

You should see both models:
```
NAME                    ID              SIZE      MODIFIED
gemma3:4b              xxxxx           2.5 GB    X minutes ago
nomic-embed-text       xxxxx           274 MB    X minutes ago
```

---

## Install Python Dependencies

### 1. Navigate to Project Directory
```bash
cd rag-chatbot
```

### 2. Create Virtual Environment (Recommended)
```bash
# Create virtual environment
python3 -m venv venv

# Activate it
# On macOS/Linux:
source venv/bin/activate

# On Windows:
venv\Scripts\activate
```

You should see `(venv)` in your terminal prompt.

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

This installs:
- Flask (web framework)
- PyPDF2 (PDF parsing)
- python-docx (DOCX parsing)
- numpy (numerical operations)
- faiss-cpu (vector search)
- requests (HTTP client)

**Expected time**: 1-3 minutes

---

## Verify Setup

Run the setup verification script:

```bash
python check_setup.py
```

### Expected Output (All Passing)
```
============================================================
LocalDoc Chat - Setup Verification
============================================================

🐍 Checking Python version...
   ✅ Python 3.11.5

📦 Checking Python dependencies...
   ✅ Flask
   ✅ PyPDF2
   ✅ python-docx
   ✅ numpy
   ✅ faiss-cpu
   ✅ requests

🦙 Checking Ollama...
   ✅ Ollama is installed and running

🤖 Checking Ollama models...
   ✅ gemma3:4b - LLM for answer generation
   ✅ nomic-embed-text - Embedding model for vectors

📁 Checking directories...
   ✅ uploads
   ✅ data/faiss_index
   ✅ templates
   ✅ static/js
   ✅ rag

============================================================
✅ ALL CHECKS PASSED!

You're ready to run the application:
   python app.py
============================================================
```

If any checks fail, follow the instructions to fix them.

---

## Run the Application

### Option 1: Use the Run Script (Easy)
```bash
./run.sh
```

### Option 2: Direct Python (Manual)
```bash
python app.py
```

### Expected Startup Output
```
============================================================
LocalDoc Chat - RAG Document Chatbot
============================================================
Starting server at http://localhost:5000
Make sure Ollama is running with:
  - gemma3:4b (LLM)
  - nomic-embed-text (Embeddings)
============================================================
 * Serving Flask app 'app'
 * Debug mode: on
 * Running on http://0.0.0.0:5000
```

### Access the Application
Open your browser and go to:
```
http://localhost:5000
```

You should see the LocalDoc Chat interface!

---

## Test the System

### 1. Upload Test Document

We've included a sample document. Here's how to test:

1. Click the upload zone or drag the `sample_document.txt` file
2. Wait for the progress bar to complete
3. You should see "Document processed successfully!" notification
4. The document appears in the left sidebar

### 2. Ask Test Questions

Try these questions with the sample document:

**Question 1**: "What is LocalDoc Chat?"
**Expected**: Information about LocalDoc Chat being a local RAG chatbot

**Question 2**: "What file formats are supported?"
**Expected**: PDF, DOCX, and TXT

**Question 3**: "How does the RAG system work?"
**Expected**: Explanation of chunking, embeddings, and retrieval

**Question 4**: "What is the capital of France?"
**Expected**: "I cannot find this information in the uploaded document."
(This tests that the system doesn't hallucinate)

### 3. Check Source Attribution

Click "View source chunks" on any answer to see the exact passages used.

---

## Troubleshooting

### Issue: "Cannot connect to Ollama"

**Solution 1**: Start Ollama
```bash
ollama serve
```

**Solution 2**: Check if Ollama is running
```bash
# Should show running process
ps aux | grep ollama
```

**Solution 3**: Verify port
```bash
curl http://localhost:11434/api/tags
# Should return JSON with model list
```

---

### Issue: "Model not found: gemma3:4b"

**Solution**: Pull the model
```bash
ollama pull gemma3:4b
```

Wait for download to complete, then restart the app.

---

### Issue: "Import Error: No module named 'flask'"

**Solution**: Install dependencies
```bash
# Make sure virtual environment is activated
source venv/bin/activate  # On macOS/Linux

# Install dependencies
pip install -r requirements.txt
```

---

### Issue: "Error processing PDF"

**Possible causes**:
1. PDF is corrupted
2. PDF is password-protected
3. PDF has no extractable text (scanned image)

**Solutions**:
- Try a different PDF
- Remove password protection
- Use OCR on scanned PDFs first

---

### Issue: Application is slow

**Solutions**:
1. Use smaller documents (< 10MB)
2. Reduce chunk_size in `app.py`:
   ```python
   splitter = DocumentSplitter(chunk_size=500, chunk_overlap=100)
   ```
3. Use a smaller model:
   ```bash
   ollama pull gemma2:2b
   ```
   Then update `rag/llm.py` to use `gemma2:2b`

---

### Issue: High memory usage

**Solutions**:
1. Close other applications
2. Use gemma2:2b instead of gemma3:4b
3. Process smaller documents
4. Restart the application periodically

---

## Advanced Configuration

### Change Ollama URL
If Ollama runs on a different port, edit these files:

**rag/embeddings.py**:
```python
ollama_url = "http://localhost:11434"  # Change port if needed
```

**rag/llm.py**:
```python
ollama_url = "http://localhost:11434"  # Change port if needed
```

### Adjust Chunk Parameters
Edit `app.py`:
```python
splitter = DocumentSplitter(
    chunk_size=1000,      # Smaller = more chunks, better precision
    chunk_overlap=200     # Higher = more context, slower processing
)
```

### Change Number of Retrieved Chunks
Edit `app.py` in the `/chat` route:
```python
retrieved_chunks = vector_store.search(query, k=4)  # Increase for more context
```

---

## Next Steps

✅ **You're all set!** Here's what you can do:

1. **Upload your own documents** - Try PDFs, DOCX files, research papers
2. **Customize the UI** - Edit `templates/index.html` and colors
3. **Add features** - Implement conversation history, multi-document support
4. **Deploy** - Use Docker, nginx, or deploy to a server
5. **Share** - Help others set up their own local RAG system

---

## Getting Help

If you run into issues:

1. **Check logs** - Terminal shows detailed error messages
2. **Browser console** - F12 shows frontend errors
3. **Run verification** - `python check_setup.py`
4. **Review documentation** - See README.md

---

## Security Note

🔒 **Everything runs locally**:
- Documents never leave your machine
- No cloud APIs are used
- No telemetry or tracking
- Complete privacy and data control

Enjoy your private, local AI document assistant! 🎉
